var portal_url = '/sites/v2qsap/';
var c_data = c_data || {};
c_data.animations = [];
c_data.timelines = [{
    "data": {
        "type": 0,
        "t": {
            "rv": 0,
            "rp": 0,
            "wa": 0,
            "de": 0,
            "st": 1,
            "du": 1,
            "es": 0
        },
        "d": {}
    },
    "element_id": "sectionfcee37b3",
    "iType": 0,
    "id": "tl_86b5022c",
    "animations": []
}, {
    "iType": 0,
    "isNew": true,
    "animations": [],
    "element_id": "body_a0fa814606522dca",
    "data": {
        "type": 0,
        "t": {
            "rv": 0,
            "rp": 0,
            "wa": 0,
            "de": 0,
            "st": 1,
            "du": 1,
            "es": 0
        },
        "d": {}
    },
    "id": "M_9cb90b65b281dddc"
}, {
    "iType": 0,
    "element_id": "sectionab099e47",
    "data": {
        "type": 0,
        "t": {
            "rv": 0,
            "rp": 0,
            "wa": 0,
            "de": 0,
            "st": 1,
            "du": 1,
            "es": 0
        },
        "d": {}
    },
    "id": "tl_389d6d77",
    "animations": []
}];
c_data.actions = [{
    "element_id": "btn_list_item_cc94f54a",
    "data": {
        "args": {
            "content_list": "contentgridviewe26f8a78",
            "e_ids": [],
            "category_list": "",
            "content_class": ["cbcont_5e9ac9e0"],
            "paramType": 1,
            "a_ids": [],
            "st": 1,
            "tag_list": ""
        },
        "type": 0,
        "exec": 107
    },
    "id": "M_a7b42b1ff2805a6c",
    "isNew": true
}, {
    "element_id": "btn_list_item08f3c922",
    "data": {
        "args": {
            "content_list": "contentgridviewe26f8a78",
            "e_ids": [],
            "category_list": "",
            "content_class": ["cbcont_5e9ac9e0"],
            "paramType": 1,
            "a_ids": [],
            "st": 1,
            "tag_list": "居住"
        },
        "type": 0,
        "exec": 107
    },
    "id": "M_66ce1144274fb00a",
    "isNew": true
}, {
    "element_id": "btn_list_item43a14df2",
    "data": {
        "args": {
            "content_list": "contentgridviewe26f8a78",
            "e_ids": [],
            "category_list": "",
            "content_class": ["cbcont_5e9ac9e0"],
            "paramType": 1,
            "a_ids": [],
            "st": 1,
            "tag_list": "文教"
        },
        "type": 0,
        "exec": 107
    },
    "id": "M_cc64acd6a34fccee",
    "isNew": true
}, {
    "element_id": "btn_list_item254e7698",
    "data": {
        "args": {
            "content_list": "contentgridviewe26f8a78",
            "e_ids": [],
            "category_list": "",
            "content_class": ["cbcont_5e9ac9e0"],
            "paramType": 1,
            "a_ids": [],
            "st": 1,
            "tag_list": "医疗"
        },
        "type": 0,
        "exec": 107
    },
    "id": "M_4cba26b42eef38b1",
    "isNew": true
}, {
    "element_id": "btn_list_item8288a1c3",
    "data": {
        "args": {
            "content_list": "contentgridviewe26f8a78",
            "e_ids": [],
            "category_list": "",
            "content_class": ["cbcont_5e9ac9e0"],
            "paramType": 1,
            "a_ids": [],
            "st": 1,
            "tag_list": "办公"
        },
        "type": 0,
        "exec": 107
    },
    "id": "M_e7e56d3b680cd16e",
    "isNew": true
}, {
    "element_id": "btn_list_itemfaf1886c",
    "data": {
        "args": {
            "content_list": "contentgridviewe26f8a78",
            "e_ids": [],
            "category_list": "",
            "content_class": ["cbcont_5e9ac9e0"],
            "paramType": 1,
            "a_ids": [],
            "st": 1,
            "tag_list": "商业"
        },
        "type": 0,
        "exec": 107
    },
    "id": "M_9b5ea55ee7bc1c4e",
    "isNew": true
}, {
    "element_id": "btn_list_item252ee821",
    "data": {
        "args": {
            "content_list": "contentgridviewe26f8a78",
            "e_ids": [],
            "category_list": "",
            "content_class": ["cbcont_5e9ac9e0"],
            "paramType": 1,
            "a_ids": [],
            "st": 1,
            "tag_list": "展览"
        },
        "type": 0,
        "exec": 107
    },
    "id": "M_f78d4999b9e76db8",
    "isNew": true
}, {
    "element_id": "btn_list_itema1a06cee",
    "data": {
        "args": {
            "content_list": "contentgridviewe26f8a78",
            "e_ids": [],
            "category_list": "",
            "content_class": ["cbcont_5e9ac9e0"],
            "paramType": 1,
            "a_ids": [],
            "st": 1,
            "tag_list": "娱乐"
        },
        "type": 0,
        "exec": 107
    },
    "id": "M_2a6e136855c4b417",
    "isNew": true
}, {
    "element_id": "btn_list_itemd23bc2a4",
    "data": {
        "args": {
            "content_list": "contentgridviewe26f8a78",
            "e_ids": [],
            "category_list": "",
            "content_class": ["cbcont_5e9ac9e0"],
            "paramType": 1,
            "a_ids": [],
            "st": 1,
            "tag_list": "体育"
        },
        "type": 0,
        "exec": 107
    },
    "id": "M_e0905298240a0c87",
    "isNew": true
}, {
    "element_id": "btn_list_itemd5ae5a92",
    "data": {
        "args": {
            "content_list": "contentgridviewe26f8a78",
            "e_ids": [],
            "category_list": "",
            "content_class": ["cbcont_5e9ac9e0"],
            "paramType": 1,
            "a_ids": [],
            "st": 1,
            "tag_list": "农业"
        },
        "type": 0,
        "exec": 107
    },
    "id": "M_f7b71db0fe20c528",
    "isNew": true
}]