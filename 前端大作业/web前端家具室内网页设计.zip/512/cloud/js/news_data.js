var portal_url = '/sites/v2qsap/';
var c_data = c_data || {};
c_data.animations = [];
c_data.timelines = [{
    "data": {
        "type": 0,
        "t": {
            "rv": 0,
            "rp": 0,
            "wa": 0,
            "de": 0,
            "st": 1,
            "du": 1,
            "es": 0
        },
        "d": {}
    },
    "element_id": "sectionfcee37b3",
    "iType": 0,
    "id": "tl_86b5022c",
    "animations": []
}, {
    "iType": 0,
    "isNew": true,
    "animations": [],
    "element_id": "body_a0fa814606522dca",
    "data": {
        "type": 0,
        "t": {
            "rv": 0,
            "rp": 0,
            "wa": 0,
            "de": 0,
            "st": 1,
            "du": 1,
            "es": 0
        },
        "d": {}
    },
    "id": "M_9cb90b65b281dddc"
}, {
    "iType": 0,
    "element_id": "sectionab099e47",
    "data": {
        "type": 0,
        "t": {
            "rv": 0,
            "rp": 0,
            "wa": 0,
            "de": 0,
            "st": 1,
            "du": 1,
            "es": 0
        },
        "d": {}
    },
    "id": "tl_389d6d77",
    "animations": []
}];
c_data.actions = []