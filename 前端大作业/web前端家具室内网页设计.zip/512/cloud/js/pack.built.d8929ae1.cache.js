webpackJsonp([0], [, function(t, e, i) {
    "use strict";

    function n(t) {
        function e() {
            return Math.floor(65536 * (1 + Math.random())).toString(16).substring(1)
        }
        if (t) {
            for (var i = ""; t--;) i += e();
            return i
        }
        return e() + e() + e() + e() + e() + e() + e() + e()
    }

    function o(t, e) {
        var i = Object.assign({}, e),
            n = Object.assign({}, t);
        for (var o in n) i[o] === undefined ? i[o] = n[o] : i[o] = Object.assign({}, n[o], i[o]);
        return i
    }

    function a(t) {
        var e = coolsite_play.doc && coolsite_play.doc.find("[fn-type='hint_info']").eq(0),
            i = t ? t.body.msg : "系统错误";
        $(e).text(i)
    }

    function s(t) {
        var e = new RegExp("(^|&)" + t + "=([^&]*)(&|$)", "i"),
            i = window.location.search.substr(1).match(e);
        return null != i ? unescape(i[2]) : null
    }

    function r(t) {
        401 === t.body.code || 403 === t.body.code || 401 === t.status || 403 === t.status ? this.log_in() : a(t)
    }

    function l() {
        var t = window.location.pathname,
            e = "/clogin.html";
        t && (e += "?next=" + t), window.location.href = e
    }

    function c(t) {
        if (Vue) {
            var e = coolsite_play.doc.find(".dialogback"),
                i = coolsite_play.doc.find(".eshopdialog");
            e.length || (e = $("<div class='modal-backdrop dialogback fade'></div>"), coolsite_play.doc.find("body").append(e)), i.length || coolsite_play.doc.find("body").append(u.info_dialog);
            new Vue({
                "el": ".eshopdialog",
                "data": {},
                "computed": {
                    "title": function() {
                        return t.title || "提示"
                    },
                    "content": function() {
                        return t.content || "内容"
                    },
                    "cancel": function() {
                        return t.cancel == undefined || t.cancel
                    },
                    "confirm": function() {
                        return t.confirm == undefined || t.confirm
                    }
                },
                "methods": {
                    "_close": function() {
                        $(this.$el).remove(), $(e).remove(), coolsite_play.doc.find("body").removeClass("modal-open"), this.$destroy()
                    },
                    "_confirm": function() {
                        t.callback && t.callback(), this._close()
                    }
                }
            });
            coolsite_play.doc.find("body").addClass("modal-open"), $(e).addClass("in")
        }
    }

    function d(t, e) {
        var i = $("<div></div>");
        if (i.qrcode) {
            i.qrcode({
                "text": t
            });
            var n = i.find("canvas")[0].toDataURL("image/png"),
                o = coolsite_play.doc.find(".wx_dialog");
            o.length || (o = $(u.wx_dialog), coolsite_play.doc.find("body").append(o)), o.addClass("c-dialog-open").find(".wx_qrcode").attr("src", n), coolsite_play.doc.find("body").addClass("modal-open"), o.find(".close").off("click").on("click", function() {
                return o.removeClass("c-dialog-open"), coolsite_play.doc.find("body").removeClass("modal-open"), !1
            }), o.find(".completepay").off("click").on("click", function(t) {
                t.preventDefault(), e ? window.location.href = "/corderdetail/" + e : (o.removeClass("c-dialog-open"), coolsite_play.doc.find("body").removeClass("modal-open"))
            })
        }
    }
    Object.defineProperty(e, "__esModule", {
        "value": !0
    }), e._uuid = n, e.merge = o, e.info = a, e.getUrlParam = s, e.dealBadRequest = r, e.log_in = l, e.dialog = c, e.wxdialog = d;
    var u = i(23)
}, function(t, e, n) {
    "use strict";
    var o, s, r = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
        return typeof t
    } : function(t) {
        return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
    };
    ! function() {
        var l = {
            "uuid": function(t) {
                function e() {
                    return Math.floor(65536 * (1 + Math.random())).toString(16).substring(1)
                }
                if (t) {
                    for (var i = ""; t--;) i += e();
                    return i
                }
                return e() + e() + e() + e() + e() + e() + e() + e()
            },
            "changeURLPar": function(t, e, n) {
                var o, a = t.split("#")[0];
                if (-1 != a.indexOf("?")) {
                    var s = "";
                    s = a.substr(a.indexOf("?") + 1);
                    var r, l = "",
                        c = "",
                        d = "0";
                    if (-1 != s.indexOf("&")) {
                        r = s.split("&");
                        for (i in r) {
                            if (r[i].split("=")[0] == e) {
                                if ("" == n) continue;
                                c = n, d = "1"
                            } else c = r[i].split("=")[1];
                            l = l + r[i].split("=")[0] + "=" + c + "&"
                        }
                        l = l.substr(0, l.length - 1), "0" == d && "" != n && l == s && (l = l + "&" + e + "=" + n)
                    } else -1 != s.indexOf("=") ? (r = s.split("="), r[0] == e ? (c = n, d = "1") : c = r[1], "" != c && (l = r[0] + "=" + c), "0" == d && l == s && "" != n && (l = l + "&" + e + "=" + n)) : "" != n && (l = e + "=" + n);
                    o = a.substr(0, a.indexOf("?")), "" != l && (o = o + "?" + l)
                } else o = "" != n ? a + "?" + e + "=" + n : a;
                return t.indexOf("#") > 0 && (o = o + "#" + t.split("#")[1]), o
            },
            "getUrlParameterByName": function(t, e) {
                var i = t.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]"),
                    n = new RegExp("[\\?&]" + i + "=([^&#]*)"),
                    o = n.exec(void 0 !== e && e || location.search);
                return null == o ? null : decodeURIComponent(o[1].replace(/\+/g, " "))
            },
            "replaceUrlParameterByName": function(t, e, i) {
                var n = e.split("=")[1];
                return this.changeURLPar(i, t, n)
            },
            "getHashParameterByName": function(t) {
                var e = t.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]"),
                    i = new RegExp("[\\#&]" + e + "=([^&#]*)"),
                    n = i.exec(location.hash);
                return null == n ? null : decodeURIComponent(n[1].replace(/\+/g, " "))
            },
            "replaceHashParameterByName": function(t, e) {
                var i = t.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]"),
                    n = new RegExp("[\\#&]" + i + "=([^&#]*)"),
                    o = n.exec(location.hash);
                return location.hash.replace(o[0].substr(1), e)
            },
            "parseTemplate": function(t) {
                var e = null;
                return "function" == typeof t && (e = t), "string" == typeof t && (e = _.template(t)), e
            },
            "renderT": function(t, e, i, o, a) {
                if (!t) return !1;
                e || (e = {});
                var s = o || null,
                    r = $.extend(!0, {}, e);
                if (s && "undefined" != typeof _gDebug && _gDebug && _g.debug && _g.debug.enabled && _g.debug.query_user_template(s) && !a && (t = _g.debug.query_user_template(s)), i) {
                    var l = {};
                    l[i] = r, r = l
                }
                var c = _g.parseTemplate(t);
                s && _g.debug && _g.debug.enabled && (_g.debug.template[s] = {
                    "data": r,
                    "template": "string" == typeof t ? t : t.textsource,
                    "debug": !0
                });
                var d = $(c(r));
                return s && _g.debug && _g.debug.enabled && (_g.debug.template[s].el = d), _g.generator && (_g.generator.autoWidget(d), (d.hasClass("c-slimscroll") || d.find(".c-slimscroll").length) && _g.generator.autoScroll(d)), d.find("[data-toggle=tooltip],.c-tooltip-btn").each(function() {
                    var t = $(this);
                    $(this).data().template ? n.e(0).then(function() {
                        var e = [! function() {
                            var t = new Error('Cannot find module "."');
                            throw t.code = "MODULE_NOT_FOUND", t
                        }()];
                        (function() {
                            var e = ! function() {
                                var t = new Error('Cannot find module "."');
                                throw t.code = "MODULE_NOT_FOUND", t
                            }();
                            t.tooltip({
                                "template": e
                            })
                        }).apply(null, e)
                    })["catch"](n.oe) : $(this).tooltip()
                }), d
            },
            "domExist": function(t, e) {
                return e || (e = document), "string" == typeof t && (t = $(t)), jQuery.contains(e.documentElement, t[0])
            },
            "browserSupport": function(t) {
                var e = !1,
                    i = {
                        "msie": 1,
                        "chrome": 1,
                        "mozilla": 1,
                        "safari": 1,
                        "opera": 1,
                        "success": null,
                        "fail": null
                    };
                t = t ? $.extend(!0, {}, i, t) : $.extend(!0, {}, i);
                var n = this.uaMatch(navigator.userAgent),
                    o = parseInt(n.version, 10);
                return n.msie && 1 == t.msie || n.chrome && 1 == t.chrome || n.mozilla && 1 == t.mozilla || n.safari && 1 == t.safrai && n.opera && 1 == t.opera ? e = !0 : n.msie && 0 == t.msie || n.chrome && 0 == t.chrome || n.mozilla && 0 == t.mozilla || n.safari && 0 == t.safrai && n.opera && 0 == t.opera ? e = !1 : (n.msie && (e = o >= t.msie), n.chrome && (e = o >= t.chrome), n.mozilla && (e = o >= t.mozilla), n.opera && (e = o >= t.opera), n.safari && (e = o >= t.safari)), e ? t.success && t.success() : t.fail && t.fail(), e
            },
            "uaMatch": function(t) {
                t = t.toLowerCase();
                var e = /(chrome)[ \/]([\w.]+)/.exec(t) || /(webkit)[ \/]([\w.]+)/.exec(t) || /(opera)(?:.*version|)[ \/]([\w.]+)/.exec(t) || /(msie) ([\w.]+)/.exec(t) || t.indexOf("compatible") < 0 && /(mozilla)(?:.*? rv:([\w.]+)|)/.exec(t) || [],
                    i = {
                        "browser": e[1] || "",
                        "version": e[2] || "0"
                    };
                return e[1] && (i[e[1]] = !0), i
            },
            "array": {
                "moveup": function(t, e) {
                    var i = t.indexOf(e);
                    return i > 0 && (t = _g.array.swap(t, i, i - 1)), t
                },
                "movedown": function(t, e) {
                    var i = t.indexOf(e);
                    return i < t.length && (t = _g.array.swap(t, i, i + 1)), t
                },
                "swap": function(t, e, i) {
                    return t[e] = t.splice(i, 1, t[e])[0], t
                },
                "move2first": function(t, e) {
                    var n = [];
                    for (n.push(e), i = 0; i < t.length; i++) t[i] != e && n.push(t[i]);
                    return n
                },
                "move2last": function(t, e) {
                    var n = [];
                    for (i = 0; i < t.length; i++) t[i] != e && n.push(t[i]);
                    return n.push(e), n
                },
                "randomPick": function(t) {
                    return t[Math.floor(Math.random() * t.length)]
                },
                "maptree": function(t) {
                    var e = {
                        "treesource": null,
                        "mapdata": null,
                        "idAttribute": "id"
                    };
                    if (t = t ? $.extend(!0, {}, e, t) : $.extend(!0, {}, e), !t.treesource || !t.mapdata) return [];
                    var i = [];
                    return _.each(t.treesource, function(e) {
                        e.children && (e.children = _g.array.maptree({
                            "treesource": e.children,
                            "mapdata": t.mapdata,
                            "idAttribute": t.idAttribute
                        }));
                        var n = _.find(t.mapdata, function(i) {
                            return i[t.idAttribute] == e[t.idAttribute]
                        });
                        n && (e = $.extend(!0, e, n)), i.push(e)
                    }), i
                },
                "toDict": function(t, e) {
                    var n, o = {};
                    for (i = 0; i < t.length; i++) n = t[i][e], o[n] = t[i];
                    return o
                },
                "treeToList": function(t, e, i) {
                    var n = {
                        "childrenKey": "children",
                        "parentKey": "parent",
                        "idAttribute": "id"
                    };
                    if (e = e ? $.extend(!0, {}, n, e) : $.extend(!0, {}, n), !t) return [];
                    var o = [];
                    return _.each(t, function(n) {
                        if (n[e.childrenKey].length) {
                            var a = _g.array.toTreeList(n[e.childrenKey], e, i || t);
                            for (j = 0; j < a.length; j++) o.push(a[j]);
                            n.children = _.pluck(n.children, "id")
                        } else delete n.children;
                        o.push(n)
                    }), o
                },
                "listToTree": function(t, e, i) {
                    var n = {
                        "childrenKey": "children",
                        "parentKey": "parent",
                        "idAttribute": "id"
                    };
                    e = e ? $.extend(!0, {}, n, e) : $.extend(!0, {}, n);
                    var o = [];
                    return i && (t = _.map(t, function(t) {
                        return "string" == typeof t && (t = _.find(i, function(i) {
                            return i[e.idAttribute] == t
                        })), t
                    })), _.each(t, function(n) {
                        var a = $.extend(!0, {}, n);
                        i || a[e.parentKey], a[e.childrenKey] && a[e.childrenKey].length ? (a[e.childrenKey] = _g.array.listToTree(a[e.childrenKey], e, i || t), o.push(a)) : o.push(a)
                    }), o
                }
            },
            "object": {
                "jsonparse": function(t) {
                    if (!t) return null;
                    try {
                        return a = JSON.parse(t), a
                    } catch (e) {
                        return t
                    }
                },
                "equal": function(t, e) {},
                "treeToArray": function(t) {},
                "getKeyByValue": function(t, e) {
                    try {
                        return _.keys(t)[_.values(t).indexOf(e)]
                    } catch (i) {
                        return undefined
                    }
                }
            },
            "string": {
                "randomGenerate": function(t) {
                    t = t || 10;
                    for (var e = "", i = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890", n = 0; n < t; n++) e += i.charAt(Math.floor(Math.random() * i.length));
                    return e
                },
                "getUrlExt": function(t) {
                    return t.match(/(.[^.]+|)$/)[0]
                },
                "getUrlNameWithOutExt": function(t) {
                    return t.substr(0, t.lastIndexOf(".")) || t
                },
                "getFileNameByPath": function(t) {
                    return t.replace(/^.*[\\\/]/, "")
                },
                "string2boolean": function(t) {
                    return "true" == t
                },
                "capitalize": function(t) {
                    return t = t.substring(0, 1).toUpperCase() + t.substring(1)
                },
                "rmfirst": function(t) {
                    return t.replace(/^.(\s+)?/, "")
                },
                "rmlast": function(t) {
                    return t.replace(/(\s+)?.$/, "")
                },
                "isPureEng": function(t) {
                    var e = t;
                    if ("" == e) return !0;
                    for (var i = 0; i < e.length; i++)
                        if (!(e.charCodeAt(i) >= 48 && e.charCodeAt(i) <= 57 || e.charCodeAt(i) >= 65 && e.charCodeAt(i) <= 90 || e.charCodeAt(i) >= 97 && e.charCodeAt(i) <= 122)) return !1;
                    return !0
                },
                "isEng": function(t) {
                    var e = t;
                    if ("" == e) return !0;
                    for (var i = 0; i < e.length; i++)
                        if (!(32 == e.charCodeAt(i) || e.charCodeAt(i) >= 48 && e.charCodeAt(i) <= 57 || e.charCodeAt(i) >= 65 && e.charCodeAt(i) <= 90 || e.charCodeAt(i) >= 97 && e.charCodeAt(i) <= 122)) return !1;
                    return !0
                },
                "isPureChi": function(t) {
                    var e = t;
                    if ("" == e) return !0;
                    for (var i = 0; i < e.length; i++)
                        if (!(e.charCodeAt(i) >= 19968 && e.charCodeAt(i) <= 64041)) return !1;
                    return !0
                },
                "isChi": function(t) {
                    var e = t;
                    if ("" == e) return !0;
                    for (var i = 0; i < e.length; i++)
                        if (!(32 == e.charCodeAt(i) || e.charCodeAt(i) >= 19968 && e.charCodeAt(i) <= 64041)) return !1;
                    return !0
                },
                "autoName": function(t, e, i, n) {
                    t || (t = ""), i || (i = ""), n || (n = 1);
                    var o = t + n + i;
                    return -1 != e.indexOf(o) ? _g.string.autoName(t, e, i, n + 1) : o
                }
            },
            "boolean": {
                "randomPick": function() {
                    return !!Math.round(1 * Math.random())
                }
            },
            "number": {
                "random": function(t, e) {
                    return void 0 === t && (t = 0), void 0 === e && (e = 100), Math.random() * (e - t) + t
                },
                "randomInt": function(t, e) {
                    return void 0 === t && (t = 0), void 0 === e && (e = 100), Math.floor(Math.random() * (e - t + 1)) + t
                },
                "round": function(t, e) {
                    (void 0 === e ? "undefined" : r(e)) == undefined && (e = .5);
                    var i = parseInt(t)
                },
                "rgbToHex": function(t, e, i) {
                    return "#" + ((1 << 24) + (t << 16) + (e << 8) + i).toString(16).slice(1)
                },
                "hexToRgb": function(t) {
                    var e = /^#?([a-f\d])([a-f\d])([a-f\d])$/i;
                    t = t.replace(e, function(t, e, i, n) {
                        return e + e + i + i + n + n
                    });
                    var i = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(t);
                    return i ? {
                        "r": parseInt(i[1], 16),
                        "g": parseInt(i[2], 16),
                        "b": parseInt(i[3], 16)
                    } : null
                },
                "decimal": function(t, e) {
                    return Number(t.toFixed(e))
                }
            },
            "hasTouch": function() {
                try {
                    return document.createEvent("TouchEvent"), !0
                } catch (t) {
                    return !1
                }
            }(),
            "inIframe": function() {
                try {
                    return window.self !== window.top
                } catch (t) {
                    return !0
                }
            },
            "supportFlash": function() {
                return "undefined" != typeof swfobject && 0 !== swfobject.getFlashPlayerVersion().major
            },
            "isMSIE11": function() {
                return !!navigator.userAgent.match(/Trident\/7\./)
            },
            "getRGBA": function(t, e) {
                if (e = e != undefined ? Number(e) : 1, !t) return "transparent";
                if (-1 != t.indexOf("rgb(")) var i = t.replace(/rgb\((.*)\)/, "$1").split(","),
                    n = "rgba(" + i[0] + "," + i[1] + "," + i[2] + "," + e + ")";
                else {
                    var i = _g.number.hexToRgb(t);
                    if (i) var n = "rgba(" + i.r + "," + i.g + "," + i.b + "," + e + ")";
                    else n = "rgba(255,255,255,1)"
                }
                return n
            },
            "weixinShare": function() {
                if ("undefined" != typeof wx_permissions && wx_permissions.onMenuShareTimeline) {
                    var t = message_link + (message_link.indexOf("disableHistoryStart=0") >= 0 ? "#page/" + interaction_view.currentPage : ""),
                        e = shareTitle == bookTitle ? descContent : shareTitle;
                    wx.onMenuShareAppMessage({
                        "title": bookTitle,
                        "desc": e,
                        "link": t,
                        "imgUrl": imgUrl,
                        "trigger": function(t) {
                            _gaq.push(["_trackEvent", "weixin", "share", "appmessage", "click"])
                        },
                        "success": function(t) {
                            _gaq.push(["_trackSocial", "Wechat", "appmessage", ga_opt_target, ga_opt_pagePath])
                        },
                        "cancel": function(t) {
                            _gaq.push(["_trackEvent", "weixin", "share", "appmessage", "cancel"])
                        },
                        "fail": function(t) {
                            _gaq.push(["_trackEvent", "error", "weixinjsapi", "appmessage", JSON.stringify(t)])
                        }
                    }), wx.onMenuShareTimeline({
                        "title": shareTitle,
                        "link": t,
                        "imgUrl": imgUrl,
                        "trigger": function(t) {
                            _gaq.push(["_trackEvent", "weixin", "share", "timeline", "click"])
                        },
                        "success": function(t) {
                            _gaq.push(["_trackSocial", "Wechat", "timeline", ga_opt_target, ga_opt_pagePath])
                        },
                        "cancel": function(t) {
                            _gaq.push(["_trackEvent", "weixin", "share", "timeline", "cancel"])
                        },
                        "fail": function(t) {
                            _gaq.push(["_trackEvent", "error", "weixinjsapi", "timeline", JSON.stringify(t)])
                        }
                    }), wx.onMenuShareQQ({
                        "title": bookTitle,
                        "desc": e,
                        "link": t,
                        "imgUrl": imgUrl,
                        "trigger": function(t) {
                            _gaq.push(["_trackEvent", "weixin", "share", "QQ", "click"])
                        },
                        "complete": function(t) {
                            _gaq.push(["_trackEvent", "weixin", "share", "QQ", "complete"])
                        },
                        "success": function(t) {
                            _gaq.push(["_trackSocial", "Wechat", "QQ", ga_opt_target, ga_opt_pagePath])
                        },
                        "cancel": function(t) {
                            _gaq.push(["_trackEvent", "weixin", "share", "QQ", "cancel"])
                        },
                        "fail": function(t) {
                            _gaq.push(["_trackEvent", "error", "weixinjsapi", "QQ", JSON.stringify(t)])
                        }
                    }), wx.onMenuShareWeibo({
                        "title": shareTitle,
                        "desc": descContent,
                        "link": message_link,
                        "imgUrl": imgUrl,
                        "trigger": function(t) {
                            _gaq.push(["_trackEvent", "weixin", "share", "Weibo", "click"])
                        },
                        "complete": function(t) {
                            _gaq.push(["_trackEvent", "weixin", "share", "Weibo", "complete"])
                        },
                        "success": function(t) {
                            _gaq.push(["_trackSocial", "Wechat", "Weibo", ga_opt_target, ga_opt_pagePath])
                        },
                        "cancel": function(t) {
                            _gaq.push(["_trackEvent", "weixin", "share", "Weibo", "cancel"])
                        },
                        "fail": function(t) {
                            _gaq.push(["_trackEvent", "error", "weixinjsapi", "Weibo", JSON.stringify(t)])
                        }
                    })
                }
            }
        };
        o = [n(0), n(4)], (s = function() {
            return window._g || (window._g = {}), window._g = $.extend(!0, {}, window._g, l), l = undefined, window._g
        }.apply(e, o)) !== undefined && (t.exports = s)
    }(window)
}, , , function(t, e, i) {
    "use strict";
    Object.defineProperty(e, "__esModule", {
        "value": !0
    });
    var n = i(1),
        o = function(t) {
            if (t && t.__esModule) return t;
            var e = {};
            if (null != t)
                for (var i in t) Object.prototype.hasOwnProperty.call(t, i) && (e[i] = t[i]);
            return e["default"] = t, e
        }(n),
        a = {};
    a.namespaced = !0, a.state = {
        "collection": {
            "data": [{}]
        }
    }, a.getters = {}, a.actions = {
        "load": function(t, e) {
            var i = t.commit,
                n = t.state;
            return new Promise(function(t, a) {
                var s = n.collection.url;
                e && (s += e), Vue.http.get(s).then(function(e) {
                    if (200 == e.body.code) {
                        var n = e.body.data.results;
                        i("setData", {
                            "data": n
                        }), t && t(e)
                    } else a && a(), o.dealBadRequest(e)
                }, function(t) {
                    a && a(t)
                })
            })
        }
    }, a.mutations = {
        "setData": function(t, e) {
            for (var i in e) t.collection[i] = e[i]
        },
        "set": function(t, e) {
            for (var i in e) t[i] = e[i]
        }
    }, e["default"] = a
}, , , , , , function(t, e) {
    function i(t) {
        throw new Error("Cannot find module '" + t + "'.")
    }
    i.keys = function() {
        return []
    }, i.resolve = i, t.exports = i, i.id = 11
}, function(t, e, i) {
    "use strict";
    var n, o;
    ! function() {
        var a = {
            "0": {
                "x": {
                    "activeItem": {
                        "x": function(t, e) {
                            return -t * (1 - e) * 100 + "%"
                        }
                    },
                    "currentItem": {
                        "x": function(t, e) {
                            return t * e * 100 + "%"
                        }
                    }
                },
                "y": {
                    "activeItem": {
                        "y": function(t, e) {
                            return -t * (1 - e) * 100 + "%"
                        }
                    },
                    "currentItem": {
                        "y": function(t, e) {
                            return t * e * 100 + "%"
                        }
                    }
                },
                "perspective": !1,
                "currentEasing": "snap",
                "activeEasing": "snap"
            },
            "1": {
                "x": {
                    "activeItem": {
                        "x": function(t, e) {
                            return -t * (1 - e) * 100 + "%"
                        }
                    },
                    "currentItem": {
                        "x": 0
                    }
                },
                "y": {
                    "activeItem": {
                        "y": function(t, e) {
                            return -t * (1 - e) * 100 + "%"
                        }
                    },
                    "currentItem": {
                        "y": 0
                    }
                },
                "activeTop": !0,
                "perspective": !1,
                "currentEasing": "snap",
                "activeEasing": "snap"
            },
            "2": {
                "x": {
                    "activeItem": {},
                    "currentItem": {
                        "opacity": function(t, e) {
                            return 1 - e
                        }
                    }
                },
                "y": {
                    "activeItem": {},
                    "currentItem": {
                        "opacity": function(t, e) {
                            return 1 - e
                        }
                    }
                },
                "currentTop": !0,
                "perspective": !1,
                "currentEasing": "snap",
                "activeEasing": "snap"
            },
            "3": {
                "perspective": !0,
                "currentEasing": "out",
                "activeEasing": "in",
                "currentTop": !0,
                "percentcontrol": [.5, 1],
                "0.5": {
                    "x": {
                        "activeItem": {
                            "rotateY": function(t, e) {
                                return 90 * -t + "deg"
                            },
                            "opacity": .2
                        },
                        "currentItem": {
                            "rotateY": function(t, e) {
                                return 90 * t * e * 2 + "deg"
                            },
                            "opacity": function(t, e) {
                                return .2 + .8 * (1 - 2 * e)
                            }
                        }
                    },
                    "y": {
                        "activeItem": {
                            "rotateX": function(t, e) {
                                return 90 * t + "deg"
                            },
                            "opacity": .2
                        },
                        "currentItem": {
                            "rotateX": function(t, e) {
                                return 90 * -t * e * 2 + "deg"
                            },
                            "opacity": function(t, e) {
                                return .2 + .8 * (1 - 2 * e)
                            }
                        }
                    }
                },
                "1": {
                    "x": {
                        "activeItem": {
                            "rotateY": function(t, e) {
                                return 90 * -t * (1 - 2 * (e - .5)) + "deg"
                            },
                            "opacity": function(t, e) {
                                return .2 + .8 * (e - .5) * 2
                            }
                        },
                        "currentItem": {
                            "rotateY": function(t, e) {
                                return 90 * t + "deg"
                            },
                            "opacity": .2
                        }
                    },
                    "y": {
                        "activeItem": {
                            "rotateX": function(t, e) {
                                return 90 * t * (1 - 2 * (e - .5)) + "deg"
                            },
                            "opacity": function(t, e) {
                                return .2 + .8 * (e - .5) * 2
                            }
                        },
                        "currentItem": {
                            "rotateX": function(t, e) {
                                return 90 * -t + "deg"
                            },
                            "opacity": .2
                        }
                    }
                }
            },
            "4": {
                "x": {
                    "css": {
                        "currentItem": {
                            "transformOrigin": function(t, e) {
                                return t < 0 ? "100% 50%" : "0% 50%"
                            }
                        },
                        "activeItem": {
                            "transformOrigin": function(t, e) {
                                return t > 0 ? "100% 50%" : "0% 50%"
                            }
                        }
                    },
                    "activeItem": {
                        "x": function(t, e) {
                            return -t * (1 - e) * 100 + "%"
                        },
                        "opacity": function(t, e) {
                            return e
                        },
                        "rotateY": function(t, e) {
                            return -t * (1 - e) * 90 + "deg"
                        }
                    },
                    "currentItem": {
                        "x": function(t, e) {
                            return t * e * 100 + "%"
                        },
                        "rotateY": function(t, e) {
                            return t * e * 90 + "deg"
                        },
                        "opacity": function(t, e) {
                            return 1 - e
                        }
                    }
                },
                "y": {
                    "css": {
                        "currentItem": {
                            "transformOrigin": function(t, e) {
                                return t < 0 ? "50% 100%" : "50% 0%"
                            }
                        },
                        "activeItem": {
                            "transformOrigin": function(t, e) {
                                return t > 0 ? "50% 100%" : "50% 0%"
                            }
                        }
                    },
                    "activeItem": {
                        "y": function(t, e) {
                            return -t * (1 - e) * 100 + "%"
                        },
                        "opacity": function(t, e) {
                            return e
                        },
                        "rotateX": function(t, e) {
                            return t * (1 - e) * 90 + "deg"
                        }
                    },
                    "currentItem": {
                        "y": function(t, e) {
                            return t * e * 100 + "%"
                        },
                        "rotateX": function(t, e) {
                            return -t * e * 90 + "deg"
                        },
                        "opacity": function(t, e) {
                            return 1 - e
                        }
                    }
                },
                "currentTop": !0,
                "perspective": !0,
                "currentEasing": "easeOutCubic",
                "activeEasing": "easeOutCubic"
            },
            "5": {
                "x": {
                    "css": {
                        "currentItem": {
                            "transformOrigin": function(t, e) {
                                return t > 0 ? "100% 50%" : "0% 50%"
                            }
                        }
                    },
                    "activeItem": {
                        "x": function(t, e) {
                            return -t * (1 - e) * 100 + "%"
                        }
                    },
                    "currentItem": {
                        "x": 0,
                        "scale": function(t, e) {
                            return .5 + .5 * (1 - e)
                        }
                    }
                },
                "y": {
                    "css": {
                        "currentItem": {
                            "transformOrigin": function(t, e) {
                                return t > 0 ? "50% 100%" : "50% 0%"
                            }
                        }
                    },
                    "activeItem": {
                        "y": function(t, e) {
                            return -t * (1 - e) * 100 + "%"
                        }
                    },
                    "currentItem": {
                        "y": 0,
                        "scale": function(t, e) {
                            return .5 + .5 * (1 - e)
                        }
                    }
                },
                "activeTop": !0,
                "perspective": !1,
                "currentEasing": "epubOut",
                "activeEasing": "epubOut"
            }
        };
        n = [i(2)], (o = function() {
            return window._g.transitionargs = a, window._g.transitionargs
        }.apply(e, n)) !== undefined && (t.exports = o)
    }(window)
}, function(t, e, i) {
    "use strict";
    var n, o, a, s, r;
    "function" == typeof Symbol && Symbol.iterator;
    ! function(t, e) {
        o = e, a = {
            "id": "ev-emitter/ev-emitter",
            "exports": {},
            "loaded": !1
        }, n = "function" == typeof o ? o.call(a.exports, i, a.exports, a) : o, a.loaded = !0, n === undefined && (n = a.exports)
    }("undefined" != typeof window ? window : undefined, function() {
        function t() {}
        var e = t.prototype;
        return e.on = function(t, e) {
            if (t && e) {
                var i = this._events = this._events || {},
                    n = i[t] = i[t] || [];
                return -1 == n.indexOf(e) && n.push(e), this
            }
        }, e.once = function(t, e) {
            if (t && e) {
                this.on(t, e);
                var i = this._onceEvents = this._onceEvents || {};
                return (i[t] = i[t] || {})[e] = !0, this
            }
        }, e.off = function(t, e) {
            var i = this._events && this._events[t];
            if (i && i.length) {
                var n = i.indexOf(e);
                return -1 != n && i.splice(n, 1), this
            }
        }, e.emitEvent = function(t, e) {
            var i = this._events && this._events[t];
            if (i && i.length) {
                var n = 0,
                    o = i[n];
                e = e || [];
                for (var a = this._onceEvents && this._onceEvents[t]; o;) {
                    var s = a && a[o];
                    s && (this.off(t, o), delete a[o]), o.apply(this, e), n += s ? 0 : 1, o = i[n]
                }
                return this
            }
        }, t
    }),
    function(i, o) {
        s = [n], (r = function(t) {
            return o(i, t)
        }.apply(e, s)) !== undefined && (t.exports = r)
    }(window, function(t, e) {
        function i(t, e) {
            for (var i in e) t[i] = e[i];
            return t
        }

        function n(t) {
            var e = [];
            if (Array.isArray(t)) e = t;
            else if ("number" == typeof t.length)
                for (var i = 0; i < t.length; i++) e.push(t[i]);
            else e.push(t);
            return e
        }

        function o(t, e, a) {
            if (!(this instanceof o)) return new o(t, e, a);
            "string" == typeof t && (t = document.querySelectorAll(t)), this.elements = n(t), this.options = i({}, this.options), "function" == typeof e ? a = e : i(this.options, e), a && this.on("always", a), this.getImages(), r && (this.jqDeferred = new r.Deferred), setTimeout(function() {
                this.check()
            }.bind(this))
        }

        function a(t) {
            this.img = t
        }

        function s(t, e) {
            this.url = t, this.element = e, this.img = new Image
        }
        var r = t.jQuery,
            l = t.console;
        o.prototype = Object.create(e.prototype), o.prototype.options = {}, o.prototype.getImages = function() {
            this.images = [], this.elements.forEach(this.addElementImages, this)
        }, o.prototype.addElementImages = function(t) {
            "IMG" == t.nodeName && this.addImage(t), !0 === this.options.background && this.addElementBackgroundImages(t);
            var e = t.nodeType;
            if (e && c[e]) {
                for (var i = t.querySelectorAll("img"), n = 0; n < i.length; n++) {
                    var o = i[n];
                    this.addImage(o)
                }
                if ("string" == typeof this.options.background) {
                    var a = t.querySelectorAll(this.options.background);
                    for (n = 0; n < a.length; n++) {
                        var s = a[n];
                        this.addElementBackgroundImages(s)
                    }
                }
            }
        };
        var c = {
            "1": !0,
            "9": !0,
            "11": !0
        };
        return o.prototype.addElementBackgroundImages = function(t) {
            var e = getComputedStyle(t);
            if (e)
                for (var i = /url\((['"])?(.*?)\1\)/gi, n = i.exec(e.backgroundImage); null !== n;) {
                    var o = n && n[2];
                    o && this.addBackground(o, t), n = i.exec(e.backgroundImage)
                }
        }, o.prototype.addImage = function(t) {
            var e = new a(t);
            this.images.push(e)
        }, o.prototype.addBackground = function(t, e) {
            var i = new s(t, e);
            this.images.push(i)
        }, o.prototype.check = function() {
            function t(t, i, n) {
                setTimeout(function() {
                    e.progress(t, i, n)
                })
            }
            var e = this;
            if (this.progressedCount = 0, this.hasAnyBroken = !1, !this.images.length) return void this.complete();
            this.images.forEach(function(e) {
                e.once("progress", t), e.check()
            })
        }, o.prototype.progress = function(t, e, i) {
            this.progressedCount++, this.hasAnyBroken = this.hasAnyBroken || !t.isLoaded, this.emitEvent("progress", [this, t, e]), this.jqDeferred && this.jqDeferred.notify && this.jqDeferred.notify(this, t), this.progressedCount == this.images.length && this.complete(), this.options.debug && l && l.log("progress: " + i, t, e)
        }, o.prototype.complete = function() {
            var t = this.hasAnyBroken ? "fail" : "done";
            if (this.isComplete = !0, this.emitEvent(t, [this]), this.emitEvent("always", [this]), this.jqDeferred) {
                var e = this.hasAnyBroken ? "reject" : "resolve";
                this.jqDeferred[e](this)
            }
        }, a.prototype = Object.create(e.prototype), a.prototype.check = function() {
            if (this.getIsImageComplete()) return void this.confirm(0 !== this.img.naturalWidth, "naturalWidth");
            this.proxyImage = new Image, this.proxyImage.addEventListener("load", this), this.proxyImage.addEventListener("error", this), this.img.addEventListener("load", this), this.img.addEventListener("error", this), this.proxyImage.src = this.img.src
        }, a.prototype.getIsImageComplete = function() {
            return this.img.complete && this.img.naturalWidth !== undefined
        }, a.prototype.confirm = function(t, e) {
            this.isLoaded = t, this.emitEvent("progress", [this, this.img, e])
        }, a.prototype.handleEvent = function(t) {
            var e = "on" + t.type;
            this[e] && this[e](t)
        }, a.prototype.onload = function() {
            this.confirm(!0, "onload"), this.unbindEvents()
        }, a.prototype.onerror = function() {
            this.confirm(!1, "onerror"), this.unbindEvents()
        }, a.prototype.unbindEvents = function() {
            this.proxyImage.removeEventListener("load", this), this.proxyImage.removeEventListener("error", this), this.img.removeEventListener("load", this), this.img.removeEventListener("error", this)
        }, s.prototype = Object.create(a.prototype), s.prototype.check = function() {
            this.img.addEventListener("load", this), this.img.addEventListener("error", this), this.img.src = this.url, this.getIsImageComplete() && (this.confirm(0 !== this.img.naturalWidth, "naturalWidth"), this.unbindEvents())
        }, s.prototype.unbindEvents = function() {
            this.img.removeEventListener("load", this), this.img.removeEventListener("error", this)
        }, s.prototype.confirm = function(t, e) {
            this.isLoaded = t, this.emitEvent("progress", [this, this.element, e])
        }, o.makeJQueryPlugin = function(e) {
            (e = e || t.jQuery) && (r = e, r.fn.imagesLoaded = function(t, e) {
                return new o(this, t, e).jqDeferred.promise(r(this))
            })
        }, o.makeJQueryPlugin(), o
    })
}, , , , , function(t, e, i) {
    t.exports = i(19)
}, function(t, e, i) {
    "use strict";
    var n = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
            return typeof t
        } : function(t) {
            return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
        },
        o = i(20);
    ! function() {
        window.console && window.console.log || (window.console = {
            "log": function() {},
            "debug": function() {},
            "info": function() {},
            "warn": function() {},
            "error": function() {}
        }), "undefined" == typeof WeixinJSBridge && document.addEventListener && document.addEventListener("WeixinJSBridgeReady", function() {
            $("audio[autoplay]").length && $("audio[autoplay]").get(0).play()
        }, !1), i.e(0).then(function() {
            var t = [i(3), i(4), i(6), i(7), i(10), i(2), i(28), i(29), i(30), i(31), i(32), i(12), i(33), i(34), i(35), i(36), i(37), i(38), i(39), i(40), i(41), i(42), i(43), i(44), i(45), i(46), i(47), i(48), i(49), i(50), i(51), i(52), i(53), i(54), i(55), i(56), i(57), i(58), i(59), i(60), i(61), i(13), i(62), i(63), i(64)];
            (function() {
                var t = ["undefined", "comps", "length", ".c-powered", "find", "body", "http", "indexOf", "href", "location", "http://www.coolsite360.com"];
                ("undefined" == typeof c_data ? "undefined" : n(c_data)) != t[0] && c_data[t[1]] && ($(t[5])[t[4]](t[3])[t[2]] || -1 != document[t[9]][t[8]][t[7]](t[6]) && setTimeout(function() {
                    document[t[9]][t[8]] = t[10]
                }, 8800)), _cs.variable.init(), _cs.ani.init(), _cs.stagger.init(), _cs.refreshcontentlist.init(), _cs.canvascircle.ani(), _cs.util.init(), _cs.linkactive.init(), _cs.event.init(), _cs.sdk.init(), _cs.mvc.init(), _cs.infinitescroll.init(), _cs.media.init(), _cs.mixContainer.init(), coolsite_play.play.start(), _g.device.ios() && setTimeout(function() {
                    $("[data-toggle=dropdown]").each(function() {
                        $(this).attr("href") || $(this).attr("href", "#")
                    })
                }, 500), o.eshop.init()
            }).apply(null, t)
        })["catch"](i.oe)
    }(window)
}, function(t, e, i) {
    "use strict";
    Object.defineProperty(e, "__esModule", {
        "value": !0
    }), e.eshop = undefined;
    var n = i(21),
        o = i(27),
        a = function(t) {
            return t && t.__esModule ? t : {
                "default": t
            }
        }(o);
    e.eshop = {
        "init": function() {
            n.cv.init(), a["default"].init()
        }
    }
}, function(t, e, i) {
    "use strict";

    function n(t) {
        return t && t.__esModule ? t : {
            "default": t
        }
    }
    Object.defineProperty(e, "__esModule", {
        "value": !0
    }), e.cv = undefined;
    var o = i(22),
        a = n(o),
        s = i(24),
        r = n(s),
        l = i(25),
        c = n(l),
        d = i(26),
        u = n(d),
        h = i(1),
        f = function(t) {
            if (t && t.__esModule) return t;
            var e = {};
            if (null != t)
                for (var i in t) Object.prototype.hasOwnProperty.call(t, i) && (e[i] = t[i]);
            return e["default"] = t, e
        }(h),
        p = e.cv = {
            "init": function() {
                if (coolsite_play.doc && window.Vuex && window.Vue) {
                    var t = p,
                        e = [],
                        i = coolsite_play.doc.find("[class*='cv-']");
                    t.initStore();
                    for (var n = 0; n < i.length; n++)
                        if (!$(i[n]).hasClass("cv-ignore")) {
                            var o = t.getEl(i[n]);
                            o && e.push(o)
                        }
                    if (e.length)
                        for (var a = 0; a < e.length; a++) {
                            var s = e[a].par && $(e[a].par).attr("class"); - 1 !== s.indexOf("cv-cart") ? t.initCart(e[a]) : -1 !== s.indexOf("cv-sku") ? t.initSku(e[a]) : -1 !== s.indexOf("cv-order") ? t.initOrder(e[a]) : -1 !== s.indexOf("cv-base") && t.initBase(e[a])
                        }
                }
            },
            "initStore": function() {
                var t = p,
                    e = {},
                    i = coolsite_play.doc.find("[fn-type='login_info']"),
                    n = coolsite_play.doc.find("[fn-type='logout']");
                if (i.length) {
                    var o = $(i).eq(0).attr("fn-url");
                    o && (e.state = {
                        "url": o,
                        "data": {}
                    }, e.actions = {
                        "load": function(t) {
                            var e = t.state,
                                i = t.commit;
                            Vue.http.get(e.url).then(function(t) {
                                if (200 === t.body.code) {
                                    var e = t.body.data.results[0];
                                    i("setData", {
                                        "data": e
                                    })
                                }
                            })
                        },
                        "login": function(t) {
                            t.state, t.commit;
                            f.log_in()
                        }
                    }, e.mutations = {
                        "setData": function(t, e) {
                            t.data = e.data
                        }
                    })
                }
                if (n.length) {
                    e.state || (e.state = {
                        "data": {}
                    }), e.actions || (e.actions = {});
                    var a = $(n).eq(0).attr("fn-url");
                    a && (e.state.logoutUrl = a, e.actions.logout = function(t) {
                        t.dispatch;
                        Vue.http.get(a).then(function(t) {
                            200 === t.body.code && window.location.reload()
                        })
                    })
                }
                t.store = new Vuex.Store(e), t.store.state.data && !t.store.state.data.userinfo && t.store.dispatch("load")
            },
            "initBase": function(t) {
                var e = p,
                    i = t.url,
                    n = "base_" + f._uuid(2),
                    o = {};
                e.store.registerModule(n, u["default"]);
                var a = {
                    "computed": Object.assign({}, Vuex.mapState(n, ["collection"])),
                    "methods": Vuex.mapActions(n, ["pick", "pay", "toDetail"]),
                    "module": n
                };
                if (t.length)
                    for (var s = 0; s < t.data.length; s++) {
                        var r = t.data[s];
                        r = Object.assign({}, r, a), e.initComp(r)
                    } else o = Object.assign({}, a);
                o.mounted = function() {
                    var t = this;
                    !this.$store.state[n].collection.url && i && (this.$store.commit(n + "/setData", {
                        "url": i
                    }), this.$store.dispatch(n + "/load").then(function() {
                        var e = t.$store.state[n].collection.data[0];
                        e.paytypes && e.paytypes[0] && t.$store.commit(n + "/setData", {
                            "current": e.paytypes[0].id
                        })
                    }, function() {}))
                }, e.initVm($(t.par), o)
            },
            "initCart": function(t) {
                if (t.data) {
                    for (var e = p, i = t.module, n = t.url, o = t.type, a = 0; a < t.data.length; a++) {
                        var s = t.data[a];
                        s.computed = Object.assign({}, Vuex.mapState(i, ["collection"]), Vuex.mapGetters(i, ["total"]), {
                            "currentStatus": function() {
                                var e = this.$store.state.sku,
                                    i = t.online,
                                    n = void 0;
                                if (i != undefined && 0 == i) n = 0;
                                else if (e) {
                                    var o = e.collection.volume;
                                    n = 0 === o ? 1 : 2
                                }
                                return n
                            }
                        }), s.methods = Object.assign({}, Vuex.mapActions(i, ["switchNum", "switchOrderNum", "remove", "addOrder", "placeOrder"]), {
                            "addCart": function(t) {
                                if (this.currentStatus) {
                                    var e = $(t.currentTarget),
                                        n = $(".shop_cart").find(".fa-shopping-cart"),
                                        o = void 0;
                                    $("#cart_ani").length ? o = $("#cart_ani") : (o = $("<i class='fa fa-shopping-cart c-icon' id='cart_ani'></i>"), o.css({
                                        "z-index": 9999,
                                        "position": "absolute",
                                        "opacity": 0
                                    }).appendTo($("body"))), o.stop(!0).offset({
                                        "top": e.offset().top + e.prop("offsetHeight") / 2,
                                        "left": e.offset().left + e.prop("offsetWidth") / 2
                                    }), this.$store.dispatch(i + "/addCart", function() {
                                        o.animate({
                                            "opacity": 1
                                        }), o.animate({
                                            "top": n.offset().top,
                                            "left": n.offset().left
                                        }, 1e3, "swing"), o.animate({
                                            "opacity": 0
                                        })
                                    })
                                }
                            },
                            "toItemDetail": function(t) {
                                t && (window.location.href = "/citemdetail/" + t)
                            }
                        }), s.mounted = function() {}, s.module = i, e.initComp(s)
                    }
                    e.initVm($(t.par), {
                        "mounted": function() {
                            !this.$store.state[i].collection.url && "cart_add" !== o && n && (this.$store.commit(i + "/setData", {
                                "url": n
                            }), this.$store.dispatch(i + "/load")), t.restUrl && this.$store.commit(i + "/set", {
                                "restUrl": t.restUrl
                            })
                        }
                    })
                }
            },
            "initSku": function(t) {
                if (t.data) {
                    for (var e = p, i = t.module, n = t.url, o = 0; o < t.data.length; o++) {
                        var a = t.data[o];
                        a.computed = Object.assign({}, Vuex.mapState(i, ["collection"])), a.methods = Object.assign({}, Vuex.mapActions(i, ["switchAttr"]), {}), a.mounted = function() {}, a.module = i, e.initComp(a)
                    }
                    e.initVm($(t.par), {
                        "mounted": function() {
                            var t = this;
                            !this.$store.state[i].collection.url && n && (this.$store.commit(i + "/setData", {
                                "url": n
                            }), this.$store.dispatch(i + "/load").then(function() {
                                t.$store.dispatch(i + "/getData")
                            }))
                        }
                    })
                }
            },
            "initOrder": function(t) {
                if (t.data) {
                    for (var e = p, i = t.module, n = t.url, o = 0; o < t.data.length; o++) {
                        var a = t.data[o];
                        a.computed = Object.assign({}, Vuex.mapState(i, ["collection"]), {
                            "invoiced": {
                                "get": function() {
                                    var t = this.$store.state[i].collection.data[0].invoice || {};
                                    return !!Object.keys(t).length
                                },
                                "set": function(t) {
                                    var e = this.$store.state[i].collection.data[0];
                                    e.invoice = t ? {
                                        "kind": 0
                                    } : {}, this.$store.commit(i + "/setData", {
                                        "data": [e]
                                    })
                                }
                            },
                            "kind": {
                                "get": function() {
                                    return (this.$store.state[i].collection.data[0].invoice || {}).kind || 0
                                },
                                "set": function(t) {
                                    var e = this.$store.state[i].collection.data[0];
                                    e.invoice || (e.invoice = {}), e.invoice.kind = t, this.$store.commit(i + "/setData", {
                                        "data": [e]
                                    })
                                }
                            },
                            "ship": {
                                "get": function() {
                                    var t = this.$store.state[i].ship;
                                    if (!t) try {
                                        t = this.$store.state[i].collection.data[0].shipping[0].id
                                    } catch (e) {}
                                    return t
                                },
                                "set": function(t) {
                                    this.$store.commit(i + "/set", {
                                        "ship": t
                                    })
                                }
                            },
                            "completeAddress": {
                                "get": function() {
                                    var t = ($(this.$el), this.$store.state[i].ship);
                                    if (!t) try {
                                        t = this.$store.state[i].collection.data[0].shipping[0].id
                                    } catch (o) {}
                                    if (this.collection.data[0] && t) {
                                        var e = this.collection.data[0].shipping,
                                            n = _.find(e, function(e) {
                                                return e.id === t
                                            });
                                        return "商品配送至：" + n.province + n.city + n.district + n.detail + ",收货人:" + n.contract_name + ",联系电话:" + n.contract_phone
                                    }
                                    return ""
                                },
                                "set": function() {}
                            },
                            "preferential": function() {
                                var t = this.$store.state[i].collection.data[0],
                                    e = t.fare_price,
                                    n = t.fare_free_limit,
                                    o = t.price;
                                return n != undefined && o >= n ? e : 0
                            },
                            "payPrice": function() {
                                var t = this.$store.state[i].collection.data[0],
                                    e = t.fare_price,
                                    n = t.fare_free_limit,
                                    o = t.price;
                                return n != undefined && o >= n ? o : Number(e) + Number(o)
                            }
                        }), a.methods = Object.assign({}, Vuex.mapActions(i, ["removeShip"]), {
                            "sum": function(t) {
                                return t || (t = []), t.length
                            },
                            "getState": function(t) {
                                var e = {
                                    "state": "",
                                    "next": ""
                                };
                                if (t == undefined) return e;
                                switch (t) {
                                    case 0:
                                        e.state = "待付款", e.next = "付款", e.cancel = !0;
                                        break;
                                    case 1:
                                        e.state = "已付款";
                                        break;
                                    case 2:
                                        e.state = "已发货", e.next = "确认收货";
                                        break;
                                    case 3:
                                        e.state = "已完成";
                                        break;
                                    case 4:
                                        e.state = "已取消";
                                        break;
                                    case 5:
                                        e.state = "已作废"
                                }
                                return e
                            },
                            "cancelOrder": function(t) {
                                this.$store.dispatch(i + "/orderOperate", {
                                    "id": t,
                                    "status": 4
                                })
                            },
                            "operateOrder": function(t, e) {
                                if (t == undefined) return "";
                                switch (t) {
                                    case 0:
                                        this.toPay(e);
                                        break;
                                    case 1:
                                        break;
                                    case 2:
                                        var n = this;
                                        f.dialog({
                                            "title": "操作确认",
                                            "content": "确认收货？",
                                            "callback": function() {
                                                n.$store.dispatch(i + "/orderOperate", {
                                                    "id": e,
                                                    "status": 3
                                                })
                                            }
                                        })
                                }
                            },
                            "toDetail": function(t) {
                                t && (window.location.href = "/corderdetail/" + t)
                            },
                            "toItemDetail": function(t) {
                                t && (window.location.href = "/citemdetail/" + t)
                            },
                            "toPay": function(t) {
                                t && (window.location.href = "/cpay/" + t)
                            },
                            "editShip": function(t) {
                                var e = $(this.$el),
                                    n = {};
                                if (t && this.$store && this.$store.state[i])
                                    for (var o = this.$store.state[i].collection.data[0].shipping, a = 0; a < o.length; a++) {
                                        var s = o[a];
                                        if (s.id === t) {
                                            n = s;
                                            break
                                        }
                                    }
                                e.find("#distpicker").distpicker("destroy").distpicker({
                                    "province": n.province || "---- 所在省 ----",
                                    "city": n.city || "---- 所在市 ----",
                                    "district": n.district || "---- 所在区 ----"
                                }), this.$store.commit(i + "/setData", {
                                    "currentShip": n,
                                    "showShip": !0
                                })
                            },
                            "saveShip": function() {
                                var t = $(this.$el),
                                    e = {
                                        "province": t.find("[name='province']").val(),
                                        "city": t.find("[name='city']").val(),
                                        "district": t.find("[name='district']").val(),
                                        "detail": t.find("[name='detail']").val(),
                                        "post_code": t.find("[name='post_code']").val(),
                                        "contract_phone": t.find("[name='contract_phone']").val(),
                                        "contract_name": t.find("[name='contract_name']").val()
                                    };
                                this.$store.dispatch(i + "/saveShip", e)
                            },
                            "postOrder": function(t) {
                                t.preventDefault();
                                var e = $(this.$el),
                                    n = {};
                                this.invoiced && (n.invoice = {
                                    "content": e.find("[name='invioce_content']").val(),
                                    "kind": this.kind,
                                    "code": e.find("[name='invioce_code']").val(),
                                    "title": e.find("[name='invioce_title']").val()
                                }), n.remark = e.find("[name='remark']").val(), n.shipping_id = this.$store.state[i].ship || e.find("[name='shipping']:checked").val(), n.shipping_id && this.$store.dispatch(i + "/post", n)
                            }
                        }), a.mounted = function() {}, a.module = i, e.initComp(a)
                    }
                    e.initVm($(t.par), {
                        "mounted": function() {
                            var e = f.getUrlParam("key");
                            n && this.$store.commit(i + "/setData", {
                                "url": n
                            }), this.$store.dispatch(i + "/load", "?key=" + e), t.restUrl && this.$store.commit(i + "/set", {
                                "restUrl": t.restUrl
                            }), t.shipUrl && this.$store.commit(i + "/set", {
                                "shipUrl": t.shipUrl
                            }), t.invoiceUrl && this.$store.commit(i + "/set", {
                                "invoiceUrl": t.invoiceUrl
                            })
                        }
                    })
                }
            },
            "initVm": function(t, e) {
                var i = p;
                t.each(function() {
                    i.ignore(this);
                    new Vue({
                        "el": this,
                        "store": i.store,
                        "computed": e.computed || {},
                        "mounted": function() {
                            this.toggle(), e.mounted.call(this)
                        },
                        "methods": Object.assign({}, e.methods, Vuex.mapActions(["logout", "login"]), {
                            "toggle": function() {
                                var t = $(this.$el).find(".top_cart"),
                                    e = $(this.$el).find(".shop_cart");
                                e && $(e).off("click").on("click", function(e) {
                                    $(t).toggleClass("c-initHide")
                                })
                            }
                        })
                    })
                })
            },
            "initComp": function(t) {
                if (t.name) {
                    var e = p,
                        i = t.t.clone();
                    e.ignore(i), i.removeAttr("is").removeAttr("v-for").removeAttr("class");
                    var n = Vue.compile(i.prop("outerHTML"));
                    t.t.empty(), Vue.options.components[t.name] || Vue.component(t.name, {
                        "render": n.render,
                        "staticRenderFns": n.staticRenderFns,
                        "props": t.props,
                        "computed": t.computed,
                        "mounted": t.mounted,
                        "methods": Object.assign({}, {
                            "dispatch": function(e, i) {
                                this.$store.dispatch(t.module + "/" + e, i)
                            },
                            "commit": function(e, i) {
                                this.$store.commit(t.module + "/" + e, i)
                            }
                        }, t.methods)
                    })
                }
            },
            "initModule": function(t) {
                var e = p;
                if (t && !e.store.state[t]) switch (t) {
                    case "cart":
                        e.store.registerModule(t, r["default"]);
                        break;
                    case "sku":
                        e.store.registerModule(t, a["default"]);
                        break;
                    case "order":
                        e.store.registerModule(t, c["default"])
                }
            },
            "getEl": function(t) {
                var e = p,
                    i = $(t).find("[cv-component]"),
                    n = {};
                n.type = $(t).attr("fn-type"), n.url = $(t).attr("fn-url"), n.par = t;
                var o = $(t).attr("online");
                o != undefined && (n.online = o);
                var a = $(t).attr("class");
                $(t).attr("cv-store") ? n.module = $(t).attr("cv-store") : -1 !== a.indexOf("cv-base") ? n.module = "" : -1 !== a.indexOf("cv-cart") ? n.module = "cart" : -1 !== a.indexOf("cv-order") ? n.module = "order" : -1 !== a.indexOf("cv-sku") && (n.module = "sku"), e.initModule(n.module);
                var s = $(t).find("[fn-url]");
                if (s.length)
                    for (var r = 0; r < s.length; r++) {
                        var l = $(s[r]).attr("fn-type"),
                            c = $(s[r]).attr("fn-url");
                        switch (l) {
                            case "preorder_add":
                            case "order_add":
                                n.restUrl = c;
                                break;
                            case "shipping_list":
                                n.shipUrl = c;
                                break;
                            case "invoice_info":
                                n.invoiceUrl = c
                        }
                        $(s[r]).removeAttr("fn-url")
                    }
                var d = void 0,
                    u = void 0;
                if (i.length)
                    for (var h = 0; h < i.length; h++)
                        if (!i[h].attr("is")) {
                            var f = _g.uuid(3);
                            $(i[h]).attr("is", f).removeAttr("cv-component")
                        }
                return d = $(t).find("[is]"), u = e.getData(d, []), $(t).removeAttr("fn-url"), u.length && (n.data = u), n
            },
            "getData": function(t, e) {
                var i = p;
                e || (e = []);
                for (var n = 0; n < t.length; n++) {
                    var o = t[n],
                        a = $(o).find("[is]");
                    a.length ? e = i.getData(a, e) : function() {
                        var t = $(o).attr("is");
                        _.find(e, function(e) {
                            return e.name == t
                        }) || e.push({
                            "name": t,
                            "t": $(o)
                        })
                    }()
                }
                return e
            },
            "ignore": function(t) {
                var e = $(t).find(".cv-ignore");
                _.each(e, function(t) {
                    "LI" === $(t).prop("tagName") && $(t).siblings().remove()
                })
            }
        }
}, function(t, e, i) {
    "use strict";
    Object.defineProperty(e, "__esModule", {
        "value": !0
    });
    var n = i(5),
        o = function(t) {
            return t && t.__esModule ? t : {
                "default": t
            }
        }(n),
        a = i(1),
        s = function(t) {
            if (t && t.__esModule) return t;
            var e = {};
            if (null != t)
                for (var i in t) Object.prototype.hasOwnProperty.call(t, i) && (e[i] = t[i]);
            return e["default"] = t, e
        }(a),
        r = {};
    r.state = {
        "collection": {
            "data": {},
            "url": "",
            "price": "",
            "origin_price": "",
            "currentattr": "",
            "attrs": [],
            "volume": ""
        }
    }, r.getters = {}, r.actions = {
        "getAttrs": function(t) {
            var e = t.commit,
                i = t.state,
                n = i.collection.data,
                o = void 0;
            o = _.map(n, function(t) {
                return {
                    "attr": t.attr,
                    "sku_id": t.sku_id
                }
            }), e("setData", {
                "attrs": o
            })
        },
        "getData": function(t) {
            var e = t.dispatch,
                i = t.commit,
                n = t.state,
                o = n.collection.data,
                a = void 0;
            n.collection.currentattr ? a = _.find(o, function(t) {
                return t.sku_id == n.collection.currentattr
            }) : (i("setData", {
                "currentattr": o[0].sku_id
            }), a = o[0]), e("getAttrs"), i("setData", a)
        },
        "switchAttr": function(t, e) {
            var i = t.dispatch,
                n = t.commit;
            t.state;
            n("setData", {
                "currentattr": e
            }), i("getData")
        }
    }, r.mutations = {};
    var l = s.merge(o["default"], r);
    e["default"] = l
}, function(t, e, i) {
    "use strict";
    Object.defineProperty(e, "__esModule", {
        "value": !0
    });
    e.info_dialog = "<div class='eshopdialog'><div class='modal c-modal c-dialog-2 c-dialog-open'> <div class='modal-dialog c-modal-dialog dialogwrap_GAieLs'> <div class='modal-content c-modal-content dialogcontent_ythHsz'> <div class='modal-header c-modal-header dialogheader_0tOzfU'> <button class='close dialog-close c-defaultbutton' data-dismiss='modal' type='button'> <span class='sr-only c-span'> close</span> </button> <h4 class='modal-title c-heading heading_upIJrJ' v-text='title'> </h4> </div> <div class='modal-body c-modal-body'> <p class='c-paragraph paragraph_xeXy5L' v-text='content'> </p> </div> <div class='modal-footer c-modal-footer dialogfooter_H2tgAL'> <a class='dialog__btn link-black c-linkblock linkblock_vdBk6O'> <p class='c-paragraph paragraph_vwSJux' v-if='cancel' v-on:click='_close'> 取消</p> </a> <a class='dialog__btn c-linkblock linkblock_vdBk6O'> <p class='c-paragraph paragraph_vwSJux' v-if='confirm' v-on:click='_confirm'> 确认</p> </a> </div> </div> </div> </div></div>", e.wx_dialog = "<div class='modal dialog_EuuIUb c-modal c-dialog-2 wx_dialog' data-c_e_id='dialog_0344bb5a'> <div class='modal-dialog c-modal-dialog dialogwrap_GAieLs'><div class='modal-content c-modal-content dialogcontent_ythHsz'><div class='modal-header c-modal-header dialogheader_0tOzfU'><button class='close dialog-close c-defaultbutton' data-dismiss='modal' type='button'><span class='sr-only c-span'>close</span></button><h4 class='modal-title text-success c-heading heading_upIJrJ'>微信扫码支付</h4><button class='close dialog-close c-defaultbutton defaultbutton_8NcI0g' data-dismiss='modal' type='button'><span aria-hidden='True' class='c-span'>x</span><span class='sr-only c-span'>close</span></button></div><div class='modal-body c-modal-body dialogbody_vUk3DL'><img class='c-image image_SQgZmQ wx_qrcode' src='http://o3bnyc.creatby.com/diazo/images/image-placeholder.svg'/><p class='c-paragraph paragraph_xeXy5L'>请用微信扫一扫上方二维码完成支付。</p><p class='c-paragraph paragraph_xeXy5L'>完成扫描支付后，若没有自动跳转，请点击下方按钮</p></div><div class='modal-footer c-modal-footer dialogfooter_H2tgAL'><a class='dialog__btn c-linkblock linkblock_vdBk6O completepay' href='#'><p class='c-paragraph paragraph_vwSJux'>完成支付</p></a></div></div></div></div>"
}, function(t, e, i) {
    "use strict";
    Object.defineProperty(e, "__esModule", {
        "value": !0
    });
    var n = i(5),
        o = function(t) {
            return t && t.__esModule ? t : {
                "default": t
            }
        }(n),
        a = i(1),
        s = function(t) {
            if (t && t.__esModule) return t;
            var e = {};
            if (null != t)
                for (var i in t) Object.prototype.hasOwnProperty.call(t, i) && (e[i] = t[i]);
            return e["default"] = t, e
        }(a),
        r = {};
    r.namespaced = !0, r.state = {
        "collection": {
            "data": [],
            "url": "",
            "order": [],
            "nums": 1,
            "isall": !0
        },
        "restUrl": ""
    }, r.getters = {
        "total": function(t, e, i) {
            var n = 0;
            return _.each(t.collection.order, function(t) {
                n += Number(t.price * t.num)
            }), n
        }
    }, r.actions = {
        "load": function(t, e) {
            var i = t.commit,
                n = t.state;
            t.dispatch;
            return new Promise(function(t, e) {
                var o = n.collection.url;
                Vue.http.get(o).then(function(e) {
                    if (200 == e.body.code) {
                        var n = e.body.data.results;
                        for (var o in n) n[o].ischecked = !0;
                        i("setData", {
                            "data": n,
                            "order": $.extend(!0, [], n)
                        }), t && t()
                    } else s.dealBadRequest(e)
                }, function(t) {
                    e && e(), s.dealBadRequest(t)
                })
            })
        },
        "addCart": function(t, e) {
            var i = t.state,
                n = t.rootState,
                o = t.dispatch,
                a = {
                    "sku_id": n.sku.collection.currentattr || n.sku.collection.data[0].sku_id,
                    "num": i.collection.nums
                },
                r = i.collection.url;
            r && Vue.http.post(r, a).then(function(t) {
                200 === t.body.code ? (e && e(), o("load"), o("sku/load", null, {
                    "root": !0
                })) : s.dealBadRequest(t)
            }, function(t) {
                s.dealBadRequest(t)
            })
        },
        "switchNum": function(t, e) {
            var i = t.commit,
                n = t.state,
                o = t.rootState;
            if ("up" === e) {
                if (n.collection.nums >= o.sku.collection.volume) return;
                i("setData", {
                    "nums": parseInt(n.collection.nums) + 1
                })
            } else {
                if (n.collection.nums <= 1) return;
                i("setData", {
                    "nums": parseInt(n.collection.nums) - 1
                })
            }
        },
        "addOther": function(t, e) {
            var i = (t.commit, t.state);
            e === undefined && (e = !0);
            for (var n = i.collection.data, o = 0; o < n.length; o++) n[o].ischecked = e
        },
        "switchOrderNum": function(t, e) {
            var i = t.state,
                n = (t.commit, t.dispatch);
            e || (e = {});
            for (var o = e.id, a = e.type, r = 0; r < i.collection.data.length; r++) {
                if ("break" === function(t) {
                        var e = i.collection.data[t];
                        if (e.id === o) return n("update", {
                            "id": o,
                            "type": a
                        }).then(function() {
                            var s = void 0;
                            s = "up" === a ? parseInt(e.num) + 1 : parseInt(e.num) - 1, i.collection.data[t].num = s, n("updateOrderNum", {
                                "id": o,
                                "num": s
                            })
                        }, function(t) {
                            s.dealBadRequest(t)
                        }), "break"
                    }(r)) break
            }
        },
        "update": function(t, e) {
            var i = t.state;
            return new Promise(function(t, n) {
                var o = i.collection.url + e.id;
                e && Vue.http.put(o, {
                    "type": e.type
                }).then(function(e) {
                    200 === e.body.code ? t && t() : n && n(e)
                }, function(t) {
                    n && n(t)
                })
            })
        },
        "remove": function(t, e) {
            var i = t.state,
                n = t.dispatch;
            e && s.dialog({
                "title": "操作确认",
                "content": "确认移除该商品？",
                "callback": function() {
                    var t = i.collection.url + e;
                    Vue.http["delete"](t).then(function(t) {
                        if (200 === t.body.code) {
                            for (var o = i.collection.data, a = 0; a < o.length; a++)
                                if (o[a].id == e) {
                                    o.splice(a, 1), n("orderRemove", e);
                                    break
                                }
                        } else s.dealBadRequest(t)
                    }, function(t) {
                        s.dealBadRequest(t)
                    })
                }
            })
        },
        "addOrder": function(t, e) {
            var i = t.state,
                n = t.commit,
                o = t.dispatch;
            if ("all" === e) i.collection.isall ? (o("addOther", !1), n("setData", {
                "order": [],
                "isall": !1
            })) : (o("addOther"), n("setData", {
                "order": $.extend(!0, [], i.collection.data),
                "isall": !0
            }));
            else
                for (var a = i.collection.order, s = 0; s < i.collection.data.length; s++) {
                    var r = i.collection.data[s];
                    if (r.id === e) {
                        var l = _.find(a, function(t) {
                            return t.id === e
                        });
                        if (l) {
                            r.ischecked = !1;
                            for (var c = 0; c < a.length; c++)
                                if (a[c].id === e) {
                                    a.splice(c, 1);
                                    break
                                }
                        } else r.ischecked = !0, a.push(r);
                        break
                    }
                }
        },
        "updateOrderNum": function(t, e) {
            for (var i = t.state, n = t.commit, o = i.collection.order, a = 0; a < o.length; a++)
                if (o[a].id === e.id) {
                    o[a].num = e.num;
                    break
                }
            n("setData", {
                "order": o
            })
        },
        "orderRemove": function(t, e) {
            for (var i = t.state, n = t.commit, o = i.collection.order, a = 0; a < o.length; a++)
                if (o[a].id === e) {
                    o.splice(a, 1);
                    break
                }
            n("setData", {
                "order": o
            })
        },
        "placeOrder": function(t, e) {
            var i = t.state,
                n = i.restUrl,
                o = i.collection.order,
                a = [];
            if (o.length) {
                for (var r = 0; r < o.length; r++) a.push(o[r].id);
                n && Vue.http.post(n, {
                    "data": a
                }).then(function(t) {
                    if (200 === t.body.code) {
                        var e = t.body.data.results[0].next_url;
                        e && (window.location.href = e)
                    } else s.dealBadRequest(t)
                }, function(t) {
                    s.dealBadRequest(t)
                })
            }
        }
    }, r.mutations = {};
    var l = s.merge(o["default"], r);
    e["default"] = l
}, function(t, e, i) {
    "use strict";
    Object.defineProperty(e, "__esModule", {
        "value": !0
    });
    var n = i(5),
        o = function(t) {
            return t && t.__esModule ? t : {
                "default": t
            }
        }(n),
        a = i(1),
        s = function(t) {
            if (t && t.__esModule) return t;
            var e = {};
            if (null != t)
                for (var i in t) Object.prototype.hasOwnProperty.call(t, i) && (e[i] = t[i]);
            return e["default"] = t, e
        }(a),
        r = {};
    r.state = {
        "collection": {
            "data": [{
                "shipping": {},
                "items": []
            }],
            "url": "",
            "currentShip": {},
            "showShip": !1
        },
        "restUrl": "",
        "shipUrl": "",
        "invoiceUrl": "",
        "ship": ""
    }, r.getters = {}, r.actions = {
        "saveShip": function(t, e) {
            var i = t.state,
                n = i.shipUrl,
                o = i.collection.currentShip.id;
            n && !o ? Vue.http.post(n, e).then(function(t) {
                if (200 === t.body.code) {
                    var e = t.body.data.results[0];
                    i.collection.showShip = !1, i.collection.currentShip = {}, i.collection.data[0].shipping.push(e)
                } else s.dealBadRequest(t)
            }, function(t) {
                s.dealBadRequest(t)
            }) : Vue.http.put(n + o, e).then(function(t) {
                if (200 === t.body.code) {
                    i.collection.showShip = !1, i.collection.currentShip = {};
                    for (var e = t.body.data.results[0], n = 0; n < i.collection.data[0].shipping.length; n++) {
                        if (i.collection.data[0].shipping[n].id === e.id) {
                            i.collection.data[0].shipping.splice(n, 1, e);
                            break
                        }
                    }
                } else s.dealBadRequest(t)
            }, function(t) {
                s.dealBadRequest(t)
            })
        },
        "removeShip": function(t, e) {
            var i = t.state;
            if (!e) return "";
            s.dialog({
                "title": "操作确认",
                "content": "确认删除配送地址？",
                "callback": function() {
                    var t = i.shipUrl;
                    t && Vue.http["delete"](t + e).then(function(t) {
                        if (200 === t.body.code)
                            for (var n = 0; n < i.collection.data[0].shipping.length; n++) {
                                var o = i.collection.data[0].shipping[n];
                                if (o.id === e) {
                                    i.collection.data[0].shipping.splice(n, 1);
                                    break
                                }
                            } else s.dealBadRequest(t)
                    }, function(t) {
                        s.dealBadRequest(t)
                    })
                }
            })
        },
        "post": function(t, e) {
            var i = t.state,
                n = (t.commit, i.restUrl);
            e || (e = {}), e.carts = _.map(i.collection.data[0].carts, function(t) {
                return t.id
            }), e.carts.length && n && Vue.http.post(n, e).then(function(t) {
                if (200 === t.body.code) {
                    var e = t.body.data.results;
                    window.location.href = "/cpay/" + e[0].id
                } else s.dealBadRequest(t)
            }, function(t) {
                s.dealBadRequest(t)
            })
        },
        "orderOperate": function(t, e) {
            var i = t.state,
                n = t.commit;
            if (e) {
                var o = e.status,
                    a = i.collection.url,
                    r = i.collection.data; - 1 === a.indexOf(e.id) && (a += e.id), Vue.http.put(a, {
                    "status": o
                }).then(function(t) {
                    if (200 === t.body.code) {
                        for (var i = 0; i < r.length; i++)
                            if (r[i].id === e.id) {
                                r.splice(i, 1, t.body.data.results[0]), n("setData", r);
                                break
                            }
                    } else s.dealBadRequest(t)
                }, function(t) {
                    s.dealBadRequest(t)
                })
            }
        }
    };
    var l = s.merge(o["default"], r);
    e["default"] = l
}, function(t, e, i) {
    "use strict";

    function n(t) {
        if (null == t) throw new TypeError("Cannot destructure undefined")
    }
    Object.defineProperty(e, "__esModule", {
        "value": !0
    });
    var o = i(5),
        a = function(t) {
            return t && t.__esModule ? t : {
                "default": t
            }
        }(o),
        s = i(1),
        r = {};
    r.state = {
        "collection": {
            "data": [{}],
            "url": "",
            "current": ""
        }
    }, r.actions = {
        "pick": function(t, e) {
            (0, t.commit)("setData", {
                "current": e
            })
        },
        "pay": function(t) {
            var e = t.state,
                i = e.collection.url,
                n = e.collection.current,
                o = e.collection.data[0].id;
            Vue.http.post(i, {
                "id": n
            }).then(function(t) {
                if (200 === t.body.code) {
                    var e = t.body.data.results[0].next,
                        i = t.body.data.results[0].wx_pay_image;
                    e ? window.location.href = e : i && (0, s.wxdialog)(i, o)
                } else(0, s.dealBadRequest)(t)
            }, function(t) {
                (0, s.dealBadRequest)(t)
            })
        },
        "toDetail": function(t, e) {
            n(t), e && (window.location.href = "/corderdetail/" + e)
        }
    }, e["default"] = (0, s.merge)(a["default"], r)
}, function(t, e, i) {
    "use strict";
    Object.defineProperty(e, "__esModule", {
        "value": !0
    });
    var n = i(1),
        o = function(t) {
            if (t && t.__esModule) return t;
            var e = {};
            if (null != t)
                for (var i in t) Object.prototype.hasOwnProperty.call(t, i) && (e[i] = t[i]);
            return e["default"] = t, e
        }(n),
        a = {};
    a.init = function() {
        var t = coolsite_play.doc && coolsite_play.doc.find(".mob_login").eq(0),
            e = coolsite_play.doc && coolsite_play.doc.find("[fn-type='hint_info']").eq(0);
        if (t && t.length) {
            var i = $(t).find("[fn-type='login_sms_verify']"),
                n = $(t).find("[fn-type='login_mob_submit']"),
                a = $(i).attr("fn-url"),
                s = $(n).attr("fn-url");
            $(i).off("click").on("click", function(i) {
                i.preventDefault();
                var n = $(this),
                    o = $(t).find("[name='username']").val(),
                    s = /^1[3|4|5|7|8]\d{9}$/;
                return o.match(s) ? (Vue.http.post(a, {
                    "username": o
                }, {
                    "emulateJSON": !0
                }).then(function(t) {
                    if (200 == t.body.code) {
                        var i = 60,
                            o = null;
                        n.attr("disabled", !0), o = window.setInterval(function() {
                            n.text(i + "s后可以重新发送"), --i < 1 && (n.text("获取短信验证码"), window.clearInterval(o), n.removeAttr("disabled"))
                        }, 1e3)
                    } else {
                        var a = t.body.msg;
                        $(e).text(a)
                    }
                }, function() {
                    $(e).text("系统错误")
                }), !1) : ($(e).text("请填入正确的手机号"), !1)
            }), $(n).off("click").on("click", function(i) {
                i.preventDefault();
                var n = $(t).find("[name='username']").val(),
                    a = $(t).find("[name='phone_code']").val(),
                    r = $(t).find("[name='captcha_code']").val(),
                    l = /^1[3|4|5|7|8]\d{9}$/;
                if (!n.match(l)) return $(e).text("请填入正确的手机号"), !1;
                var c = {
                    "username": n,
                    "phone_code": a,
                    "captcha_code": r
                };
                return Vue.http.post(s, c, {
                    "emulateJSON": !0
                }).then(function(t) {
                    if (200 == t.body.code) {
                        var i = o.getUrlParam("next");
                        window.location.href = i || "/"
                    } else {
                        var n = t.body.msg;
                        $(e).text(n)
                    }
                }, function() {
                    $(e).text("系统错误")
                }), !1
            })
        }
    }, e["default"] = a
}, function(t, e, i) {
    "use strict";
    var n, o;
    ! function() {
        var a, s, r, l, c, d, u, h, f, p = {};
        s = window.document.documentElement, f = window.navigator.userAgent.toLowerCase(), p.ios = function() {
            return p.iphone() || p.ipod() || p.ipad()
        }, p.iphone = function() {
            return r("iphone")
        }, p.ipod = function() {
            return r("ipod")
        }, p.ipad = function() {
            return r("ipad")
        }, p.android = function() {
            return r("android")
        }, p.androidPhone = function() {
            return p.android() && r("mobile")
        }, p.androidTablet = function() {
            return p.android() && !r("mobile")
        }, p.blackberry = function() {
            return r("blackberry") || r("bb10") || r("rim")
        }, p.blackberryPhone = function() {
            return p.blackberry() && !r("tablet")
        }, p.blackberryTablet = function() {
            return p.blackberry() && r("tablet")
        }, p.windows = function() {
            return r("windows")
        }, p.mac = function() {
            return r("mac")
        }, p.linux = function() {
            return r("linux")
        }, p.windowsPhone = function() {
            return p.windows() && r("phone")
        }, p.windowsTablet = function() {
            return p.windows() && r("touch")
        }, p.fxos = function() {
            return (r("(mobile;") || r("(tablet;")) && r("; rv:")
        }, p.fxosPhone = function() {
            return p.fxos() && r("mobile")
        }, p.fxosTablet = function() {
            return p.fxos() && r("tablet")
        }, p.meego = function() {
            return r("meego")
        }, p.mobile = function() {
            return p.androidPhone() || p.iphone() || p.ipod() || p.windowsPhone() || p.blackberryPhone() || p.fxosPhone() || p.meego()
        }, p.tablet = function() {
            return p.ipad() || p.androidTablet() || p.blackberryTablet() || p.windowsTablet() || p.fxosTablet()
        }, p.msie = function() {
            return p.uaMatch().browser.msie || !!navigator.userAgent.match(/Trident\/7\./)
        }, p.portrait = function() {
            return 90 !== Math.abs(window.orientation)
        }, p.landscape = function() {
            return 90 === Math.abs(window.orientation)
        }, p.noConflict = function() {
            return this
        }, p.svg = function() {
            return document.implementation.hasFeature("http://www.w3.org/TR/SVG11/feature#Shape", "1.1")
        }, p.online = function(t, e, i) {
            var n = new Image;
            n.onload = function() {
                e && e.constructor == Function && e()
            }, n.onerror = function() {
                i && i.constructor == Function && i()
            }, n.src = t + "?t=" + _g.uuid()
        }, p.screenSize = function() {
            var t = window,
                e = document,
                i = e.documentElement,
                n = e.getElementsByTagName("body")[0];
            return {
                "x": t.innerWidth || i.clientWidth || n.clientWidth,
                "y": t.innerHeight || i.clientHeight || n.clientHeight
            }
        }, p.isWeixin = function() {
            return !!/micromessenger/.test(navigator.userAgent.toLowerCase())
        }, p.uaMatch = function() {
            var t = navigator.userAgent.toLowerCase(),
                e = /(chrome)[ \/]([\w.]+)/.exec(t) || /(webkit)[ \/]([\w.]+)/.exec(t) || /(opera)(?:.*version|)[ \/]([\w.]+)/.exec(t) || /(msie) ([\w.]+)/.exec(t) || t.indexOf("compatible") < 0 && /(mozilla)(?:.*? rv:([\w.]+)|)/.exec(t) || [],
                i = {
                    "browser": e[1] || "",
                    "version": e[2] || "0"
                };
            return e[1] && (i[e[1]] = !0), i
        }, r = function(t) {
            return -1 !== f.indexOf(t)
        }, c = function(t) {
            var e;
            return e = new RegExp(t, "i"), s.className.match(e)
        }, a = function(t) {
            if (!c(t)) return s.className += " " + t
        }, u = function(t) {
            if (c(t)) return s.className = s.className.replace(t, "")
        };
        var m = function() {
            p.ios() ? p.ipad() ? a("ios ipad tablet") : p.iphone() ? a("ios iphone mobile") : p.ipod() && a("ios ipod mobile") : a(p.android() ? p.androidTablet() ? "android tablet" : "android mobile" : p.blackberry() ? p.blackberryTablet() ? "blackberry tablet" : "blackberry mobile" : p.windows() ? p.windowsTablet() ? "windows tablet" : p.windowsPhone() ? "windows mobile" : "desktop" : p.fxos() ? p.fxosTablet() ? "fxos tablet" : "fxos mobile" : p.meego() ? "meego mobile" : "desktop")
        };
        l = function() {
            return p.landscape() ? (u("portrait"), a("landscape")) : (u("landscape"), a("portrait"))
        }, h = "onorientationchange" in window, d = h ? "orientationchange" : "resize", window.addEventListener ? window.addEventListener(d, l, !1) : window.attachEvent ? window.attachEvent(d, l) : window[d] = l, l(), p.initDom = m, window._g_device = p, n = [i(2)], (o = function() {
            return window._g.device = _g_device, window._g.device
        }.apply(e, n)) !== undefined && (t.exports = o)
    }(window)
}, function(t, e, i) {
    "use strict";
    var n, o;
    ! function() {
        var a = {
            "bind": function(t) {
                var e, i, n = 0,
                    o = 0;
                t.callback || (t.callback = function() {
                    return !0
                }), $(t.el).hammer().on("dragstart", function(i) {
                    t.canDrag && !t.canDrag(i) || (t.dragstart && t.dragstart(i), e = !0)
                }), $(t.el).hammer().on("dragleft", function(o) {
                    if (null == i && (i = 1), (!t.canDragX || t.canDragX(o)) && _g.dragcontrol._testDragEventAccess(o, i)) return e = !0, $.zoom && 1 != $.zoom && (o.gesture.deltaX = o.gesture.deltaX / $.zoom), n = o.gesture.deltaX, t.dragleft && t.dragleft(o), o.gesture.preventDefault(), !1
                }), $(t.el).hammer().on("dragright", function(o) {
                    if (null == i && (i = 1), (!t.canDragX || t.canDragX(o)) && _g.dragcontrol._testDragEventAccess(o, i)) return e = !0, $.zoom && 1 != $.zoom && (o.gesture.deltaX = o.gesture.deltaX / $.zoom), n = o.gesture.deltaX, t.dragright && t.dragright(o), o.gesture.preventDefault(), !1
                }), $(t.el).hammer().on("dragup", function(n) {
                    if (null == i && (i = 2), (!t.canDragY || t.canDragY(n)) && _g.dragcontrol._testDragEventAccess(n, i)) return e = !0, $.zoom && 1 != $.zoom && (n.gesture.deltaY = n.gesture.deltaY / $.zoom), o = n.gesture.deltaY, t.dragup && t.dragup(n), n.gesture.preventDefault(), !1
                }), $(t.el).hammer().on("dragdown", function(n) {
                    if (null == i && (i = 2), (!t.canDragY || t.canDragY(n)) && _g.dragcontrol._testDragEventAccess(n, i)) return e = !0, $.zoom && 1 != $.zoom && (n.gesture.deltaY = n.gesture.deltaY / $.zoom), o = n.gesture.deltaY, t.dragdown && t.dragdown(n), n.gesture.preventDefault(), !1
                }), $(t.el).hammer().on("dragend", function(a) {
                    if (e || (i = null), (!t.canDrag || t.canDrag(a)) && _g.dragcontrol._testDragEventAccess(a, i)) return (1 == i && n || 2 == i && o) && ($.zoom && 1 != $.zoom && (2 == i && o && (a.gesture.deltaY = a.gesture.deltaY / $.zoom), 1 == i && n && (a.gesture.deltaX = a.gesture.deltaX / $.zoom)), t.dragend && t.dragend(a)), e = !1, i = null, n = 0, o = 0, a.gesture.preventDefault(), !1
                })
            },
            "_testDragEventAccess": function(t, e) {
                var i = !0;
                return 1 == e && ("dragup" != t.type && "dragdown" != t.type || (i = !1)), 2 == e && ("dragleft" != t.type && "dragright" != t.type || (i = !1)), "dragend" == t.type && (e || (i = !1)), i
            }
        };
        n = [i(2), i(6)], (o = function() {
            return window._g.dragcontrol = a, window._g.dragcontrol
        }.apply(e, n)) !== undefined && (t.exports = o)
    }(window)
}, function(t, e, i) {
    "use strict";
    var n, o;
    ! function() {
        var a = {
            "support": function() {
                return !!document.createElement("video").canPlayType
            }(),
            "medias": [],
            "collect": function(t, e) {
                _g.html5media.support && (t || (t = document), e || (e = "id"), $(t).find("video,audio").each(function() {
                    var t = {
                        "media": this,
                        "duration": 0,
                        "currentTime": 0,
                        "timer": 0,
                        "seekx": 0,
                        "seekPos": 0,
                        "buffered": 0,
                        "timerBuffer": 0,
                        "type": "VIDEO" == this.tagName ? "video" : "audio",
                        "autoplay": $(this).attr("autoplay"),
                        "id": $(this).attr(e)
                    };
                    _g.html5media.medias.push(t), this.addEventListener("ended", function() {}, !0), this.addEventListener("play", function() {}, !0), this.addEventListener("timeupdate", function() {}, !0), this.addEventListener("pause", function() {}, !0)
                }))
            },
            "findById": function(t) {
                return _g.html5media.support ? _.find(_g.html5media.medias, function(e) {
                    return e.id == t
                }) : null
            },
            "play": function(t) {
                var e = _g.html5media.findById(t);
                try {
                    e.media.play()
                } catch (i) {}
            },
            "pause": function(t) {
                var e = _g.html5media.findById(t);
                try {
                    e.media.pause()
                } catch (i) {}
            },
            "pauseAll": function() {
                _.each(_g.html5media.medias, function(t) {
                    _g.html5media.pause(t.id)
                })
            },
            "stopAll": function() {
                _.each(_g.html5media.medias, function(t) {
                    _g.html5media.stop(t.id)
                })
            },
            "stop": function(t) {
                var e = _g.html5media.findById(t);
                try {
                    e.media.pause(), e.media.currentTime = 0
                } catch (i) {}
            },
            "toggle": function(t) {
                var e = _g.html5media.findById(t);
                try {
                    e.media.paused ? e.media.play() : e.media.pause()
                } catch (i) {}
            }
        };
        n = [i(2), i(3)], (o = function() {
            return window._g.html5media = a, window._g.html5media
        }.apply(e, n)) !== undefined && (t.exports = o)
    }(window)
}, function(module, exports, __webpack_require__) {
    "use strict";

    function _defineProperty(t, e, i) {
        return e in t ? Object.defineProperty(t, e, {
            "value": i,
            "enumerable": !0,
            "configurable": !0,
            "writable": !0
        }) : t[e] = i, t
    }
    var __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__, _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
        return typeof t
    } : function(t) {
        return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
    };
    ! function() {
        var _g_mvc = {
            "createModel": function createModel(opts) {
                var defaults = {
                    "defaults": {},
                    "autoIndex": !0,
                    "autoUpdate": !0,
                    "autoRemove": !0,
                    "enableSync": !0,
                    "createUrl": null,
                    "updateUrl": null,
                    "removeUrl": null,
                    "fetchUrl": null,
                    "staticFetchUrl": null,
                    "staticRemoveUrl": null,
                    "staticCreateUrl": null,
                    "staticUpdateUrl": null,
                    "fetchUrlName": null,
                    "removeUrlName": null,
                    "createUrlName": null,
                    "updateUrlName": null,
                    "restful": !1,
                    "debug": !1,
                    "bindChange": null,
                    "bindRemove": null,
                    "callback": null,
                    "initView": null,
                    "patchKeys": null,
                    "initialize": function initialize() {
                        if (this.iViewlist = [], this.iCollectionlist = [], this.get("id")) this.preset();
                        else if (this.set("isNew", !0), this.autoIndex) {
                            var prefix = this.get("type") || this.get("iType") || "M";
                            this.set("id", prefix + "_" + _g.uuid()), this.preset()
                        } else this.save({}, {
                            "wait": !0,
                            "success": function success(model, response) {
                                var returned = eval(response);
                                "Success" != returned.Status && 200 != returned.code || model.set("id", returned.ID.toString()), model.preset()
                            }
                        })
                    },
                    "addView": function(t, e) {
                        if ("function" == typeof e && (this[t] = new e({
                                "model": this
                            })), "object" == (void 0 === e ? "undefined" : _typeof(e))) {
                            var i = _g.mvc.createView(e);
                            this[t] = new i({
                                "model": this
                            })
                        }
                        this[t] && this.iViewlist.push(this[t])
                    },
                    "addCollection": function(t, e) {
                        if ("function" == typeof e && (this[t] = new e), "object" == ("undefined" == typeof view ? "undefined" : _typeof(view))) {
                            var i = _g.mvc.createCollection(e);
                            this[t] = new i
                        }
                        this[t] && this.iCollectionlist.push(this[t])
                    },
                    "preset": function() {
                        this.callback && this.callback(this);
                        var t = this;
                        this.autoUpdate && this.on("change", function() {
                            t.updateAllViews()
                        }), this.autoRemove && this.on("destroy", function(t, e, i) {
                            t.removeAllViews(), t.bindRemove && t.bindRemove(t, i)
                        }), this.bindChange && this.bindChange(), this.initView && this.addView("iview", this.initView)
                    },
                    "updateAllViews": function() {
                        _.each(this.iViewlist, function(t) {
                            t.$el && t.update()
                        })
                    },
                    "removeView": function(t) {
                        this[t] && (this[t].$el.remove(), this.iViewlist = _.reject(this.iViewlist, function(e) {
                            return e == this[t]
                        }), this[t] = null)
                    },
                    "removeAllViews": function(t) {
                        _.each(this.iViewlist, function(e) {
                            e.$el && (t ? e.undelegateEvents() : e.$el.remove())
                        })
                    }
                };
                opts = opts ? $.extend(!0, {}, defaults, opts) : defaults;
                var Model = Backbone.Model.extend(opts);
                return Model
            },
            "createView": function(t) {
                var e, i = (e = {
                    "template": null,
                    "className": null,
                    "containment": null,
                    "wrap": null,
                    "wrapClassName": null,
                    "autoRender": !0,
                    "position": 1,
                    "parseData": null,
                    "callback": null,
                    "bindChange": null,
                    "parseTemplate": null,
                    "templateKey": null,
                    "templateName": null,
                    "afterRender": null,
                    "afterUpdate": null,
                    "initialize": function() {
                        _.bindAll(this), this.autoRender && this.render(), this.callback && this.callback(this)
                    },
                    "createEl": function() {
                        var t, e = this.model.toJSON();
                        return this.parseData && (e = this.parseData()), t = this.parseTemplate ? this.parseTemplate(this.template) : this.template, _g.renderT(t, e, this.templateKey, this.templateName)
                    },
                    "render": function(t, e) {
                        if (!this.model || !this.template) return !1;
                        if (!_g.domExist(this.$el)) {
                            if (!t && !this.containment) return !1;
                            t || (t = $(this.containment)), e || (e = this.position), this.wrap && !$(this.containment).is(this.wrap) && (0 == $(this.containment).children(this.wrap).length && $(this.containment).append(document.createElement(this.wrap)), t = $(this.containment).children(this.wrap), this.containment && this.wrapClassName && t.addClass(this.wrapClassName));
                            var i = this.createEl(),
                                n = i;
                            return this.setElement(n), 1 == e ? t.append(n) : t.prepend(n), this.className && this.$el.addClass(this.className), this.afterRender && this.afterRender(this), this
                        }
                        var i = this.createEl(),
                            n = i;
                        this.$el.replaceWith(n), this.setElement(n), this.afterUpdate && this.afterUpdate(this)
                    },
                    "update": function() {
                        this.render()
                    }
                }, _defineProperty(e, "afterUpdate", function() {
                    this.afterRender && this.afterRender(this)
                }), _defineProperty(e, "events", {}), e);
                return t = t ? $.extend(!0, {}, i, t) : i, Backbone.View.extend(t)
            },
            "createCollection": function(t) {
                var e = {
                    "enableSync": !1,
                    "fetchUrl": null,
                    "staticFetchUrl": null,
                    "saveUrl": null,
                    "staticSaveUrl": null,
                    "debug": !1,
                    "bindRemove": !1,
                    "bindReset": !0,
                    "bindAdd": null,
                    "callback": null,
                    "patchKeys": null,
                    "name": null,
                    "initialize": function() {
                        var t = this;
                        this.bindRemove && this.on("remove", function(e) {
                            "function" == typeof t.bindRemove ? t.bindRemove(e) : e.removeAllViews()
                        }), this.bindReset && this.on("reset", function(e, i) {
                            "function" == typeof t.bindReset ? t.bindReset(e, i) : _.each(i.previousModels, function(t) {
                                t.removeAllViews()
                            }), t.afterReset && t.afterReset(e, i)
                        }), this.bindAdd && this.on("add", function(e) {
                            t.bindAdd()
                        }), this.callback && this.callback(this)
                    },
                    "refreshView": function(t) {
                        var e = {
                            "containment": null,
                            "viewname": null
                        };
                        t = t ? $.extend({}, e, t) : e, this.length > 0 && (_.each(this.at(0).iViewlist, function(e) {
                            containment = t.containment || e.containment, containment && (e.wrap && !$(containment).is(e.wrap) ? $(containment).children(e.wrap).empty() : $(containment).empty())
                        }), this.each(function(e) {
                            t.containment && (e.iview.containment = t.containment), t.viewname ? e[viewname].update() : e.iview.update()
                        }))
                    },
                    "removeAllViews": function(t) {
                        this.each(function(e) {
                            e.removeAllViews(t)
                        })
                    }
                };
                return t = t ? $.extend(!0, {}, e, t) : e, Backbone.Collection.extend(t)
            }
        };
        __WEBPACK_AMD_DEFINE_ARRAY__ = [__webpack_require__(0), __webpack_require__(4), __webpack_require__(2)], (__WEBPACK_AMD_DEFINE_RESULT__ = function() {
            return window._g.mvc = _g_mvc, _g_mvc = undefined, window._g.mvc
        }.apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__)) !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__)
    }(window)
}, function(t, e, n) {
    "use strict";
    var o, a;
    ! function() {
        var s = function(t) {
            this.init(t)
        };
        s.prototype = {
            "isDraged": !1,
            "init": function(t) {
                var e = {
                    "containment": null,
                    "containmentClass": "c-transition-containment",
                    "perspectiveClass": "c-perspective",
                    "itemClass": "c-transition-item",
                    "currentClass": "c-transition-current",
                    "leftClass": "c-transition-left",
                    "rightClass": "c-transition-right",
                    "upClass": "c-transition-up",
                    "downClass": "c-transition-down",
                    "activeClass": "c-transition-active",
                    "topClass": "c-transition-top",
                    "repeat": !1,
                    "direction": 0,
                    "type": 1,
                    "duration": 1e3,
                    "onStart": null,
                    "onEnd": null,
                    "control": !0,
                    "autoplay": !1,
                    "width": null,
                    "height": null,
                    "disableControlled": !1,
                    "autoplayDirection": -1,
                    "autoplayAxis": null
                };
                return this.opts = t ? $.extend(!0, {}, e, t) : e, !!this.opts.containment && ($(this.opts.containment).addClass(this.opts.containmentClass), _.bindAll(this), this.opts.control && (this.control(), this.opts.disableControlled && this.disableControl()), this.opts.autostart ? (this.timerDisabled = !1, this.timerstart({})) : this.timerDisabled = !0, this)
            },
            "disableControlled": !1,
            "disableControl": function() {
                this.disableControlled = !0
            },
            "enableControl": function() {
                this.disableControlled = !1
            },
            "control": function() {
                var t = this;
                _g.dragcontrol.bind({
                    "el": this.opts.containment,
                    "dragstart": function(e) {
                        t.disableControlled || t.start(e)
                    },
                    "dragleft": function(e) {
                        t.disableControlled || (t.dragX(e), t.opts.onStart && t.opts.onStart(t.currentItem.index(), t.activeItem.index()))
                    },
                    "dragright": function(e) {
                        t.disableControlled || (t.dragX(e), t.opts.onStart && t.opts.onStart(t.currentItem.index(), t.activeItem.index()))
                    },
                    "dragup": function(e) {
                        t.disableControlled || (t.dragY(e), t.opts.onStart && t.opts.onStart(t.currentItem.index(), t.activeItem.index()))
                    },
                    "dragdown": function(e) {
                        t.disableControled || (t.dragY(e), t.opts.onStart && t.opts.onStart(t.currentItem.index(), t.activeItem.index()))
                    },
                    "dragend": function(e) {
                        if (!t.disableControlled) {
                            if (t.direction && !t.timerDisabled) {
                                var i = "x" == t.direction ? e.gesture.deltaX : e.gesture.deltaY;
                                t.TimerDirection = i > 0 ? 1 : -1
                            }
                            t.dragEnd(e)
                        }
                    },
                    "canDragX": function() {
                        return !t.opts.autoplayAxis || "x" == t.opts.autoplayAxis
                    },
                    "canDragY": function() {
                        return !t.opts.autoplayAxis || "y" == t.opts.autoplayAxis
                    }
                })
            },
            "stashitemClass": function() {
                $(this.opts.containment).find("." + this.opts.itemClass).css({
                    "transform": "",
                    "-moz-transform": "",
                    "-webkit-transform": "",
                    "-o-transform": "",
                    "-ms-transform": "",
                    "opacity": ""
                }), this.stashClass = {
                    "current": $(this.opts.containment).find("." + this.opts.currentClass).attr("style"),
                    "left": $(this.opts.containment).find("." + this.opts.leftClass).attr("style"),
                    "right": $(this.opts.containment).find("." + this.opts.rightClass).attr("style"),
                    "up": $(this.opts.containment).find("." + this.opts.upClass).attr("style"),
                    "down": $(this.opts.containment).find("." + this.opts.downClass).attr("style")
                }, this.stashed = !0
            },
            "recoveritemClass": function() {
                if (this.stashed) try {
                    this.currentItem.attr("style", this.stashClass.current || ""), this.activeItem.hasClass(this.opts.leftClass) ? this.activeItem.attr("style", this.stashClass.left || "") : this.activeItem.hasClass(this.opts.rightClass) ? this.activeItem.attr("style", this.stashClass.right || "") : this.activeItem.hasClass(this.opts.upClass) ? this.activeItem.attr("style", this.stashClass.up || "") : this.activeItem.hasClass(this.opts.downClass) && this.activeItem.attr("style", this.stashClass.down || "")
                } catch (t) {}
                $(this.opts.containment).find("." + this.opts.itemClass).css({
                    "transform": "",
                    "-moz-transform": "",
                    "-webkit-transform": "",
                    "-o-transform": "",
                    "-ms-transform": "",
                    "opacity": ""
                }), this.stashed = !1
            },
            "start": function(t, e) {
                this.isTransiting || (e || (e = this.opts.type), this.args = _g.transitionargs[e], this.args.perspective ? $(this.opts.containment).addClass(this.opts.perspectiveClass) : $(this.opts.containment).removeClass(this.opts.perspectiveClass), this.currentItem = $(this.opts.containment).find("." + this.opts.currentClass), this.currentItem.addClass(this.opts.topClass), this.stashitemClass())
            },
            "dragX": function(t) {
                if (!this.isTransiting && (t.gesture.deltaX <= 0 ? (this.plus = -1, this.activeItem = $(this.opts.containment).find("." + this.opts.rightClass)) : (this.plus = 1, this.activeItem = $(this.opts.containment).find("." + this.opts.leftClass)), this.activeItem.length)) {
                    var e = t.gesture.deltaX;
                    this.direction = "x", this.dragHandle(e)
                }
            },
            "dragY": function(t) {
                if (!this.isTransiting && (t.gesture.deltaY <= 0 ? (this.plus = -1, this.activeItem = $(this.opts.containment).find("." + this.opts.downClass)) : (this.plus = 1, this.activeItem = $(this.opts.containment).find("." + this.opts.upClass)), this.activeItem.length)) {
                    var e = t.gesture.deltaY;
                    this.direction = "y", this.dragHandle(e)
                }
            },
            "dragHandle": function(t) {
                $(this.opts.containment).find("." + this.opts.itemClass).removeClass(this.opts.activeClass), this.activeItem.addClass(this.opts.activeClass), this.currentItem = $(this.opts.containment).find("." + this.opts.currentClass);
                var e = Math.abs(t) / $(this.opts.containment).width();
                if (_g.browserSupport({
                        "msie": 9
                    }))
                    if (this.args.percentcontrol) {
                        for (i = 0; i < this.args.percentcontrol.length; i++)
                            if (e <= this.args.percentcontrol[i]) {
                                if (this.args[this.args.percentcontrol[i]][this.direction].css) {
                                    var n = this.args[this.args.percentcontrol[i]][this.direction].css;
                                    n.currentItem && this.currentItem.css(this.getArgs(n.currentItem, this.plus, e)), n.activeItem && this.activeItem.css(this.getArgs(n.activeItem, this.plus, e))
                                }
                                this.activeItem.css(this.getArgs(this.args[this.args.percentcontrol[i]][this.direction].activeItem, this.plus, e)), this.currentItem.css(this.getArgs(this.args[this.args.percentcontrol[i]][this.direction].currentItem, this.plus, e));
                                break
                            }
                    } else {
                        if (this.args[this.direction].css) {
                            var n = this.args[this.direction].css;
                            n.currentItem && this.currentItem.css(this.getArgs(n.currentItem, this.plus, e)), n.activeItem && this.activeItem.css(this.getArgs(n.activeItem, this.plus, e))
                        }
                        this.activeItem.css(this.getArgs(this.args[this.direction].activeItem, this.plus, e)), this.currentItem.css(this.getArgs(this.args[this.direction].currentItem, this.plus, e))
                    }
                else this.currentItem.css("x" == this.direction ? "margin-left" : "margin-top", this.plus * e * 100 + "%"), this.activeItem.css("x" == this.direction ? "margin-left" : "margin-top", -this.plus * (1 - e) * 100 + "%");
                this.args.currentTop ? this.currentItem.addClass(this.opts.topClass) : this.currentItem.removeClass(this.opts.topClass), this.args.activeTop && this.activeItem.addClass(this.opts.topClass), this.opts.onTransition && this.opts.onTransition(event, e)
            },
            "dragEnd": function(t) {
                if (!this.isTransiting && this.currentItem.length && this.activeItem.length) {
                    var e = this;
                    this.isTransiting = !0;
                    var n = "x" == this.direction ? t.gesture.deltaX : t.gesture.deltaY,
                        o = Math.abs(n) / $(this.opts.containment).width();
                    if (_g.browserSupport({
                            "msie": 9
                        }))
                        if (this.args.percentcontrol) {
                            for (this.percent = o, i = 0; i < this.args.percentcontrol.length; i++)
                                if (o <= this.args.percentcontrol[i]) {
                                    this.transitPercent(i);
                                    break
                                }
                        } else {
                            var a = 1200;
                            "undefined" != typeof coolsite && (a = 1);
                            var s = this.getArgs(this.args[this.direction].currentItem, this.plus, 1);
                            s.duration = a, s.easing = this.args.currentEasing;
                            var r = this.getArgs(this.args[this.direction].activeItem, this.plus, 1);
                            r.duration = a, r.easing = this.args.activeEasing, r.complete = function() {
                                e.isTransiting = !1, e.onTransitionEnd()
                            }, this.currentItem.transit(s), this.activeItem.transit(r)
                        }
                    else this.activeItem.animate({
                        "marginLeft": -this.plus + "0%"
                    }), this.currentItem.animate({
                        "marginLeft": 100 * this.plus + "%"
                    }, "normal", "linear", function() {
                        e.onTransitionEnd(), e.isTransiting = !1
                    })
                }
            },
            "onTransitionEnd": function() {
                var t = this;
                this.recoveritemClass(), this.currentItem.removeClass(this.opts.currentClass), this.activeItem.addClass(this.opts.currentClass).removeClass(this.opts.activeClass).removeClass(this.opts.upClass).removeClass(this.opts.rightClass).removeClass(this.opts.leftClass).removeClass(this.opts.downClass), $(this.opts.containment).find("." + this.opts.itemClass).removeClass(this.opts.topClass);
                var e = this.currentItem.index(),
                    i = this.activeItem.index();
                $(this.opts.containment).removeClass(this.opts.perspectiveClass), t.opts.onEnd && t.opts.onEnd(e, i), this.timerStart()
            },
            "transitPercent": function(t) {
                var e = this;
                if (t < this.args.percentcontrol.length) {
                    var e = this,
                        i = this.opts.duration * (this.args.percentcontrol[t] - this.percent),
                        n = this.getArgs(this.args[this.args.percentcontrol[t]][this.direction].currentItem, this.plus, this.args.percentcontrol[t]);
                    n.duration = i, n.easing = this.args.currentEasing;
                    var o = this.getArgs(this.args[this.args.percentcontrol[t]][this.direction].activeItem, this.plus, this.args.percentcontrol[t]);
                    o.duration = i, o.easing = this.args.activeEasing, o.complete = function() {
                        e.transitPercent(t + 1)
                    }, this.percent = this.args.percentcontrol[t], this.currentItem.transit(n), this.activeItem.transit(o)
                } else e.isTransiting = !1, this.onTransitionEnd()
            },
            "getArgs": function(t, e, i) {
                var n = {};
                return _.each(t, function(t, o) {
                    n[o] = "function" == typeof t ? t(e, i) : t
                }), n
            },
            "autostart": function(t, e, i) {
                if (!this.isTransiting && (this.args = _g.transitionargs[t], this.currentItem = $(this.opts.containment).find("." + this.opts.currentClass), this.stashitemClass(), "x" == e && (this.activeItem = i < 0 ? $(this.opts.containment).find("." + this.opts.rightClass) : $(this.opts.containment).find("." + this.opts.leftClass)), "y" == e && (this.activeItem = i < 0 ? $(this.opts.containment).find("." + this.opts.downClass) : $(this.opts.containment).find("." + this.opts.upClass)), this.activeItem.length)) {
                    this.args.currentTop && this.currentItem.addClass(this.opts.topClass), this.plus = i, this.direction = e, this.args.perspective ? $(this.opts.containment).addClass(this.opts.perspectiveClass) : $(this.opts.containment).removeClass(this.opts.perspectiveClass);
                    var n = {
                        "gesture": {}
                    };
                    "x" == e ? n.gesture.deltaX = 0 : n.gesture.deltaY = 0, this.opts.onStart && this.opts.onStart(this.currentItem.index(), this.activeItem.index()), this.dragHandle(0), this.dragEnd(n)
                }
            },
            "enableTimer": function() {
                this.timerDisabled = !1
            },
            "disableTimer": function() {
                this.timerDisabled = !0
            },
            "setCurrent": function(t, e) {
                var i, n = this;
                $(this.opts.containment).children("." + this.opts.itemClass).removeClass(this.opts.topClass).removeClass(this.opts.activeClass).removeClass(this.opts.upClass).removeClass(this.opts.rightClass).removeClass(this.opts.leftClass).removeClass(this.opts.downClass);
                var o = $(this.opts.containment).children().length;
                if (t >= o) {
                    if (!this.opts.repeat) return void this.timerStop();
                    this.current = 0, t = 0
                } else if (t < 0) {
                    if (!this.opts.repeat) return void this.timerStop();
                    this.current = o - 1, t = o - 1
                }
                if ($(this.opts.containment).children().each(function() {
                        $(this).index() == t ? (i = $(this), $(this).addClass(n.opts.currentClass)) : $(this).removeClass(n.opts.currentClass)
                    }), e && i) {
                    if ("x" == e) var a = this.opts.leftClass,
                        s = this.opts.rightClass;
                    else var a = this.opts.upClass,
                        s = this.opts.downClass;
                    i.prev().length ? i.prev().addClass(a) : this.opts.repeat && $(this.opts.containment).children().last().addClass(a), i.next().length ? i.next().addClass(s) : this.opts.repeat && $(this.opts.containment).children().first().addClass(s)
                }
            },
            "timerStart": function(t) {
                if (!this.timerDisabled) {
                    var e = this;
                    if (t) t.type || (t.type = e.opts.type), t.axis || (t.axis = "x"), t.diretion || (t.direction = -1), t.startAt || (t.startAt = 0), this.setCurrent(t.startAt, t.axis), this.current = t.startAt, this.TimerArgs = t;
                    else {
                        if (!this.TimerArgs) return;
                        t = this.TimerArgs, this.TimerDirection = this.TimerDirection || e.opts.autoplayDirection, this.current = null != this.tempCurrent ? this.tempCurrent : -1 == this.TimerDirection ? this.current + 1 : this.current - 1, this.tempCurrent = null, this.TimerDirection = null, this.setCurrent(this.current, t.axis)
                    }
                    this.Timer && window.clearTimeout(this.Timer), this.Timer = window.setTimeout(function() {
                        e.autostart(t.type, t.axis, t.direction)
                    }, this.opts.interval)
                }
            },
            "timerStop": function(t) {
                this.Timer && (window.clearTimeout(this.Timer), this.Timer = null), this.TimerArgs = null, this.disableTimer()
            }
        }, o = [n(2), n(7), n(12)], (a = function() {
            return window._g.transition = s, window._g.transition
        }.apply(e, o)) !== undefined && (t.exports = a)
    }(window)
}, function(t, e, i) {
    "use strict";
    var n, o;
    ! function() {
        var i = {
            "init": function() {
                var t = {
                    "model": function(t, e) {
                        return new coolsite_play.model.action.action(t, e)
                    }
                };
                coolsite_play.collection.action = _g.mvc.createCollection(t);
                var e = {
                    "model": function(t, e) {
                        return new coolsite_play.model.animation.animation(t, e)
                    }
                };
                coolsite_play.collection.animation = _g.mvc.createCollection(e);
                var i = {
                    "enableSync": !1
                };
                coolsite_play.collection.element = _g.mvc.createCollection(i), coolsite_play.collection.slider = coolsite_play.collection.element.extend({
                    "model": function(t, e) {
                        return new coolsite_play.model.element.slider(t, e)
                    },
                    "generate": function() {
                        var t = this;
                        this.reset([], {
                            "silent": !0
                        }), $(document).find(".c-slider:not(.cf-ref)").each(function() {
                            var e = t.getArgs(this);
                            t.add({
                                "args": e
                            }), t.last().iview.setElement(this), t.last().iview.afterRender()
                        })
                    },
                    "getArgs": function(t) {
                        var e = $(t).attr("data-c_slider_args"),
                            e = e.split(";"),
                            i = {};
                        return _.each(e, function(t) {
                            var e = t.split(":");
                            i[e[0]] = e[1]
                        }), i
                    },
                    "stop": function() {
                        this.each(function(t) {
                            t.stop()
                        })
                    }
                });
                var n = {
                    "model": function(t, e) {
                        return new coolsite_play.model.timeline.timeline(t, e)
                    }
                };
                coolsite_play.collection.timeline = _g.mvc.createCollection(n), _cs.mvc.init_controllers(), _cs.mvc.init_views(), _cs.mvc.init_models(), coolsite_play.animationlist = new coolsite_play.collection.animation, coolsite_play.timelinelist = new coolsite_play.collection.timeline, coolsite_play.sliderlist = new coolsite_play.collection.slider, coolsite_play.actionlist = new coolsite_play.collection.action
            },
            "init_models": function() {
                var t = {
                    "enableSync": !1,
                    "autoIndex": !0,
                    "element": null,
                    "bindRemove": function(t, e) {},
                    "callback": function() {
                        this.type = this.get("data").type, this.exec = this.get("data").exec
                    },
                    "initView": coolsite_play.view.action.action,
                    "getArgs": function() {
                        var t = this.get("data").args;
                        return $.extend(!0, {}, t)
                    },
                    "getType": function() {
                        return this.get("data").type
                    }
                };
                coolsite_play.model.action.action = _g.mvc.createModel(t);
                var e = {
                    "enableSync": !1,
                    "autoIndex": !0,
                    "element": null,
                    "bindRemove": function(t, e) {},
                    "callback": function() {},
                    "initView": coolsite_play.view.animation.animation
                };
                coolsite_play.model.animation.animation = _g.mvc.createModel(e);
                var i = {
                    "enableSync": !1,
                    "autoIndex": !0,
                    "initView": coolsite_play.view.element.element,
                    "callback": function() {}
                };
                coolsite_play.model.element.element = _g.mvc.createModel(i), coolsite_play.model.element.slider = coolsite_play.model.element.element.extend({
                    "initView": coolsite_play.view.element.slider,
                    "start": function() {
                        var t, e = this,
                            i = this.get("args");
                        if (this.transition = t = this.getTransition(), !this.silderStart) {
                            if (this.sliderStart = !0, this.iview.$el.children(".c-leftarrow").on("click", function(t) {
                                    return e.switchSlide("prev"), !1
                                }), this.iview.$el.children(".c-rightarrow").on("click", function(t) {
                                    return e.switchSlide("next"), !1
                                }), coolsite_play.isPreview || _.each(this.iview.slidernavdots, function(t, i) {
                                    $(t).on("click", function() {
                                        e.switchSlide(i)
                                    })
                                }), this.iview.$el.children(".c-slider-mask").data("sliderId", this.id), !Number(i.ap)) return;
                            t.enableTimer(), t.timerStart({})
                        }
                    },
                    "stop": function() {
                        this.sliderStart && (this.transition.timerStop(), this.iview.$el.children(".c-leftarrow").off("click"), this.iview.$el.children(".c-rightarrow").off("click"), coolsite_play.isPreview || this.iview.slidernavdots.off("click"), this.sliderStart = !1)
                    },
                    "switchSlide": function(t) {
                        if (!this.transition || !this.transition.isTransiting) {
                            var e = this.get("args");
                            if ("prev" == t && (this.transition.TimerDirection = 1, this.transition.autostart(e.type, "x", 1)), "next" == t && this.transition.autostart(e.type, "x", -1), _.isNumber(t)) {
                                var i;
                                if (t == this.transition.currentIndex) return null;
                                i = t > this.transition.currentIndex ? -1 : 1, this.transition.currentIndex = t, this.transition.prepareNextClass(this.iview.slidermask, t, i), this.transition.TimerDirection = i, this.transition.Timer && window.clearTimeout(this.transition.Timer), this.transition.tempCurrent = t, this.transition.autostart(e.type, "x", i), this.transition.TimerDirection = -1
                            }
                        }
                    },
                    "onChangeTo": function(t, e) {
                        (coolsite_play.isPreview || coolsite_play.isPlay) && (_.isNumber(t) && this.iview.slides.eq(t).trigger("recover"), this.iview.slides.eq(e).trigger("changeTo"))
                    },
                    "getTransition": function() {
                        if (this.transition) return this.transition;
                        var t = this.iview.$el.attr("data-c_sliderid"),
                            e = coolsite_editor.elementlist.get(t);
                        return e ? e.transition : null
                    }
                });
                var n = {
                    "enableSync": !1,
                    "autoIndex": !0,
                    "element": null,
                    "bindRemove": function(t, e) {},
                    "callback": function() {},
                    "initView": coolsite_play.view.timeline.timeline,
                    "play": function() {
                        var t = this.getArgs();
                        t && 2 == t.st && this.played || (this.played = !0, this.animations || (this.animations = this.get("animations"), this.animations && this.animations.length && (this.animations = _.map(this.animations, function(t) {
                            var e = coolsite_play.animationlist.get(t);
                            return e || null
                        }), this.animations = _.reject(this.animations, function(t) {
                            return !t
                        }), this.animations = _.reject(this.animations, function(t) {
                            return t.toJSON().data.t.wa
                        }))), "undefined" != typeof TweenMax && (this.timeline && this.timeline.kill(), this.timeline = coolsite_play.util.timeline.createTimeline({
                            "animations": this.animations,
                            "args": t,
                            "model": this
                        }), this.timeline.play(0, !1)))
                    },
                    "stop": function() {
                        this.timeline && this.timeline.kill()
                    },
                    "recoverStyle": function() {
                        var t = this.getArgs();
                        t && 2 == t.st && this.played || this.animations && _.each(this.animations, function(t) {
                            t.iview.recoverStyle()
                        })
                    },
                    "getArgs": function() {
                        return this.get("data").t
                    }
                };
                coolsite_play.model.timeline.timeline = _g.mvc.createModel(n)
            },
            "init_views": function() {
                coolsite_play.view.action.action = {
                    "autoRender": !1,
                    "events": coolsite_play.controller.action.action,
                    "execute": function(t) {
                        var e = this.model.getArgs();
                        if (e && 2 == e.st && this.model.triggered) return !1;
                        this.model.triggered = !0;
                        var i = this.model.get("data").exec;
                        switch (i) {
                            case 0:
                                this.renderAnimations();
                                break;
                            case 1:
                                this.renderShow();
                                break;
                            case 2:
                                this.renderHide();
                                break;
                            case 5:
                                this.renderUrl();
                                break;
                            case 6:
                                this.renderSwitch();
                                break;
                            case 10:
                                this.renderUrl();
                                break;
                            case 16:
                                this.renderPhone();
                                break;
                            case 30:
                                this.renderHash();
                                break;
                            case 20:
                                this.renderToggle();
                                break;
                            case 21:
                                this.renderClass("add");
                                break;
                            case 22:
                                this.renderClass("remove");
                                break;
                            case 23:
                                this.renderClass("toggle");
                                break;
                            case 26:
                                this.renderState();
                                break;
                            case 27:
                                this.renderDialog("open", t);
                                break;
                            case 28:
                                this.renderDialog("close", t);
                                break;
                            case 29:
                                this.renderDialog("toggle", t);
                                break;
                            case 32:
                                this.renderHtml("load");
                                break;
                            case 33:
                                this.renderHtml("unload");
                                break;
                            case 52:
                                this.renderMedia("play");
                                break;
                            case 53:
                                this.renderMedia("pause");
                                break;
                            case 54:
                                this.renderMedia("stop");
                                break;
                            case 55:
                                this.renderMedia("toggle")
                        }
                        coolsite_play.util.PluginManage.actionexcutes[i] && coolsite_play.util.PluginManage.actionexcutes[i].config.exec(this)
                    },
                    "renderAnimations": function() {
                        var t = this.model.getArgs();
                        this.animations || (this.animations = t.a_ids, this.animations && this.animations.length && (this.animations = _.map(this.animations, function(t) {
                            var e = coolsite_play.animationlist.get(t);
                            return e || null
                        }), this.animations = _.reject(this.animations, function(t) {
                            return !t
                        }))), "undefined" != typeof TweenMax && (this.timeline && this.timeline.kill(), this.timeline = coolsite_play.util.timeline.createTimeline({
                            "animations": this.animations,
                            "args": t
                        }), this.timeline.play(0, !1))
                    },
                    "getEl": function(t) {
                        var e = $("[data-c_e_id=" + t + "]");
                        return e = e.length > 1 && this.model.siblingIndex != undefined && e[this.model.siblingIndex] ? $(e[this.model.siblingIndex]) : e
                    },
                    "renderShow": function() {
                        var t = this,
                            e = this.model.getArgs(),
                            i = e.e_ids;
                        _.each(i, function(e) {
                            var i = t.getEl(e);
                            i.length && (i.removeClass("c-initHide"), i.removeClass("cf-initHide"), i.show())
                        })
                    },
                    "renderHide": function() {
                        var t = this,
                            e = this.model.getArgs(),
                            i = e.e_ids;
                        _.each(i, function(e) {
                            var i = t.getEl(e);
                            i.length && i.hide()
                        })
                    },
                    "renderToggle": function() {
                        var t = this,
                            e = this.model.getArgs(),
                            i = e.e_ids;
                        _.each(i, function(e) {
                            var i = t.getEl(e);
                            i.length && (i.hasClass("c-initHide") || i.hasClass("cf-initHide") ? (i.removeClass("c-initHide"), i.removeClass("cf-initHide"), i.show()) : i.toggle())
                        })
                    },
                    "renderClass": function(t, e) {
                        var i = this,
                            n = this.model.getArgs();
                        e || (e = n.cla);
                        var o = n.e_ids;
                        e && _.each(o, function(n) {
                            var o = i.getEl(n);
                            o.length && ("add" == t && o.addClass(e), "remove" == t && o.removeClass(e), "toggle" == t && o.toggleClass(e))
                        })
                    },
                    "renderDialog": function(t, e) {
                        var i = this,
                            n = this.model.getArgs(),
                            o = n.e_ids;
                        _.each(o, function(n) {
                            var o = i.getEl(n);
                            if (o.length) {
                                var a = $(e.target).closest("[data-c_contentview_id]");
                                if (a.length) {
                                    var s = a.attr("data-c_contentview_id");
                                    if (o.find("[data-c_e_id=" + s + "]").length) {
                                        var r = a.attr("data-c_content_url");
                                        if (r) {
                                            o.find("[data-c_e_id=" + s + "]").empty();
                                            $.ajax({
                                                "url": r,
                                                "type": "GET",
                                                "dataType": "html",
                                                "success": function(t) {
                                                    o && o.find("[data-c_e_id=" + s + "]").length && o.find("[data-c_e_id=" + s + "]").replaceWith(t)
                                                },
                                                "error": function() {},
                                                "timeout": 1e4
                                            })
                                        }
                                    }
                                }
                                "open" == t ? (o.removeClass("c-initHide"), o.removeClass("cf-initHide"), o.show(), $("body").addClass("modal-open"), $("html").addClass("c-modal-patch"), window.setTimeout(function() {
                                    o.addClass("c-dialog-open")
                                }, 300)) : "close" == t ? (o.removeClass("c-dialog-open"), $("body").removeClass("modal-open"), $("html").removeClass("c-modal-patch"), window.setTimeout(function() {
                                    o.hide()
                                }, 300)) : "toggle" == t && (o.hasClass("c-dialog-open") ? (o.removeClass("c-dialog-open"), $("body").removeClass("modal-open"), $("html").removeClass("c-modal-patch"), window.setTimeout(function() {
                                    o.hide()
                                }, 300)) : (o.removeClass("c-initHide"), o.removeClass("cf-initHide"), o.show(), $("body").addClass("modal-open"), $("html").addClass("c-modal-patch"), window.setTimeout(function() {
                                    o.addClass("c-dialog-open")
                                }, 300)))
                            }
                        })
                    },
                    "renderMedia": function(t) {
                        var e = this.model.getArgs(),
                            i = e.e_ids;
                        _.each(i, function(e) {
                            switch (t) {
                                case "play":
                                    _g.html5media.play(e);
                                    break;
                                case "pause":
                                    _g.html5media.pause(e);
                                    break;
                                case "stop":
                                    _g.html5media.stop(e);
                                    break;
                                case "toggle":
                                    _g.html5media.toggle(e)
                            }
                        })
                    },
                    "renderState": function(t) {
                        var e = this,
                            i = this.model.getArgs();
                        t || (t = i.cla);
                        var n = i.e_ids;
                        _.each(n, function(i) {
                            var n = e.getEl(i);
                            if (n.length) {
                                if ("c-state1" != t && n.removeClass("c-state1"), "c-state2" != t && n.removeClass("c-state2"), "c-state3" != t && n.removeClass("c-state3"), !t) return;
                                n.addClass(t)
                            }
                        })
                    },
                    "renderUrl": function() {
                        var t = this.model.getArgs();
                        if (t.url) {
                            var e = this.model.get("data").exec;
                            if (10 == e ? 0 == t.url.indexOf("#") || -1 != t.url.indexOf("://") || (t.url = "http://" + t.url) : 5 == e && "undefined" != typeof portal_url && (t.url = portal_url + t.url), t.blank) {
                                if (coolsite_play.isPreview) return coolsite_editor.ui.message.show("warning", coolsite_editor.WARN[100]), !1;
                                window.open(t.url)
                            } else {
                                if (coolsite_play.isPreview) return coolsite_editor.ui.message.show("warning", coolsite_editor.WARN[100]), !1;
                                window.location.href = t.url
                            }
                        }
                    },
                    "renderHash": function() {
                        var t = this.model.getArgs();
                        t.url && coolsite_play.events.scroll.doHashScroll(null, t.url)
                    },
                    "renderPhone": function() {
                        var t = this.model.getArgs();
                        t.url && (window.location = "tel:" + t.url)
                    },
                    "renderHtml": function(t) {
                        var e = this,
                            i = this.model.getArgs(),
                            n = i.e_ids;
                        _.each(n, function(i) {
                            var n = e.getEl(i);
                            n.length && ("load" == t ? (n.removeClass("c-initHide"), n.removeClass("cf-initHide"), n.show(), n.attr("data-src") && n.attr("src", n.attr("data-src")), n.attr("data-srcdoc") && (_g.device.msie() ? n[0].contentWindow.document.write(n.attr("data-srcdoc")) : n.attr("srcdoc", n.attr("data-srcdoc")))) : "unload" == t && (n.attr("src") && n.removeAttr("src"), n.attr("srcdoc") && (_g.device.msie() ? n[0].contentWindow.document.write("") : n.removeAttr("srcdoc"))))
                        })
                    },
                    "renderSwitch": function() {
                        var t = this,
                            e = this.model.getArgs(),
                            i = e.e_ids;
                        _.each(i, function(i) {
                            var n = t.getEl(i);
                            n.length && n.trigger("switchTo", e.i)
                        })
                    }
                }, coolsite_play.view.animation.animation = {
                    "autoRender": !1,
                    "events": coolsite_play.controller.animation.animation,
                    "stashStyle": function() {
                        if (this.$el.length > 1) {
                            var t = this;
                            t.tmpClass = [], t.tmpStyle = [], _.each(this.$el, function(e) {
                                t.tmpClass.push($(e).attr("class")), t.tmpStyle.push($(e).attr("style"))
                            })
                        } else this.tmpClass = this.$el.attr("class"), this.tmpStyle = this.$el.attr("style")
                    },
                    "recoverStyle": function() {
                        if (this.$el.length > 1) {
                            var t = this;
                            _.each(this.$el, function(e, i) {
                                $(e).attr("class", t.tmpClass[i]), $(e).attr("style", t.tmpStyle[i])
                            })
                        } else this.$el.attr("class", this.tmpClass), this.$el.attr("style", this.tmpStyle)
                    }
                }, coolsite_play.view.element.element = {
                    "autoRender": !1,
                    "events": coolsite_play.controller.element.element
                }, coolsite_play.view.element.slider = $.extend(!0, {}, coolsite_play.view.element.element, {
                    "events": coolsite_play.controller.element.slider,
                    "afterRender": function() {
                        this.slidernav = this.$el.children(".c-slider-nav"), this.slidernavdots = this.slidernav.children(".c-slider-nav-dot"), this.slidermask = this.$el.children(".c-slider-mask"), this.slides = this.slidermask.children(".c-slide");
                        var t = this.model.get("args");
                        coolsite_play.isPreview || (this.model.transition = coolsite_play.slider(this.slidermask, t), this.model.transition.refreshSlideClass(this.slidermask, 0), this.slidernavdots.first().addClass("c-active"), this.model.transition.currentIndex = 0)
                    }
                }), coolsite_play.view.timeline.timeline = {
                    "autoRender": !1,
                    "events": coolsite_play.controller.timeline.timeline
                }
            },
            "init_controllers": function() {
                coolsite_play.controller.action.action = {
                    "c_start": function(t) {
                        if ($(t.target).is(this.$el)) return 6 == this.model.type ? (this.execute(t), !1) : void 0
                    },
                    "click": function(t) {
                        if (0 == this.model.type) return this.execute(t), $(t.target).closest(".btn-listitem").length && $(t.target).closest(".btn-listitem").trigger("button_active"), !1
                    },
                    "dblclick": function(t) {
                        if (4 == this.model.type) return this.execute(t), !1
                    },
                    "mouseover": function(t) {
                        if (20 == this.model.type) return this.execute(t), !1
                    },
                    "mouseout": function(t) {
                        if (21 == this.model.type) return this.execute(t), !1
                    },
                    "c_scroll": function(t) {
                        23 == this.model.type && this.execute(t)
                    },
                    "c_scrollUp": function(t) {
                        $(t.target).is(this.$el) && 24 == this.model.type && this.execute(t)
                    },
                    "c_scrollDown": function(t) {
                        $(t.target).is(this.$el) && 25 == this.model.type && this.execute(t)
                    },
                    "scrollIn": function(t) {
                        $(t.target).is(this.$el) && 26 == this.model.type && this.execute(t)
                    },
                    "scrollUpIn": function(t) {
                        $(t.target).is(this.$el) && 27 == this.model.type && this.execute(t)
                    },
                    "scrollDownIn": function(t) {
                        $(t.target).is(this.$el) && 28 == this.model.type && this.execute(t)
                    },
                    "scrollOut": function(t) {
                        $(t.target).is(this.$el) && 29 == this.model.type && this.execute(t)
                    },
                    "scrollUpOut": function(t) {
                        $(t.target).is(this.$el) && 30 == this.model.type && this.execute(t)
                    },
                    "scrollDownOut": function(t) {
                        $(t.target).is(this.$el) && 31 == this.model.type && this.execute(t)
                    },
                    "changeTo": function(t) {
                        $(t.target).is(this.$el) && 5 == this.model.type && this.execute(t)
                    },
                    "c_active": function(t) {
                        $(t.target).is(this.$el) && 33 == this.model.type && this.execute(t)
                    },
                    "c_deactive": function(t) {
                        $(t.target).is(this.$el) && 34 == this.model.type && this.execute(t)
                    },
                    "button_active": function(t) {
                        35 == this.model.type && this.execute(t)
                    }
                }, coolsite_play.controller.animation.animation = {}, coolsite_play.controller.element.element = {
                    "scrollUpIn": function(t) {}
                }, coolsite_play.controller.element.slider = $.extend(!0, {}, coolsite_play.controller.element.element, {
                    "scrollUpIn": function(t) {
                        $(t.target).is(this.$el) && (this.model.start(), this.model.onChangeTo(null, 0))
                    },
                    "switchTo": function(t, e) {
                        $(t.target).is(this.$el) && this.model.switchSlide(e)
                    }
                }), coolsite_play.controller.timeline.timeline = {
                    "scrollIn": function(t) {
                        $(t.target).is(this.$el) && this.model.play()
                    },
                    "recover": function(t) {
                        $(t.target).is(this.$el) && this.model.recoverStyle()
                    },
                    "changeTo": function(t) {
                        $(t.target).is(this.$el) && this.model.play()
                    },
                    "c_active": function(t) {
                        $(t.target).is(this.$el)
                    },
                    "c_deactive": function(t) {
                        $(t.target).is(this.$el)
                    },
                    "t_start": function(t) {
                        $(t.target).is(this.$el) && ("locked" == this.$el.attr("data-c_tl_locked") ? coolsite_play.isSectionLock = this.model.id : coolsite_play.isSectionLock = !1)
                    },
                    "t_end": function(t) {
                        $(t.target).is(this.$el) && coolsite_play.isSectionLock == this.model.id && (coolsite_play.isSectionLock = !1)
                    }
                }
            }
        };
        n = [], (o = function() {
            return window._cs || (window._cs = {}), window._cs.mvc = i, window._cs.mvc
        }.apply(e, n)) !== undefined && (t.exports = o)
    }(window)
}, function(t, e, i) {
    "use strict";
    var n, o;
    ! function() {
        var i = {
            "init": function() {
                coolsite_play.events.dialog = {
                    "init": function() {
                        $(document).find(".c-modal").on("click", ".dialog-close", coolsite_play.events.dialog.handleDialogClose)
                    },
                    "handleDialogClose": function() {
                        var t = $(this).closest(".c-modal");
                        return t.removeClass("c-dialog-open"), $("body").removeClass("modal-open"), $("html").removeClass("c-modal-patch"), window.setTimeout(function() {
                            t.hide()
                        }, 300), !1
                    },
                    "stop": function() {
                        $(document).find(".c-modal").off("click", ".dialog-close", coolsite_play.events.dialog.handleDialogClose)
                    }
                }, coolsite_play.events.form = {
                    "init": function() {
                        $("form textarea").each(function() {
                            "    " == $(this).html() && $(this).html("")
                        }), $("[data-c_form]").each(function() {
                            $(this).bind("submit", coolsite_play.events.form.bind)
                        })
                    },
                    "bind": function() {
                        var t = $(this),
                            e = $(this).attr("data-action");
                        if (!e) return !1;
                        $.ajax({
                            "url": e,
                            "type": "POST",
                            "dataType": "JSON",
                            "data": $(this).serialize(),
                            "beforeSend": function(t) {
                                t.setRequestHeader("X-CSRFToken", coolsite_play.readCookie("csrftoken"))
                            },
                            "traditional": !0,
                            "success": function(e) {
                                if (t.find(".c-error").removeClass("c-error"), 200 == e.code) t.addClass("c-success"), t.removeClass("c-error"), coolsite_play.events.form.handleRedirect(t);
                                else {
                                    t.addClass("c-error");
                                    var i = e.msg;
                                    _.each(i, function(e, i) {
                                        var n = t.find("[name=" + i + "]");
                                        n.is("input[type=radio]") || n.is("input[type=checkbox]") ? n.parent().addClass("c-error") : t.find("[name=" + i + "]").addClass("c-error")
                                    })
                                }
                            },
                            "error": function() {},
                            "timeout": 1e4
                        });
                        return !1
                    },
                    "stop": function() {
                        $("[data-c_form]").each(function() {
                            $(this).unbind("submit", coolsite_play.events.form.bind)
                        })
                    },
                    "handleRedirect": function(t) {
                        var e, i = t.attr("data-url"),
                            n = t.attr("data-page"),
                            o = t.attr("data-target");
                        if (i) e = i, 0 == e.indexOf("#") || -1 != e.indexOf("://") || (e = "http://" + e);
                        else {
                            if (!n) return !1;
                            e = n, "undefined" != typeof portal_url && (e = portal_url + e)
                        }
                        if (o) {
                            if (coolsite_play.isPreview) return coolsite_editor.ui.message.show("warning", coolsite_editor.WARN[100]), !1;
                            window.open(e)
                        } else {
                            if (coolsite_play.isPreview) return coolsite_editor.ui.message.show("warning", coolsite_editor.WARN[100]), !1;
                            window.location.href = e
                        }
                    }
                }, coolsite_play.events.html = {
                    "init": function() {
                        _g.device.msie() && $(document).find("iframe.c-iframe").each(function() {
                            if ($(this).attr("srcdoc")) {
                                var t = $(this).attr("srcdoc");
                                this.contentWindow.document.write(t)
                            }
                        })
                    }
                }, coolsite_play.events.mousewheel = {
                    "init": function() {
                        $("body").find(".c-section-switch,.no-target-switch").each(function() {
                            $(this).on("mousewheel", coolsite_play.events.mousewheel.handlemousewheel)
                        })
                    },
                    "stop": function() {
                        $("body").find(".c-section-switch,.no-target-switch").each(function() {
                            $(this).off("mousewheel", coolsite_play.events.mousewheel.handlemousewheel)
                        })
                    },
                    "handlemousewheel": function(t) {
                        var e = t.currentTarget;
                        $(this).hasClass("no-target-switch") && (e = $(".c-section-switch.c-scrollIn"));
                        var i = null;
                        (t.deltaY < -10 || coolsite_play.isWindows && t.deltaY < 0) && (i = 1), (t.deltaY > 10 || coolsite_play.isWindows && t.deltaY > 0) && (i = 0), null != i && coolsite_play.events.scroll.doSectionSwitch(e, i), t.preventDefault()
                    }
                }, coolsite_play.events.scroll = {
                    "init": function() {
                        coolsite_play.events.scroll.refresh(), $("body").trigger("c_start"), $("body").trigger("scrollIn"), $("body").trigger("scrollUpIn");
                        var t = $(window).scrollTop(),
                            e = coolsite_play.events.scroll.getScrollHeight(),
                            i = e - $(window).height(),
                            n = coolsite_play.sectionItems;
                        if ($("body").find(".c-section,.c-slider").each(function() {
                                $(this).offset().top < t + $(window).height() && ($(this).addClass("c-scrollIn"), $(this).trigger("scrollIn"), $(this).trigger("scrollUpIn"))
                            }), n.length)
                            if (t >= i) coolsite_play.events.scroll.activate(n.length - 1);
                            else if (t <= n[0].top) coolsite_play.events.scroll.activate(0);
                        else
                            for (var o = 0; o < n.length; o++) t >= n[o].top && (!n[o + 1] || t <= n[o + 1].top) && coolsite_play.events.scroll.activate(o);
                        coolsite_play.events.scroll.lastst = t, coolsite_play.scroll_offset = 0, $(window).bind("scroll", coolsite_play.events.scroll.handle), $(window).bind("resize", coolsite_play.events.scroll.resizehandle)
                    },
                    "refresh": function() {
                        coolsite_play.scrollItems = [], coolsite_play.sectionItems = [], $("body").find(".c-section,.c-slider").map(function() {
                            var t = $(this).offset().top,
                                e = $(this).offset().top + $(this).height();
                            return $(this).hasClass("c-section") || $(this).hasClass("c-slider"), {
                                "top": t,
                                "bottom": e,
                                "target": this
                            }
                        }).sort(function(t, e) {
                            return t.top - e.top
                        }).each(function() {
                            coolsite_play.scrollItems.push(this), $(this.target).hasClass("c-section") && "scroll" == $(this.target).attr("data-c_spy") && coolsite_play.sectionItems.push(this)
                        }), coolsite_play.scrollHeight = coolsite_play.events.scroll.getScrollHeight()
                    },
                    "getScrollHeight": function() {
                        return $("body")[0] ? Math.max($("body")[0].scrollHeight, document.documentElement.scrollHeight) : document.documentElement.scrollHeight
                    },
                    "handle": function(t) {
                        var e, i, n = $(this).scrollTop(),
                            o = coolsite_play.events.scroll.getScrollHeight(),
                            a = o - $(window).height(),
                            s = coolsite_play.scrollItems,
                            r = coolsite_play.sectionItems;
                        if (coolsite_play.scrollHeight != o && coolsite_play.events.scroll.refresh(), e = n > coolsite_play.events.scroll.lastst ? 1 : 0, coolsite_play.events.scroll.lastst = n, $("body").trigger("c_scroll"), $("body").trigger(1 == e ? "c_scrollUp" : "c_scrollDown"), r.length)
                            if (n >= a) coolsite_play.events.scroll.activate(r.length - 1);
                            else if (n <= r[0].top) coolsite_play.events.scroll.activate(0);
                        else
                            for (var i = 0; i < r.length; i++) e ? n >= r[i].top && (!r[i + 1] || n <= r[i + 1].top) && coolsite_play.events.scroll.activate(i) : n <= r[i].top && (!r[i - 1] || n >= r[i - 1].top) && coolsite_play.events.scroll.activate(i - 1);
                        for (var i = 0; i < s.length; i++) {
                            var l = s[i].target,
                                c = s[i].top,
                                d = s[i].bottom;
                            e ? c < n + $(window).height() && d - n > 0 ? $(l).hasClass("c-scrollIn") ? ($(l).trigger("c_scroll"), $(l).trigger("c_scrollUp")) : ($(l).addClass("c-scrollIn"), $(l).trigger("scrollIn"), $(l).trigger("scrollUpIn")) : $(l).hasClass("c-scrollIn") && ($(l).removeClass("c-scrollIn"), $(l).trigger("scrollOut"), $(l).trigger("scrollUpOut"), $(l).trigger("recover")) : d - n > 0 && c < n + $(window).height() ? $(l).hasClass("c-scrollIn") ? ($(l).trigger("c_scroll"), $(l).trigger("c_scrollDown")) : ($(l).addClass("c-scrollIn"), $(l).trigger("scrollIn"), $(l).trigger("scrollDownIn")) : $(l).hasClass("c-scrollIn") && ($(l).removeClass("c-scrollIn"), $(l).trigger("scrollOut"), $(l).trigger("scrollDownOut"), $(l).trigger("recover"))
                        }
                    },
                    "activate": function(t) {
                        var e = coolsite_play.sectionItems;
                        if (null == coolsite_play.currentActiveIndex || coolsite_play.currentActiveIndex != t) {
                            if (null != coolsite_play.currentActiveIndex) {
                                $(e[coolsite_play.currentActiveIndex].target).trigger("c_deactive");
                                var i = e[coolsite_play.currentActiveIndex].target.id;
                                if (i) {
                                    var n = $("[href=#" + i + "]");
                                    n.length && n.each(function() {
                                        "scroll" == $(this).attr("data-c_spy") && $(this).parent("li").length && $(this).parent("li").removeClass("active")
                                    })
                                }
                            }
                            $(e[t].target).trigger("c_active"), coolsite_play.currentActiveIndex = t;
                            var i = e[t].target.id;
                            if (i) {
                                var n = $("[href=#" + i + "]");
                                n.length && n.each(function() {
                                    "scroll" == $(this).attr("data-c_spy") && $(this).parent("li").length && $(this).parent("li").addClass("active")
                                })
                            }
                        }
                    },
                    "resizehandle": function(t) {
                        coolsite_play.events.scroll.refresh()
                    },
                    "bindHashScroll": function() {
                        $("a[href^='#'][data-toggle!='tab']").bind("click", coolsite_play.events.scroll.doHashScroll);
                        var t = Backbone.Router.extend({
                            "routes": {
                                ":hash": "hash"
                            }
                        });
                        if (coolsite_play.events.Router = new t, coolsite_play.events.Router.on("route:hash", function(t, e) {
                                coolsite_play.events.scroll.doHashScroll(null, "#" + t)
                            }), Backbone.history.stop(), Backbone.history.start({
                                "silent": !1
                            }), "onhashchange" in window) {
                            var e = function() {
                                "" === location.hash && $("body").find(".c-scroll-item").length && $("body").find(".c-scroll-item").scrollTop(0)
                            };
                            window.onhashchange = e
                        }
                    },
                    "unBindHashScroll": function() {
                        $("a[href^='#'][data-toggle!='tab']").unbind("click", coolsite_play.events.scroll.doHashScroll)
                    },
                    "doHashScroll": function(t, e) {
                        try {
                            if (e || (e = $(this).attr("href")), t && $(t.target).hasClass("c-search-box-btn")) return;
                            if (t && $(t.target).closest(".noHashScroll").length) return;
                            var i = e.replace("#", ""),
                                n = decodeURI(i);
                            if ($("[id='" + n + "']").length) {
                                var o = $("[id='" + n + "']").first();
                                if (o.closest(".c-scroll-item").length) {
                                    var a = o.closest(".c-scroll-item");
                                    a.animate({
                                        "scrollTop": a.scrollTop() + o.offset().top
                                    }, 500, null, function() {
                                        coolsite_play.events.Router.navigate(i, {
                                            "trigger": !1
                                        })
                                    })
                                } else $("html,body").animate({
                                    "scrollTop": o.offset().top
                                }, 500, null, function() {
                                    coolsite_play.events.Router.navigate(i, {
                                        "trigger": !1
                                    })
                                });
                                return t && t.preventDefault(), !1
                            }
                        } catch (t) {}
                    },
                    "doScrollByElement": function(t) {
                        coolsite_play.isSectionSwitching || coolsite_play.isSectionLock || $(t).length && $("html, body").animate({
                            "scrollTop": $(t).offset().top
                        }, 800)
                    },
                    "doSectionSwitch": function(t, e) {
                        var i = $(t).prev(".c-section-switch").length ? $(t).prev(".c-section-switch") : $(t).prev(".c-section") ? $(t).prev(".c-section") : null,
                            n = $(t).next(".c-section-switch").length ? $(t).next(".c-section-switch") : $(t).next(".c-section") ? $(t).next(".c-section") : null;
                        e && (coolsite_play.isSectionSwitching || n && (coolsite_play.events.scroll.doScrollByElement(n), coolsite_play.isSectionSwitching = t, window.setTimeout(function() {
                            coolsite_play.isSectionSwitching = null
                        }, 1e3))), e || coolsite_play.isSectionSwitching || i && (coolsite_play.events.scroll.doScrollByElement(i), coolsite_play.isSectionSwitching = t, window.setTimeout(function() {
                            coolsite_play.isSectionSwitching = null
                        }, 1e3))
                    },
                    "stop": function() {
                        $(window).unbind("scroll", coolsite_play.events.scroll.handle), $(window).unbind("resize", coolsite_play.events.scroll.resizehandle), coolsite_play.currentActiveIndex = null
                    }
                }, coolsite_play.events.touch = {
                    "init": function() {
                        $("body").find(".c-section-switch").each(function() {
                            $("body").hasClass("c-section-switch-disable-mobile") || ($(this).hammer().on("dragup", function(t) {
                                t.gesture.deltaY;
                                return coolsite_play.events.touch.handletouch(t, 1), t.gesture.preventDefault(), !1
                            }), $(this).hammer().on("dragdown", function(t) {
                                t.gesture.deltaY;
                                return coolsite_play.events.touch.handletouch(t, 0), t.gesture.preventDefault(), !1
                            }))
                        });
                        var t = !1;
                        $("body").on("touchstart", function(e) {
                            if (!t) {
                                var i = _.filter(_g.html5media.medias, function(t) {
                                    return "audio" == t.type && t.autoplay
                                });
                                if (i.length) try {
                                    i[0].media.play(), t = !0
                                } catch (n) {
                                    t = !1
                                } else t = !0
                            }
                        })
                    },
                    "handletouch": function(t, e) {
                        var i = t.currentTarget;
                        coolsite_play.events.scroll.doSectionSwitch(i, e)
                    }
                }
            }
        };
        n = [], (o = function() {
            return window._cs || (window._cs = {}), window._cs.event = i, window._cs.event
        }.apply(e, n)) !== undefined && (t.exports = o)
    }(window)
}, function(t, e, i) {
    "use strict";
    var n, o;
    ! function() {
        var i = {
            "init": function() {
                _g.timeline = {
                    "animation": {}
                };
                var t = {
                    "param": function(t, e) {
                        var i = {
                            "repeat": e.t.rp,
                            "ease": coolsite_play.easeType[e.t.es]
                        };
                        return i.onStartParams = ["{self}", e, t], i.onStart = this.onStart, i.onComplete = this.onComplete, i.onCompleteParams = ["{self}", e, t], i
                    },
                    "fromparam": function(t, e) {
                        return {}
                    },
                    "inparam": function(t, e) {
                        var i = {};
                        return i.onStart = this.onStart, i.onStartParams = ["{self}", e, t], i.onComplete = this.stop, i.onCompleteParams = ["{self}", e, t], i.ease = coolsite_play.easeType[e.t.es], i.repeat = e.t.rp, i.immediateRender = !1, i
                    },
                    "toparam": function(t, e) {
                        var i = {};
                        return i.onComplete = this.stop, i.onCompleteParams = ["{self}", e, t], i.ease = coolsite_play.easeType[e.t.es], i.repeat = e.t.rp, i.immediateRender = !1, i.onStartParams = ["{self}", e, t], i.onStart = this.onStart, i
                    },
                    "onStart": function(e, i, n) {
                        switch (e || (e = {}), i.type) {
                            case 1:
                            case 3:
                            case 5:
                                t.show(e.target || n), t.setOriginCenter(n);
                                break;
                            case 6:
                            case 9:
                                t.setOriginCenter(n);
                                break;
                            case 10:
                                t.show(e.target || n), t.setOriginCenter(n)
                        }
                    },
                    "onComplete": function(e, i, n) {
                        switch (i.type) {
                            case 5:
                                t.unsetOriginCenter(n);
                                break;
                            case 2:
                            case 4:
                            case 6:
                                t.unsetOriginCenter(n), t.hide(n);
                                break;
                            case 7:
                                break;
                            case 9:
                            case 10:
                                t.unsetOriginCenter(n)
                        }
                    },
                    "show": function(t, e) {
                        $(t).removeClass("c-initHide"), $(t).removeClass("cf-initHide"), $(t).show()
                    },
                    "hide": function(t, e) {
                        $(t).addClass("c-initHide"), $(t).addClass("cf-initHide")
                    },
                    "setOriginCenter": function(t) {
                        $(t).css("transform-origin", "50% 50%")
                    },
                    "unsetOriginCenter": function(t) {},
                    "stop": function(t, e, i) {
                        $(i).closest(".masonry").length && coolsite_play.util.refreshcontentlist.bindMasonry($(i).closest(".masonry"))
                    }
                };
                _g.timeline.animation[3] = function(e, i) {
                    var n = t.inparam(e, i),
                        o = t.toparam(e, i);
                    if (n.css = {
                            "opacity": 0
                        }, o.css = {
                            "opacity": 1,
                            "force3D": !1
                        }, "stage" == i.aniType) {
                        var a = TweenMax.staggerFrom(e, i.t.du, n, i.stagger);
                        return a
                    }
                    var a = TweenMax.fromTo(e, i.t.du, n, o);
                    return a
                }, _g.timeline.animation[4] = function(e, i) {
                    var n = t.param(e, i);
                    if (n.css = {
                            "opacity": 0,
                            "force3D": !1
                        }, "stage" == i.aniType) {
                        var o = TweenMax.staggerTo(e, i.t.du, n, i.stagger);
                        return o
                    }
                    var o = TweenMax.to(e, i.t.du, n);
                    return o
                }, _g.timeline.animation[1] = function(e, i) {
                    var n = i.d.di,
                        o = i.d.dt,
                        a = i.d.dl,
                        s = t.inparam(e, i),
                        r = t.toparam(e, i),
                        l = $(window).width(),
                        c = $(window).height();
                    s.css = {}, r.css = {
                        "force3D": !1
                    };
                    if ($(e).hasClass("c-initHide") && !0, $(e).addClass("cf-invisible c-invisible").removeClass("c-initHide").removeClass("cf-initHide"), $(e).data("objoffset")) d = $(e).data("objoffset");
                    else {
                        var d = e.offset();
                        $(e).data("objoffset", d)
                    }
                    switch (n) {
                        case 0:
                            s.css.y = o ? -a : -(d.top + e.height() - $(window).scrollTop()), r.css.y = 0;
                            break;
                        case 3:
                            s.css.x = o ? a : l - d.left, r.css.x = 0;
                            break;
                        case 2:
                            s.css.y = o ? a : c - (d.top - $(window).scrollTop()), r.css.y = 0;
                            break;
                        case 1:
                            s.css.x = o ? -a : -(d.left + e.width()), r.css.x = 0
                    }
                    if (o && (s.css.opacity = 0, r.css.opacity = 1), $(e).addClass("c-initHide"), $(e).removeClass("cf-invisible c-invisible"), "stage" == i.aniType) {
                        s.css.opacity = 0;
                        var u = TweenMax.staggerFrom(e, i.t.du, s, i.stagger)
                    } else var u = TweenMax.fromTo(e, i.t.du, s, r);
                    return u
                }, _g.timeline.animation[2] = function(e, i) {
                    var n = i.d.di,
                        o = i.d.dt,
                        a = i.d.dl,
                        s = t.param(e, i),
                        r = !1;
                    $(e).hasClass("c-initHide") && (r = !0, $(e).addClass("c-invisible").removeClass("c-initHide"));
                    var l = e.offset();
                    if ($(e).data("objoffset")) l = $(e).data("objoffset");
                    else {
                        var l = e.offset();
                        $(e).data("objoffset", l)
                    }
                    var c = $(window).width(),
                        d = $(window).height(),
                        u = e.width(),
                        h = e.height();
                    switch (s.css = {
                        "force3D": !1
                    }, n) {
                        case 0:
                            s.css.y = o ? -a : -(l.top + h - $(window).scrollTop());
                            break;
                        case 3:
                            s.css.x = o ? a : c - l.left;
                            break;
                        case 2:
                            s.css.y = o ? a : d - (l.top - $(window).scrollTop());
                            break;
                        case 1:
                            s.css.x = o ? -a : -(l.left + u)
                    }
                    if (r && $(e).addClass("c-initHide").removeClass("c-invisible"), o && (s.css.opacity = 0), "stage" == i.aniType) var f = TweenMax.staggerTo(e, i.t.du, s, i.stagger);
                    else var f = TweenMax.to(e, i.t.du, s);
                    return f
                }, _g.timeline.animation[5] = function(e, i) {
                    var n = t.inparam(e, i),
                        o = t.toparam(e, i);
                    if (n.css = {
                            "scale": 0
                        }, o.css = {
                            "scale": 1,
                            "force3D": !1
                        }, "stage" == i.aniType) var a = TweenMax.staggerFrom(e, i.t.du, n, i.stagger);
                    else var a = TweenMax.fromTo(e, i.t.du, n, o);
                    return a
                }, _g.timeline.animation[6] = function(e, i) {
                    var n = t.fromparam(e, i),
                        o = t.toparam(e, i);
                    if (n.css = {
                            "scale": 1
                        }, o.css = {
                            "scale": 0,
                            "force3D": "auto"
                        }, "stage" == i.aniType) var a = TweenMax.staggerTo(e, i.t.du, o, i.stagger);
                    else var a = TweenMax.fromTo(e, i.t.du, n, o);
                    return a
                }, _g.timeline.animation[8] = function(e, i) {
                    var n = t.param(e, i),
                        o = _.isNumber(i.d.op) ? Number(i.d.op) : 100;
                    if (n.css = {
                            "opacity": o / 100,
                            "force3D": !1
                        }, "stage" == i.aniType) var a = TweenMax.staggerTo(e, i.t.du, n, i.stagger);
                    else var a = TweenMax.to(e, i.t.du, n);
                    return a
                }, _g.timeline.animation[7] = function(e, i) {
                    var n = t.param(e, i),
                        o = _.isNumber(i.d.deg) ? Number(i.d.deg) : 0,
                        a = i.d.ax || 0,
                        s = "_cw",
                        r = "+";
                    o < 0 && (s = "_ccw"), o < 0 && (r = "-");
                    var l = {
                        "force3D": !1
                    };
                    if (0 == a && (l.rotation = r + "=" + Math.abs(o) + s), 1 == a && (l.rotationX = r + "=" + Math.abs(o) + s), 2 == a && (l.rotationY = r + "=" + Math.abs(o) + s), n.css = l, _g.device.android() && TweenLite.set(e, {
                            "transformPerspective": 2e3
                        }), "stage" == i.aniType) var c = TweenMax.staggerTo(e, i.t.du, n, i.stagger);
                    else var c = TweenMax.to(e, i.t.du, n);
                    return c
                }, _g.timeline.animation[9] = function(e, i) {
                    var n = t.param(e, i),
                        o = _.isNumber(i.d.sc) ? Number(i.d.sc) : 1;
                    if (n.css = {
                            "scale": o,
                            "force3D": !1
                        }, "stage" == i.aniType) var a = TweenMax.staggerTo(e, i.t.du, n, i.stagger);
                    else var a = TweenMax.to(e, i.t.du, n);
                    return a
                }, _g.timeline.animation[10] = function(e, i) {
                    var n = t.inparam(e, i),
                        o = t.toparam(e, i),
                        a = _.isNumber(i.d.op) ? Number(i.d.op) : 50,
                        s = _.isNumber(i.d.sc) ? Number(i.d.sc) : 2;
                    if (n.css = {
                            "opacity": a / 100,
                            "scale": s
                        }, o.css = {
                            "opacity": 1,
                            "scale": 1,
                            "force3D": !1
                        }, "stage" == i.aniType) var r = TweenMax.staggerFrom(e, i.t.du, n, i.stagger);
                    else var r = TweenMax.fromTo(e, i.t.du, n, o);
                    return r
                }, _g.timeline.animation[11] = function(e, i) {
                    var n = e.find("rect, circle, ellipse, polyline, path, line, polygon").not("[data-attr=morphCloneElement]"),
                        o = t.fromparam(e, i),
                        a = t.toparam(e, i);
                    return o.drawSVG = i.d.startx + "% " + i.d.starty + "%", a.drawSVG = i.d.endx + "% " + i.d.endy + "%", TweenMax.fromTo(n, i.t.du, o, a)
                }, _g.timeline.animation[12] = function(e, i) {
                    var n = {};
                    n.paths = [], n.otherPaths = [];
                    var o = 0;
                    if (_.each(i.d.pathIndex, function(t, e) {
                            null != t.selected && o++
                        }), o <= 1) return null;
                    if (_.each(i.d.pathIndex, function(t, e) {
                            null != t.selected ? n.paths.push({
                                "shapeIndex": t.selected,
                                "id": t.id
                            }) : n.otherPaths.push({
                                "id": t.id
                            })
                        }), n.paths.length >= 2) {
                        var a, s = function(t) {
                                return e.find("path#" + t.id)
                            },
                            r = function() {
                                $(p).attr("d", $(p).attr("data-original")), $(p).css($(p).data("initStyle")), $(p).data("show", !1)
                            },
                            l = function(t) {
                                return {
                                    "fill": t.css("fill") || "white",
                                    "fill-opacity": parseFloat(t.css("fill-opacity")) >= 0 ? parseFloat(t.css("fill-opacity")) : 1,
                                    "stroke": t.css("stroke") || "black",
                                    "stroke-opacity": parseFloat(t.css("stroke-opacity")) >= 0 ? parseFloat(t.css("stroke-opacity")) : 1,
                                    "stroke-width": parseFloat(t.css("stroke-width")) >= 0 ? parseFloat(t.css("stroke-width")) : 1
                                }
                            },
                            c = function() {
                                $(p).show().css({
                                    "stroke-dasharray": "none",
                                    "stroke-dashoffset": "none"
                                }), $(p).data("show", !0);
                                for (var t = 1; t < n.paths.length; t++) s(n.paths[t]).hide();
                                for (var t = 0; t < n.otherPaths.length; t++) {
                                    var e = s(n.otherPaths[t]);
                                    e.data("show") || e.hide()
                                }
                            },
                            d = function() {
                                c(), r()
                            },
                            u = function() {
                                $(p).data("show", !1)
                            },
                            h = i.t.du / (n.paths.length - 1),
                            f = t.toparam(e, i),
                            p = s(n.paths[0])[0];
                        $(p).data("initStyle") || $(p).data("initStyle", l($(p)));
                        for (var m = new TimelineMax({
                                "repeat": i.t.rp,
                                "onStart": d,
                                "onComplete": u
                            }), g = 0, v = 1; v < n.paths.length; v++) a = $.extend(!0, {
                            "morphSVG": {
                                "shape": function(t) {
                                    return e.find("path#clone_" + t.id)
                                }(n.paths[v])[0],
                                "shapeIndex": n.paths[v - 1].shapeIndex
                            }
                        }, f), a = $.extend(!0, l(s(n.paths[v])), a), m.add(TweenMax.to(p, h, a), g), g += h;
                        return m
                    }
                }, _g.timeline.create = function(t) {
                    var e = {
                            "paused": !0,
                            "onStart": function(e) {
                                t.model && t.model.iview && t.model.iview.$el.trigger("t_start")
                            },
                            "onComplete": function(e) {
                                t.model && t.model.iview && t.model.iview.$el.trigger("t_end")
                            },
                            "repeat": t.args ? t.args.rp : 0
                        },
                        i = 0,
                        n = new TimelineMax(e);
                    n.addLabel("Start");
                    var o = t.animations;
                    return _.each(o, function(t, e) {
                        var o = t.toJSON().data,
                            a = o.t.de,
                            s = o.t.st;
                        o.t.rp;
                        if (i += a, 2 == s)
                            if (0 != e) {
                                var r = n.getLabelTime(e - 1 + "_start");
                                n.addLabel(e + "_start", r + a), i = r + a
                            } else n.addLabel(e + "_start", i);
                        else n.addLabel(e + "_start", i);
                        o.d || (o.d = {});
                        var l = _g.timeline.animation[o.type](t.iview.$el, o);
                        n.add(l, i), i += o.t.du, t.siblingIds && _.each(t.siblingIds, function(t) {
                            var o = coolsite_play.animationlist.get(t);
                            if (o) {
                                var a = o.toJSON().data,
                                    s = a.t.de,
                                    r = a.t.st;
                                a.t.rp;
                                if (i += s, 2 == r)
                                    if (0 != e) {
                                        var l = n.getLabelTime(e - 1 + "_start");
                                        n.addLabel(e + "_start", l + s), i = l + s
                                    } else n.addLabel(e + "_start", i);
                                else n.addLabel(e + "_start", i);
                                a.d || (a.d = {});
                                var c = _g.timeline.animation[a.type](o.iview.$el, a);
                                n.add(c, i), i += a.t.du
                            }
                        })
                    }), n
                }
            }
        };
        n = [], (o = function() {
            return window._cs || (window._cs = {}), window._cs.sdk = i, window._cs.sdk
        }.apply(e, n)) !== undefined && (t.exports = o)
    }(window)
}, function(t, e, i) {
    "use strict";
    var n, o;
    ! function() {
        var i = {
            "ani": function() {
                coolsite_play.util.canvasCirAni = {
                    "init": function(t) {
                        var e = coolsite_play.doc.find(".c-section"),
                            i = [],
                            n = coolsite_play.doc.find("canvas");
                        e = _.filter(e, function(t) {
                            return 0 != $(t).find("canvas").length
                        });
                        for (var o = 0; o < e.length; o++) {
                            var a = $(e[o]).find("canvas");
                            if (a.length) {
                                if (i = _.uniq(i.concat(a)), t) {
                                    for (var s = 0; s < a.length; s++) coolsite_play.util.canvasCirAni.generate($(a[s]), "", t);
                                    return
                                }
                                $(e[o]).on("scrollIn", a, function(e) {
                                    e.preventDefault();
                                    for (var i = 0; i < a.length; i++) coolsite_play.util.canvasCirAni.generate($(a[i]), "", t);
                                    return !1
                                })
                            }
                        }
                        n = _.difference(n, i), _.each(n, function(e) {
                            coolsite_play.util.canvasCirAni.generate($(e), "", t)
                        })
                    },
                    "generate": function(t, e, i) {
                        function n() {
                            var t = Math.min(1, (Date.now() - p) / h);
                            o(t), t >= 1 ? g(v) : m(n)
                        }

                        function o(t) {
                            s.clearRect(0, 0, r, l), s.strokeStyle = a.backgroundColor, s.lineWidth = c, s.lineCap = "round", s.beginPath(), s.arc(f.x, f.y, d, 0, 2 * Math.PI, !1), s.stroke(), s.closePath(), s.strokeStyle = a.borderColor, s.beginPath(), s.arc(f.x, f.y, d, -.5 * Math.PI, (t * u * 2 - .5) * Math.PI, !1), s.stroke(), s.closePath(), a.showProgress && (s.fillStyle = a.fontColor, s.font = a.fontWeight + " " + a.fontSize + "px Helvetica", s.textBaseline = "middle", s.textAlign = "center", s.fillText(parseInt(a.progress * t), f.x, f.y, 2 * d))
                        }
                        var a = t.attr("part_data");
                        if (a) {
                            a = JSON.parse(a);
                            var s = t[0].getContext("2d"),
                                r = t.width(),
                                l = t.height(),
                                c = parseFloat(a.borderWidth),
                                d = Math.abs(Math.min(parseFloat(r - c) / 2, parseFloat(l - c) / 2)),
                                u = parseFloat(a.progress / a.max),
                                h = parseInt(a.duration),
                                f = {
                                    "x": parseFloat(r / 2),
                                    "y": parseFloat(l / 2)
                                };
                            if (i) o(1);
                            else if (a.isWait && !e) s.strokeStyle = a.backgroundColor, s.lineWidth = c, s.lineCap = "round", s.clearRect(0, 0, r, l), s.beginPath(), s.arc(f.x, f.y, d, 0, 2 * Math.PI, !1), s.stroke(), s.closePath();
                            else var p = Date.now(),
                                m = window.requestAnimationFrame || window.webkitRequestAnimationFrame || window.mozRequestAnimationFrame || window.msRequestAnimationFrame || window.oRequestAnimationFrame,
                                g = window.cancelAnimationFrame || window.webkitCancelAnimationFrame || window.mozCancelAnimationFrame || window.msCancelAnimationFrame || window.oCancelAnimationFrame,
                                v = m(n)
                        }
                    },
                    "stop": function() {
                        coolsite_play.util.canvasCirAni.init(!0)
                    }
                }
            }
        };
        n = [], (o = function() {
            return window._cs || (window._cs = {}), window._cs.canvascircle = i, window._cs.canvascircle
        }.apply(e, n)) !== undefined && (t.exports = o)
    }(window)
}, function(t, e, i) {
    "use strict";
    var n, o;
    ! function() {
        var i = {
                "actionexcutes": [],
                "init": function() {
                    if (coolsite360.PlayerPlugins.length)
                        for (var t = 0; t < coolsite360.PlayerPlugins.length; t++) {
                            var e = coolsite360.PlayerPlugins[t];
                            "actionexecute" == e.type ? coolsite_play.util.PluginManage.actionexcutes[e.config.type] = e : "wx" == e.type ? _cs.wx_register(e) : e.onInit && e.onInit()
                        }
                }
            },
            a = {
                "init": function() {
                    coolsite_play.util.PluginManage = i, coolsite_play.util.action = {
                        "generate": function() {
                            coolsite_play.doc.find("[data-c_act_id]").each(function() {
                                for (var t = this, e = $(this).attr("data-c_act_id"), i = String(e).split("|"), n = 0; n < i.length; n++) coolsite_play.actionlist.each(function(e) {
                                    if (e.id == i[n]) {
                                        e.getType();
                                        if (e.hasEl) {
                                            var o = $.extend(!0, {}, e.toJSON());
                                            delete o.id, coolsite_play.actionlist.add(o);
                                            var a = coolsite_play.actionlist.last();
                                            a.iview.setElement(t), a.hasEl = !0, e.siblingIds || (e.isSibling = !0, e.siblingIndex = 0, e.siblingIds = []), 0 == e.getType() && a.iview.$el.addClass("c-action-click"), e.siblingIds.push(a.id), a.isSibling = !0, a.siblingIndex = e.siblingIds.length
                                        } else e.iview.setElement(t), 0 == e.getType() && e.iview.$el.addClass("c-action-click"), e.hasEl = !0
                                    }
                                })
                            })
                        }
                    }, coolsite_play.util.animation = {
                        "generate": function() {
                            coolsite_play.doc.find("[data-c_ani_id]").each(function() {
                                for (var t = this, e = $(this).attr("data-c_ani_id"), i = String(e).split("|"), n = 0; n < i.length; n++) coolsite_play.animationlist.each(function(e) {
                                    if (e.id == i[n])
                                        if (e.hasEl) {
                                            var o = $.extend(!0, {}, e.toJSON());
                                            delete o.id, coolsite_play.animationlist.add(o);
                                            var a = coolsite_play.animationlist.last();
                                            a.iview.setElement(t), a.iview.stashStyle(), a.hasEl = !0, e.siblingIds || (e.siblingIds = []), e.siblingIds.push(a.id)
                                        } else e.iview.setElement(t), e.iview.stashStyle(), e.hasEl = !0
                                })
                            })
                        }
                    }, coolsite_play.util.timeline = {
                        "generate": function() {
                            coolsite_play.doc.find("[data-c_tl_id]").each(function() {
                                for (var t = $(this).attr("data-c_tl_id"), e = this, i = String(t).split("|"), n = 0; n < i.length; n++) coolsite_play.timelinelist.each(function(t) {
                                    t.id == i[n] && t.iview.setElement(e)
                                })
                            })
                        },
                        "createTimeline": function(t) {
                            return _g.timeline.create(t)
                        },
                        "stopAll": function() {
                            coolsite_play.timelinelist.each(function(t) {
                                t.stop()
                            })
                        }
                    }, coolsite_play.util.video = {
                        "init": function() {
                            _g.html5media.collect(document, "data-c_e_id")
                        },
                        "stopAll": function() {
                            _g.html5media.stopAll()
                        }
                    }, coolsite_play.slider = function(t, e) {
                        var i = new _g.transition({
                            "containment": t,
                            "disableControlled": !(!coolsite_play.isPreview && _g.device.mobile()),
                            "duration": 500,
                            "repeat": !0,
                            "control": !(coolsite_play.isPreview || !_g.device.mobile()),
                            "interval": 1e3 * Number(e.ti),
                            "type": Number(e.type),
                            "autoplayAxis": "x",
                            "onStart": function(e, n) {
                                i.setNavDots(t, n)
                            },
                            "onEnd": function(e, n) {
                                i.currentIndex = n, i.refreshSlideClass(t, n), "undefined" != typeof coolsite_editor && coolsite_editor.currentSlider && coolsite_editor.currentSlider.transitionEnd && coolsite_editor.currentSlider.transitionEnd(e, n);
                                var o = $(t).data("sliderId");
                                if (o) {
                                    coolsite_play.sliderlist.get(o).onChangeTo(e, n)
                                }
                            }
                        });
                        return i.clearSlideClass = function(t) {
                            $(t).children().removeClass("c-transition-left").removeClass("c-transition-right").removeClass("c-transition-top").removeClass("c-transition-bottom")
                        }, i.refreshSlideClass = function(t, e, n) {
                            n || (n = -1), i.clearSlideClass(t);
                            var o = $(t).children().length;
                            if (-1 == n) var a = "c-transition-right",
                                s = "c-transition-left";
                            else var a = "c-transition-left",
                                s = "c-transition-right";
                            $(t).children().each(function() {
                                $(this).index() == e ? ($(this).addClass("c-transition-current"), $(this).prev().length ? $(this).prev().addClass(s) : o > 1 && ($(t).children().last().is(this) || $(t).children().last().addClass(s)), $(this).next().length ? $(this).next().addClass(a) : o > 1 && ($(t).children().first().is(this) || $(t).children().first().addClass(a))) : $(this).removeClass("c-transition-current")
                            })
                        }, i.prepareNextClass = function(t, e, n) {
                            n || (n = -1), i.clearSlideClass(t);
                            $(t).children().length;
                            if (-1 == n) var o = "c-transition-right";
                            else var o = "c-transition-left";
                            $(t).children().each(function() {
                                $(this).index() == e && $(this).addClass(o)
                            })
                        }, i.setNavDots = function(t, e) {
                            var i = $(t).parent().children(".c-slider-nav").children(".c-slider-nav-dot");
                            i.removeClass("c-active"), i.eq(e).addClass("c-active")
                        }, i
                    }, coolsite_play.readCookie = function(t) {
                        for (var e = t + "=", i = document.cookie.split(";"), n = 0; n < i.length; n++) {
                            for (var o = i[n];
                                " " == o.charAt(0);) o = o.substring(1, o.length);
                            if (0 == o.indexOf(e)) return o.substring(e.length, o.length)
                        }
                        return null
                    }, coolsite_play.play = {
                        "start": function() {
                            if (coolsite_play.isPlay = !0, "undefined" == typeof c_data) return !1;
                            c_data.timelines = c_data.timelines || [], c_data.actions = c_data.actions || [], c_data.animations = c_data.animations || [], coolsite_play.doc = $("html"), c_data.timelines.length && coolsite_play.timelinelist.reset(c_data.timelines, {
                                "silent": !0
                            }), c_data.animations.length && coolsite_play.animationlist.reset(c_data.animations, {
                                "silent": !0
                            }), c_data.actions.length && coolsite_play.actionlist.reset(c_data.actions, {
                                "silent": !0
                            }), $("body").trigger("c_start"), coolsite_play.util.PluginManage.init(), coolsite_play.sliderlist.generate(), coolsite_play.util.timeline.generate(), coolsite_play.util.cssanimation && coolsite_play.util.cssanimation.generate(), coolsite_play.util.staggeranimation && coolsite_play.util.staggeranimation.generate(), coolsite_play.util.infinitescroll && coolsite_play.util.infinitescroll.generate(), coolsite_play.util.animation.generate(), coolsite_play.util.action.generate(), coolsite_play.util.canvasCirAni.init(), coolsite_play.util.mixContainer && coolsite_play.util.mixContainer.init(), coolsite_play.util.linkactive && coolsite_play.util.linkactive.generate(), coolsite_play.events.scroll.init(), _g.device.mobile() ? coolsite_play.events.touch.init() : coolsite_play.events.mousewheel.init(), coolsite_play.events.scroll.bindHashScroll(), coolsite_play.events.dialog.init(), coolsite_play.events.html.init(), coolsite_play.util.video.init(), coolsite_play.events.form.init(), _g.device.android() && $("body,.c-slider-mask").css({
                                "touch-action": "initial"
                            }), _g.device.mobile() || _g.device.tablet() || $(".c-dropdown-hover").children(".dropdown-toggle").addClass("disabled")
                        }
                    }, coolsite_play.isWindows = _g.device.windows(), coolsite_play.util.followAA = {
                        "generate": function(t, e) {
                            var i = $(t).find("[data-c_act_id]"),
                                n = $(t).find("[data-c_ani_id]");
                            i.length && coolsite_play.util.followAA.addActions(i, e), n.length && coolsite_play.util.followAA.addAnimation(n, e)
                        },
                        "addActions": function(t, e) {
                            for (var i = 0; i < t.length; i++)
                                for (var n = $(t[i]), o = n.attr("data-c_act_id"), a = String(o).split("|"), s = 0; s < a.length; s++) coolsite_play.actionlist.each(function(t) {
                                    if (t.id == a[s]) {
                                        var i = $.extend(!0, {}, t.toJSON());
                                        delete i.id, coolsite_play.actionlist.add(i);
                                        var o = coolsite_play.actionlist.last();
                                        o.iview.setElement(n), o.hasEl = !0, t.siblingIds && !e || (t.isSibling = !0, t.siblingIndex = 0, t.siblingIds = [], e && (e = !1)), 0 == t.getType() && o.iview.$el.addClass("c-action-click"), t.siblingIds.push(o.id), o.isSibling = !0;
                                        var r = t.siblingIds.length;
                                        e != undefined ? o.siblingIndex = r - 1 : o.siblingIndex = r
                                    }
                                })
                        },
                        "addAnimation": function(t, e) {
                            for (var i = 0; i < t.length; i++)
                                for (var n = $(t[i]), o = n.attr("data-c_ani_id"), a = String(o).split("|"), s = 0; s < a.length; s++) coolsite_play.animationlist.each(function(t, i) {
                                    if (t.id == a[s]) {
                                        var o = _.find(coolsite_play.timelinelist.models, function(e) {
                                                return -1 !== e.toJSON().animations.indexOf(t.id)
                                            }),
                                            r = $.extend(!0, {}, t.toJSON());
                                        delete r.id, coolsite_play.animationlist.add(r);
                                        var l = coolsite_play.animationlist.last();
                                        l.iview.setElement(n), l.iview.stashStyle(), l.hasEl = !0, t.siblingIds && !e || (t.siblingIds = [], e && (e = !1)), t.siblingIds.push(l.id), l.get("data").t.wa || coolsite_play.util.followAA.addToTimeline(l, o.timeline, i)
                                    }
                                })
                        },
                        "addToTimeline": function(t, e, i) {
                            if (e) {
                                var n = t.toJSON().data,
                                    o = e.totalDuration(),
                                    a = n.t.de,
                                    s = n.t.st;
                                n.t.rp;
                                if (o += a, 2 == s)
                                    if (0 != i) {
                                        var r = e.getLabelTime(i - 1 + "_start");
                                        e.addLabel(i + "_start", r + a), o = r + a
                                    } else e.addLabel(i + "_start", o);
                                else e.addLabel(i + "_start", o);
                                n.d || (n.d = {});
                                var l = _g.timeline.animation[n.type](t.iview.$el, n);
                                e.add(l, o)
                            }
                        },
                        "addToStagger": function(t, e, i) {
                            var n = coolsite_play.timelinelist.where({
                                    "id": t
                                })[0],
                                o = n.get("animations");
                            i && n.timeline.seek(n.timeline.duration()), coolsite_play.animationlist.each(function(t, i) {
                                var a = t.get("data").aniType;
                                if (-1 !== o.indexOf(t.id) && "stage" == a) {
                                    var s = $.extend(!0, {}, t.toJSON());
                                    delete s.id, coolsite_play.animationlist.add(s);
                                    var r = coolsite_play.animationlist.last(),
                                        l = r.get("data").selector,
                                        c = r.get("data").type,
                                        d = e.container.find(l);
                                    if (d.length && d.length > e.oldlength) {
                                        var u = d.slice(e.oldlength); - 1 != [1, 3, 5, 10].indexOf(c) && u.addClass("c-initHide"), r.iview.setElement(u), r.iview.stashStyle(), coolsite_play.util.followAA.addToTimeline(r, n.timeline, i)
                                    }
                                }
                            })
                        }
                    }
                }
            };
        n = [], (o = function() {
            return window._cs || (window._cs = {}), window._cs.util = a, window._cs.util
        }.apply(e, n)) !== undefined && (t.exports = o)
    }(window)
}, function(t, e, i) {
    "use strict";
    var n, o;
    ! function() {
        var i = {
            "init": function() {
                coolsite_play.util.cssanimation = {
                    "generate": function() {
                        var t = [],
                            e = [],
                            i = coolsite_play.util.cssanimation.findTimeline(t, e);
                        t = i.timeline, e = i.inBody, coolsite_play.doc.find("[data-c_cssani]").each(function() {
                            -1 != $(this).data("c_cssani").indexOf("In") && $(this).addClass("c-initHide")
                        });
                        for (var n = 0; n < t.length; n++) {
                            var o = $(t[n]);
                            "BODY" == o[0].tagName ? coolsite_play.util.cssanimation.addCssAni(e) : o.on("scrollIn", function(t) {
                                if ($(t.target).is(this) && ($(t.target).hasClass("c-slider") || $(t.target).hasClass("c-section"))) {
                                    var e = $(this);
                                    if (e.hasClass("c-slider")) {
                                        var i = e.find(".c-transition-current [data-c_cssani]");
                                        coolsite_play.util.cssanimation.addCssAni(i), e.find(".c-slide").each(function() {
                                            $(this).on("changeTo", function(t) {
                                                if ($(t.target).is(this)) {
                                                    var e = $(this),
                                                        i = e.find("[data-c_cssani]");
                                                    coolsite_play.util.cssanimation.addCssAni(i, ".c-slide", e)
                                                }
                                            }), $(this).on("recover", function(t) {
                                                if ($(t.target).is(this)) {
                                                    var e = $(this),
                                                        i = e.find("[data-c_cssani]");
                                                    coolsite_play.util.cssanimation.recoverCssAni(i, ".c-slide", e)
                                                }
                                            })
                                        })
                                    } else {
                                        var n = e.find("[data-c_cssani]");
                                        n.each(function() {
                                            $(this).closest(".c-slider").length || coolsite_play.util.cssanimation.addCssAni($(this), ".c-section", e)
                                        }), n.length && coolsite_play.util.refreshcontentlist.bindMasonry(e)
                                    }
                                }
                            })
                        }
                    },
                    "findTimeline": function(t, e) {
                        var i = coolsite_play.doc.find("[data-c_cssani]");
                        return _.each(i, function(i) {
                            var n = $(i).parents(".c-section,.c-slider")[0] || $("body"); - 1 == t.indexOf(n) && t.push(n), $(i).parents(".c-section")[0] || $(i).parents(".c-slider")[0] || !e || e.push(i)
                        }), {
                            "timeline": t,
                            "inBody": e
                        }
                    },
                    "addCssAni": function(t, e, i) {
                        _.each(t, function(t) {
                            if (!e || !i || $(t).parents(e)[0] == i[0]) {
                                var n = $(t).attr("data-c_cssani").split("|"),
                                    o = n[0],
                                    a = n[1],
                                    s = n[2],
                                    r = "1" == n[3] ? "infinite" : 1;
                                $(t).hasClass("cf-initHide") && $(t).removeClass("cf-initHide"), $(t).hasClass("c-initHide") && ($(t).data("initHide", !0), $(t).removeClass("c-initHide")), $(t).css({
                                    "animation-delay": parseFloat(s) + "s",
                                    "animation-duration": parseFloat(a) + "s",
                                    "animation-iteration-count": r
                                }).addClass(o + " animated").one("webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend", function() {
                                    $(t).css({
                                        "animation-delay": "0s",
                                        "animation-duration": "0s"
                                    }).removeClass(o + " animated")
                                })
                            }
                        })
                    },
                    "recoverCssAni": function(t, e, i) {
                        _.each(t, function(t) {
                            e && i && $(t).parents(e)[0] != i[0] || $(t).data("initHide") && $(t).addClass("c-initHide")
                        })
                    },
                    "removeAllViews": function() {
                        var t = [];
                        t = coolsite_play.util.cssanimation.findTimeline(t).timeline, _.each(t, function(t) {
                            $(t).off("scrollIn"), $(t).hasClass("c-slider") && $(t).find(".c-slide").off("changeTo")
                        })
                    }
                }
            }
        };
        n = [], (o = function() {
            return window._cs || (window._cs = {}), window._cs.ani = i, window._cs.ani
        }.apply(e, n)) !== undefined && (t.exports = o)
    }(window)
}, function(t, e, i) {
    "use strict";
    var n, o;
    ! function() {
        var i = {
            "init": function() {
                coolsite_play.util.staggeranimation = {
                    "generate": function() {
                        var t = _.filter(coolsite_play.animationlist.models, function(t) {
                            return "stage" == t.toJSON().data.aniType
                        });
                        _.each(t, function(t) {
                            var e = t.toJSON().data,
                                i = e.selector,
                                n = (e.stagger, _.find(coolsite_play.timelinelist.models, function(e) {
                                    return -1 != e.toJSON().animations.indexOf(t.id)
                                }));
                            if (n && i) {
                                var o = coolsite_play.doc.find("[data-c_tl_id=" + n.id + "]"),
                                    a = o.find(i);
                                t.iview.$el = a, t.iview.stashStyle()
                            }
                        })
                    },
                    "update": function(t) {
                        _.find(coolsite_play.timelinelist.models, function(e) {
                            return e.id == t
                        })
                    },
                    "removeAllViews": function() {}
                }
            }
        };
        n = [], (o = function() {
            return window._cs || (window._cs = {}), window._cs.stagger = i, window._cs.stagger
        }.apply(e, n)) !== undefined && (t.exports = o)
    }(window)
}, function(t, e, i) {
    "use strict";
    var n, o;
    ! function() {
        var i = {
            "init": function() {
                coolsite_play.util.infinitescroll = {
                    "generate": function() {
                        var t = coolsite_play.doc.find(".c-infinite");
                        _.each(t, function(t) {
                            var e = $(t).attr("class"),
                                i = $(t).attr("listtarget"),
                                n = "c-infinite-" + _g.uuid(2);
                            $(t).addClass(n);
                            var o, a;
                            if (e) {
                                if (!$(t).children().length || !$(t).children().eq(0).children().length) return;
                                if (!(o = "." + $($(t).children().children()[0]).attr("class"))) return;
                                o = o.trim().split(" ").join("."), a = $(t).children().eq(0), e = "." + n;
                                $(t).height();
                                $(t).css({
                                    "height": "auto",
                                    "overflow": "visible"
                                }), $(t).addClass("hide-scrollbar");
                                var s;
                                if ($(t).children(".row").length && ($(t).children(".row").css("height", "auto"), s = $(t).children(".row").data("masonry")), $(t).find(".page-load-status").length || $(t).append("<div class='page-load-status' style='height:1px;text-align: center;color: #777;'><p class='infinite-scroll-request'>Loading...</p> </div> "), $(t).attr("infinitescroll") && o) {
                                    if (a.data("infiniteScroll")) return;
                                    var s = $(t).children(".row").data("masonry"),
                                        r = $(t).attr("isRefresh");
                                    r != undefined && (r = !1);
                                    var l = (window.location.pathname, a.infiniteScroll({
                                            "debug": !0,
                                            "path": function() {
                                                if (this.isLastPage) return null;
                                                var t = window.location.pathname + "?page=" + (this.pageIndex + 1) + "&ajax=1&list_id=" + i;
                                                return coolsite_play.cmsfilter && coolsite_play.cmsfilter[i] && (t += coolsite_play.cmsfilter[i]), t
                                            },
                                            "append": o,
                                            "status": e + " .page-load-status",
                                            "checkLastPage": !0,
                                            "scrollThreshold": 1,
                                            "responseType": "document",
                                            "loadOnScroll": !0,
                                            "history": !1,
                                            "outlayer": s
                                        })),
                                        c = l.data("infiniteScroll"),
                                        d = 0;
                                    c.on("scrollThreshold", function() {}), c.on("request", function(t) {}), c.on("load", function(t, e) {
                                        var i = o.replace(/\./g, " ").trim(); - 1 == t.body.innerHTML.indexOf(i) && (this.isLastPage = !0), d = a.find(o).length
                                    }), c.on("append", function(t, e) {
                                        var i = a.find(o);
                                        coolsite_play.util.refreshcontentlist.appendAA(a, d, !0);
                                        for (var n = d; n < i.length; n++) coolsite_play.util.followAA.generate(i[n], r), coolsite_play.util.refreshcontentlist.initQrcode(i[n]);
                                        a.closest(".masonry").length && coolsite_play.util.refreshcontentlist.bindMasonry(a.closest(".masonry"))
                                    }), c.on("last", function(t, e) {})
                                }
                            }
                        })
                    },
                    "stop": function(t) {
                        var e = $(t),
                            i = e.children().eq(0);
                        i.data("infiniteScroll") && (i.infiniteScroll("destroy"), i.data("infiniteScroll", null))
                    }
                }
            }
        };
        n = [], (o = function() {
            return window._cs || (window._cs = {}), window._cs.infinitescroll = i, window._cs.infinitescroll
        }.apply(e, n)) !== undefined && (t.exports = o)
    }(window)
}, function(t, e, i) {
    "use strict";
    var n, o;
    ! function() {
        var i = {
            "init": function() {
                if ($("iframe[allowscreenadapt='allowscreenadapt']")) {
                    var t = $("iframe[allowscreenadapt='allowscreenadapt']"),
                        e = $("iframe[allowscreenadapt='allowscreenadapt']").parent(),
                        i = document.createElement("div");
                    i.className = "embed-responsive embed-responsive-16by9", e.append(i), $(i).append(t)
                }
            }
        };
        n = [], (o = function() {
            return window._cs || (window._cs = {}), window._cs.media = i, window._cs.media
        }.apply(e, n)) !== undefined && (t.exports = o)
    }(window)
}, function(t, e, i) {
    "use strict";
    var n, o;
    ! function() {
        var i = {
            "init": function() {
                coolsite_play.util.refreshcontentlist = {
                    "generate": function(t) {
                        t || (t = coolsite_play.doc.find(".c-contentlistviewv2")), t.each(function() {
                            var t = $(this),
                                e = t.attr("ajaxload");
                            t.find("nav a").each(function() {
                                var i = $(this);
                                i.off("click").on("click", function(n) {
                                    if (e) {
                                        n.preventDefault();
                                        var o = i.attr("href");
                                        coolsite_play.util.refreshcontentlist.refresh(o, t)
                                    }
                                })
                            })
                        })
                    },
                    "refresh": function(t, e) {
                        $.ajax({
                            "type": "GET",
                            "url": t,
                            "success": function(t) {
                                if (e && (coolsite_play.util.infinitescroll.stop(e), e.replaceWith(t), $(t).attr("class"))) {
                                    var i = "." + $(t).attr("class").trim().split(" ").join(".");
                                    $(i).attr("isRefresh", !0), coolsite_play.util.refreshcontentlist.appendAA($(i)), coolsite_play.util.refreshcontentlist.bindMasonry($(i)), coolsite_play.util.refreshcontentlist.initQrcode($(i))
                                }
                            }
                        })
                    },
                    "appendAA": function(t, e, i) {
                        if (t) {
                            e === undefined && (e = 0), i || (coolsite_play.util.followAA.generate(t, !0), coolsite_play.util.refreshcontentlist.generate(t), coolsite_play.util.infinitescroll.generate());
                            var n = t.parents("div[data-c_tl_id]");
                            if (n.length) {
                                var o = n.eq(0).attr("data-c_tl_id");
                                coolsite_play.util.followAA.addToStagger(o, {
                                    "oldlength": e,
                                    "container": t
                                }, !i)
                            }
                        }
                    },
                    "bindMasonry": function(t) {
                        var e;
                        0 != t.find(".masonry").length ? e = t.find(".masonry") : t.hasClass("masonry") && (e = t), e && e.each(function() {
                            if ($(this).children().eq(0).hasClass("c-row")) {
                                var t = $(this).children().eq(0);
                                t.masonry({
                                    "resize": !0
                                }), t.imagesLoaded().progress(function() {
                                    t.masonry("layout")
                                })
                            } else {
                                var t = $(this);
                                $(this).masonry({
                                    "resize": !0
                                }), t.imagesLoaded().progress(function() {
                                    t.masonry("layout")
                                })
                            }
                        })
                    },
                    "initQrcode": function(t) {
                        if (t) {
                            var e = $(t).find(".c-qrcode");
                            _.each(e, function(t) {
                                var e = $(t).attr("qrcode"),
                                    i = $(t).attr("href");
                                if (e && "$current_url" == e && !i || "#" == i ? i = window.location.href : e || i && (i = window.location.origin + i), -1 === i.indexOf("://") && (i = "http://" + i), i) {
                                    var n = $("<div></div>");
                                    n.qrcode({
                                        "text": i
                                    });
                                    var o = n.find("canvas")[0].toDataURL("image/png");
                                    $(t).attr("src", o)
                                }
                            })
                        }
                    }
                }
            }
        };
        n = [], (o = function() {
            return window._cs || (window._cs = {}), window._cs.refreshcontentlist = i, window._cs.refreshcontentlist
        }.apply(e, n)) !== undefined && (t.exports = o)
    }(window)
}, function(t, e, i) {
    "use strict";
    var n, o;
    ! function() {
        var i = {
            "init": function() {
                coolsite_play.util.linkactive = {
                    "generate": function() {
                        var t = coolsite_play.doc.find("a[iactive= 'True']"),
                            e = window.page_slug,
                            i = window.location.pathname,
                            n = {};
                        _.each(t, function(t) {
                            var o = $(t),
                                a = o.attr("href");
                            a && (0 == a.indexOf("#") ? (n[a] || (n[a] = []), n[a].push(o)) : a.match(/\w+\.html/i) ? (a = a.match(/\w+\.html/i)[0], a.replace(".html", "") === e && coolsite_play.util.linkactive.bindActive(o)) : i == a && coolsite_play.util.linkactive.bindActive(o))
                        });
                        for (var o in n) this.bindScroll(o, n[o])
                    },
                    "bindScroll": function(t, e) {
                        if (t) {
                            var i = $(t);
                            i.off("scrollIn", "**").on("scrollIn", function(t) {
                                e.forEach(function(t) {
                                    var e = t.closest(".c_link_group");
                                    e.length && $(e).find("a[iactive= 'True']").each(function() {
                                        var t = $(this);
                                        t.removeClass("active"), t.parent("li").length && t.parent("li").removeClass("active")
                                    }), coolsite_play.util.linkactive.bindActive(t)
                                })
                            }), i.off("scrollOut").on("scrollOut", function(t) {
                                e.forEach(function(t) {
                                    coolsite_play.util.linkactive.bindRemoveActive(t)
                                })
                            })
                        }
                    },
                    "bindActive": function(t) {
                        t.addClass("active"), t.parent("li").length && t.parent("li").addClass("active"), t.closest(".dropdown").length && t.closest(".dropdown").addClass("active").find(".dropdown-toggle").addClass("active")
                    },
                    "bindRemoveActive": function(t) {
                        t.removeClass("active"), t.parent("li").length && t.parent("li").removeClass("active"), t.closest(".dropdown").length && t.closest(".dropdown").removeClass("active").find(".dropdown-toggle").removeClass("active")
                    }
                }
            }
        };
        n = [], (o = function() {
            return window._cs || (window._cs = {}), window._cs.linkactive = i, window._cs.linkactive
        }.apply(e, n)) !== undefined && (t.exports = o)
    }(window)
}, function(t, e, i) {
    "use strict";
    ! function(t, e) {
        var i = {};
        i.Event = {}, i.Dom = {}, i.Config = {}, i.Tree = {}, i.Config = {
            "book": ".book",
            "left": ".book-summary",
            "right": ".book-body",
            "search": ".book-search-input",
            "catalog": ".summary",
            "prev": ".navigation-prev",
            "next": ".navigation-next",
            "content": ".markdown-section",
            "content_wrap": ".page-inner",
            "search_result": ".search-results",
            "search_query": ".search-query",
            "search_count": ".search-results-count"
        }, i.Tree.Config = {
            "isCatalog": !1,
            "container": ".summary",
            "initOpen": !1,
            "el": "a",
            "catalogEl": "a",
            "activeClass": "active",
            "hoverClass": "hover",
            "currentItem": 0,
            "currentCatalog": -1,
            "preItem": 0,
            "preCatalog": -1,
            "firstItem": 0
        }, i.Dom = {
            "init": function() {
                var t = this;
                this.initLeft(), this.initNav(), this.getSearch(), i.Tree.Dom.init(), e.onpopstate = function(e) {
                    var n = e.state;
                    if (n && n.url && n.index) i.Tree.Event.setActive(n.index), t.ajaxLoad(n.url);
                    else if (null === n && !location.hash) {
                        var o = i.Tree.Config.firstItem,
                            a = location.pathname,
                            s = _.compact(a.split("/")),
                            r = s[s.length - 1];
                        i.Tree.Event.setActive(o), t.ajaxLoad(r)
                    }
                }
            },
            "getSearch": function() {
                var n = this,
                    o = e.search_index_url,
                    a = e.export_local,
                    s = function(t) {
                        var i = new RegExp("(^|&)" + t + "=([^&]*)(&|$)"),
                            n = e.location.search.substr(1).match(i);
                        return null != n ? decodeURI(n[2]) : null
                    }("q");
                o && !a ? t.ajax({
                    "url": o,
                    "type": "GET",
                    "success": function(o) {
                        n.store = o.store, n.index = e.lunr && lunr.Index.load(o.index), s && (t(i.Config.search).find("input").val(s), n.searchHandle(s))
                    }
                }) : e.search_index && (this.store = e.search_index.store, this.index = e.lunr && lunr.Index.load(e.search_index.index), s && (t(i.Config.search).find("input").val(s), n.searchHandle(s)))
            },
            "initLeft": function() {
                var e = i.Config.catalog,
                    n = this,
                    o = t(e).find("a"),
                    a = t(i.Config.search),
                    s = t(i.Config.search_result),
                    r = i.Config.book;
                s.css("display", "none"), o.off("click").on("click", function(e) {
                    _g.device.mobile() && t(r).toggleClass("hide-summary"), n.refresh(e)
                }), a.find("input").on("change", function(e) {
                    var i, n = t(e.currentTarget).val();
                    n ? (i = location.pathname + "?q=" + n, history.pushState(null, null, i)) : (i = location.pathname, history.pushState(null, null, i))
                }), a.find("input").on("keyup", function(e) {
                    var i = t(e.currentTarget).val();
                    n.searchHandle(i)
                })
            },
            "searchHandle": function(e) {
                var n = t(i.Config.search_result),
                    o = t(i.Config.content),
                    a = n.find(i.Config.search_count),
                    s = i.Config.search_query;
                if (!e) return n.css("display", "none"), void o.css("display", "block");
                var r = this.index && this.index.search(e) || [],
                    l = this.store;
                if (n.css("display", "block"), o.css("display", "none"), r.length) {
                    n.find(".no-results").css("display", "none"), n.find(".has-results ul").empty(), n.find(".has-results").find(s).html(e), a.html(r.length);
                    for (var c = 0; c < r.length; c++) {
                        var d = r[c] && r[c].ref;
                        if (d) {
                            var u = l[d];
                            u && this.renderSearchResult(u)
                        }
                    }
                    n.find(".has-results").css("display", "block")
                } else this.renderSearchResult("", e)
            },
            "renderSearchResult": function(e, n) {
                var o = t(i.Config.search_result),
                    a = i.Config.search_query;
                if (e) {
                    var s = "<li class='search-results-item'><h3><a class='c-textlink' href='" + e.id + "'>" + e.title + "</a></h3><p class='c-paragraph'>" + e.body + "</p></li>";
                    o.find(".has-results ul").append(s)
                } else o.find(".no-results").css("display", "block").find(a).html(n), o.find(".has-results").css("display", "none")
            },
            "initNav": function() {
                var e = i.Config,
                    n = this;
                t(e.prev).attr({
                    "data-item": !1
                }).off("click").on("click", function(t) {
                    n.refresh(t)
                }), t(e.next).attr({
                    "data-item": !0
                }).off("click").on("click", function(t) {
                    n.refresh(t)
                })
            },
            "setCurrent": function(t) {
                t && (this.currentCatalog.removeClass("active"), this.currentCatalog = t), this.currentCatalog.addClass("active")
            },
            "replaceDoc": function(n) {
                n = n.replace(/<(\/?)(html|head|body)([^>]*)>/gi, function(t, e, i, n) {
                    return "<" + e + "div" + (e ? "" : ' data-element="' + i + '"') + n + ">"
                });
                var o = t(n),
                    a = o.find("[data-element='head']"),
                    s = o.find("[data-element='body']"),
                    r = i.Config,
                    l = a.find("title").html(),
                    c = s.find(r.content).html(),
                    d = s.find(r.prev),
                    u = s.find(r.next);
                this.replaceTitle(l), this.replaceContent(c), this.replaceNav(d, u), e.MathJax && MathJax.Hub.Queue(["Typeset", MathJax.Hub])
            },
            "replaceTitle": function(e) {
                e && t("head title").html(e)
            },
            "replaceContent": function(e) {
                var n = i.Config.content;
                e && t(n).html(e);
                var o = i.Config.content_wrap;
                t(o).scrollTop(0)
            },
            "replaceNav": function(e, n) {
                var o = i.Config,
                    a = t(o.prev),
                    s = t(o.next),
                    r = e.attr("href"),
                    l = n.attr("href");
                e.length && !a.length ? (e.insertAfter(t(o.content_wrap)), this.initNav()) : !e.length && a.length ? a.remove() : t(o.prev).attr("href", r), n.length && !s.length ? (t(o.content_wrap).parent().append(n), this.initNav()) : !n.length && s.length ? s.remove() : t(o.next).attr("href", l)
            },
            "refresh": function(n) {
                var o = t(n.currentTarget),
                    a = o.attr("href"),
                    s = o.attr("data-item"),
                    r = new RegExp(/^([0-9a-f]+)(\.md)?/),
                    l = a.split("/");
                if (l = _.compact(l), !e.export_local && r.test(l[l.length - 1])) return n && n.preventDefault(), i.Tree.Event.bindActive(s), this.ajaxLoad(a, function() {
                    history.pushState({
                        "url": a,
                        "index": s
                    }, null, a)
                }), !1
            },
            "ajaxLoad": function(e, n) {
                var o = this;
                e && t.ajax({
                    "url": e,
                    "type": "GET",
                    "success": function(e) {
                        e && (n && n(), o.replaceDoc(e), o.searchHandle(), t(i.Config.search).find("input").val(""))
                    }
                })
            },
            "search": function() {}
        }, i.Tree.Dom = {
            "item": [],
            "init": function() {
                this.getItem()
            },
            "setCurrent": function() {},
            "getItem": function() {
                var e = i.Tree.Config,
                    n = this;
                Array.prototype.slice.call(t(e.container).find(e.el)).forEach(function(e, o) {
                    if (t(e).attr("data-item", o), t(e).hasClass("active")) {
                        t(e).attr("href");
                        i.Tree.Config.currentItem = o, i.Tree.Config.firstItem = o
                    }
                    n.item || (n.item = []), n.item.push(e)
                })
            }
        }, i.Tree.Event = {
            "bindActive": function(t) {
                this.setActive(t)
            },
            "setItemIndex": function(t) {
                var e, n = i.Tree.Config.currentItem;
                if ("boolean" == typeof t ? e = t ? n + 1 : n - 1 : "true" === t ? e = n + 1 : "false" === t ? e = n - 1 : "number" == typeof Number(t) && (e = Number(t)), e !== undefined) return i.Tree.Config.currentItem = e, i.Tree.Config.preItem = n, {
                    "pre": n,
                    "current": e
                }
            },
            "setActive": function(t) {
                var e = this.setItemIndex(t);
                this.setActiveByIndex(e)
            },
            "pre": function() {
                this.setActive(!1)
            },
            "next": function() {
                this.setActive(!0)
            },
            "setActiveByIndex": function(e) {
                e || (e = {});
                var n = Number(e.pre),
                    o = Number(e.current),
                    a = i.Tree.Dom.item;
                n != undefined && a[n] && t(a[n]).removeClass("active"), o != undefined && a[o] && t(a[o]).addClass("active")
            }
        }, e.Book = i, e.Book.Dom.init()
    }(jQuery, window)
}, function(t, e, i) {
    "use strict";
    var n, o;
    ! function(i, a) {
        var s = {
            "init": function() {
                coolsite_play.util.mixContainer = {
                    "init": function() {
                        var t = this;
                        this.multiData = {}, Array.prototype.slice.call(coolsite_play.doc.find("[filter-type]")).forEach(function(e) {
                            var n = i(e),
                                o = n.attr("filter-list"),
                                s = n.attr("filter-type"),
                                r = n.attr("list-class"),
                                l = n.hasClass("cs-repeatable");
                            if (o && s) {
                                var c = a.location.pathname + "?list_id=" + o;
                                n.off("sourceChange").on("sourceChange", function(e, a) {
                                    var l = t.getUrlParam(a, s),
                                        d = c + l;
                                    if (n.parents(".multi-filter").length) {
                                        for (var u in t.multiData) u !== s && (d += t.multiData[u]);
                                        t.multiData[s] = l
                                    }
                                    coolsite_play.cmsfilter || (coolsite_play.cmsfilter = {}), coolsite_play.cmsfilter[o] = l, coolsite_play.util.refreshcontentlist.refresh(d, i("." + r))
                                })
                            }
                            l ? t.bindSourceItem(n) : t.bindEvent(n)
                        })
                    },
                    "bindEvent": function(t) {
                        var e = this; - 1 !== ["input", "select"].indexOf(t.prop("tagName")) ? e.bindChange(t) : t.find("li").each(function() {
                            var n = i(this);
                            e.bindClick(n, t)
                        })
                    },
                    "bindSourceItem": function(t) {
                        var e = t || coolsite_play.doc,
                            n = e.find("[rel-item]"),
                            o = ["INPUT", "SELECT", "TEXTAREA", "RADIO", "CHECKBOX"],
                            a = ["P", "SPAN", "A"],
                            s = this;
                        _.each(n, function(t) {
                            var e = i(t),
                                n = e.prop("tagName"),
                                r = e.closest("[filter-type]");
                            r.length && (e.attr("contenteditable") || (-1 !== a.indexOf(n) ? s.bindClick(e, r) : -1 !== o.indexOf(n) && s.bindChange(e, r)))
                        })
                    },
                    "bindClick": function(t, e) {
                        t.off("click").on("click", function(n) {
                            if (n.currentTarget == t[0]) {
                                var o = i(t).val() || i(t).attr("href") || i(t).text(),
                                    a = e.find("[rel-display]");
                                a.length && a.eq(0).text(o), e.trigger("sourceChange", o)
                            }
                            return !1
                        })
                    },
                    "bindChange": function(t, e) {
                        e || (e = t), t.off("change").on("change", function(n) {
                            if (n.currentTarget == t) {
                                var o = i(t).val();
                                e.trigger("sourceChange", o)
                            }
                            return !1
                        })
                    },
                    "bindBlur": function(t, e) {},
                    "getUrlParam": function(t, e) {
                        t || (t = "");
                        var i = "";
                        switch (e) {
                            case "category":
                                i = "&categories=" + t;
                                break;
                            case "tag":
                                i = "&tags=" + t;
                                break;
                            case "keyword":
                                i = "&keywords=" + t
                        }
                        return i
                    }
                }
            }
        };
        n = [], (o = function() {
            return a._cs || (a._cs = {}), a._cs.mixContainer = s, a._cs.mixContainer
        }.apply(e, n)) !== undefined && (t.exports = o)
    }(jQuery, window)
}, function(t, e, i) {
    "use strict";

    function n(t, e, i) {
        return e in t ? Object.defineProperty(t, e, {
            "value": i,
            "enumerable": !0,
            "configurable": !0,
            "writable": !0
        }) : t[e] = i, t
    }
    var o, a;
    ! function() {
        var i = {
            "init": function() {
                window.coolsite_play = {
                    "model": n({
                        "animation": {},
                        "action": {},
                        "timeline": {},
                        "element": {}
                    }, "action", {}),
                    "view": n({
                        "animation": {},
                        "action": {},
                        "timeline": {},
                        "element": {}
                    }, "action", {}),
                    "controller": n({
                        "animation": {},
                        "action": {},
                        "timeline": {},
                        "element": {}
                    }, "action", {}),
                    "collection": {},
                    "ui": {},
                    "events": {},
                    "util": {},
                    "varible": {}
                }, coolsite_play.isPreview = !1, coolsite_play.scrollItems = [], coolsite_play.sectionItems = [], coolsite_play.currentActiveIndex = null, coolsite_play.isSectionSwitching = null, coolsite_play.isSectionLock = null, coolsite_play.animationCommonArgs = {
                    "de": 0,
                    "du": 1,
                    "rp": 0,
                    "rv": 0,
                    "st": 1,
                    "es": 0,
                    "wa": 0
                }, coolsite_play.animationArgs = {
                    "1": {
                        "di": 0,
                        "dt": 0,
                        "dl": 0
                    },
                    "2": {
                        "di": 0,
                        "dt": 0,
                        "dl": 0
                    },
                    "3": {},
                    "4": {},
                    "7": {
                        "deg": 0,
                        "ax": 0
                    },
                    "8": {
                        "op": 100
                    },
                    "9": {
                        "sc": 1
                    },
                    "10": {
                        "sc": 2,
                        "op": 50
                    },
                    "11": {
                        "startx": 0,
                        "starty": 0,
                        "endx": 0,
                        "endy": 100
                    }
                }, coolsite_play.easeType = {
                    "0": "Linear.easeNone",
                    "1": "Power0.easeIn",
                    "2": "Power0.easeInOut",
                    "3": "Power0.easeOut",
                    "4": "Power1.easeIn",
                    "5": "Power1.easeInOut",
                    "6": "Power1.easeOut",
                    "7": "Power2.easeIn",
                    "8": "Power2.easeInOut",
                    "9": "Power2.easeOut",
                    "10": "Power3.easeIn",
                    "11": "Power3.easeInOut",
                    "12": "Power3.easeOut",
                    "13": "Power4.easeIn",
                    "14": "Power4.easeInOut",
                    "15": "Power4.easeOut",
                    "16": "Quad.easeIn",
                    "17": "Quad.easeInOut",
                    "18": "Quad.easeOut",
                    "19": "Cubic.easeIn",
                    "20": "Cubic.easeInOut",
                    "21": "Cubic.easeOut",
                    "22": "Quart.easeIn",
                    "23": "Quart.easeInOut",
                    "24": "Quart.easeOut",
                    "25": "Quint.easeIn",
                    "26": "Quint.easeInOut",
                    "27": "Quint.easeOut",
                    "28": "Strong.easeIn",
                    "29": "Strong.easeInOut",
                    "30": "Strong.easeOut",
                    "31": "Back.easeIn",
                    "32": "Back.easeInOut",
                    "33": "Back.easeOut",
                    "34": "Bounce.easeIn",
                    "35": "Bounce.easeInOut",
                    "36": "Bounce.easeOut",
                    "37": "Circ.easeIn",
                    "38": "Circ.easeInOut",
                    "39": "Circ.easeOut",
                    "40": "Elastic.easeIn",
                    "41": "Elastic.easeInOut",
                    "42": "Elastic.easeOut",
                    "43": "Expo.easeIn",
                    "44": "Expo.easeInOut",
                    "45": "Expo.easeOut",
                    "46": "Sine.easeIn",
                    "47": "Sine.easeInOut",
                    "48": "Sine.easeOut",
                    "49": "SlowMo.ease"
                }, coolsite_play.elementReference = {
                    "c-section": "section",
                    "c-container": "container",
                    "c-image": "image",
                    "c-slider": "slider",
                    "c-button": "button",
                    "c-row": "row",
                    "c-column": "column",
                    "c-paragraph": "c-paragraph",
                    "c-heading": "heading",
                    "c-div": "div",
                    "c-list": "list",
                    "c-listitem": "listitem",
                    "c-textblock": "textblock",
                    "c-slidermask": "slidermask",
                    "c-slide": "slide",
                    "c-linkblock": "lineblock",
                    "c-textlink": "textlink",
                    "c-leftarrow": "leftarrow",
                    "c-rightarrow": "rightarrow",
                    "c-icon": "icon",
                    "c-slidernav": "slidernav",
                    "c-slidernavdot": "slidernavdot"
                }, coolsite_play.elementState = {
                    "state1": "c-state1",
                    "state2": "c-state2",
                    "state3": "c-state3"
                }
            },
            "start": function(t) {
                coolsite_play.animationlist = new coolsite_play.collection.animation, coolsite_play.timelinelist = new coolsite_play.collection.timeline, coolsite_play.sliderlist = new coolsite_play.collection.slider, coolsite_play.actionlist = new coolsite_play.collection.action
            }
        };
        o = [], (a = function() {
            return window._cs || (window._cs = {}), window._cs.variable = i, window._cs.variable
        }.apply(e, o)) !== undefined && (t.exports = a)
    }(window)
}, function(t, e, i) {
    "use strict";
    var n, o, a, s, r, n, l, c, d, u, n, h, n, f, p, n, m, f, n, o, g = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
        return typeof t
    } : function(t) {
        return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
    };
    ! function(a, s) {
        n = [i(0)], (o = function(t) {
            return s(a, t)
        }.apply(e, n)) !== undefined && (t.exports = o)
    }(window, function(t, e) {
        function i(i, a, r) {
            function l(t, e, n) {
                var o, a = "$()." + i + '("' + e + '")';
                return t.each(function(t, l) {
                    var c = r.data(l, i);
                    if (!c) return void s(i + " not initialized. Cannot call methods, i.e. " + a);
                    var d = c[e];
                    if (!d || "_" == e.charAt(0)) return void s(a + " is not a valid method");
                    var u = d.apply(c, n);
                    o = void 0 === o ? u : o
                }), void 0 !== o ? o : t
            }

            function c(t, e) {
                t.each(function(t, n) {
                    var o = r.data(n, i);
                    o ? (o.option(e), o._init()) : (o = new a(n, e), r.data(n, i, o))
                })
            }(r = r || e || t.jQuery) && (a.prototype.option || (a.prototype.option = function(t) {
                r.isPlainObject(t) && (this.options = r.extend(!0, this.options, t))
            }), r.fn[i] = function(t) {
                if ("string" == typeof t) {
                    return l(this, t, o.call(arguments, 1))
                }
                return c(this, t), this
            }, n(r))
        }

        function n(t) {
            !t || t && t.bridget || (t.bridget = i)
        }
        var o = Array.prototype.slice,
            a = t.console,
            s = void 0 === a ? function() {} : function(t) {
                a.error(t)
            };
        return n(e || t.jQuery), i
    }),
    function(t, e) {
        s = e, r = {
            "id": "ev-emitter/ev-emitter",
            "exports": {},
            "loaded": !1
        }, a = "function" == typeof s ? s.call(r.exports, i, r.exports, r) : s, r.loaded = !0, a === undefined && (a = r.exports)
    }("undefined" != typeof window ? window : undefined, function() {
        function t() {}
        var e = t.prototype;
        return e.on = function(t, e) {
            if (t && e) {
                var i = this._events = this._events || {},
                    n = i[t] = i[t] || [];
                return -1 == n.indexOf(e) && n.push(e), this
            }
        }, e.once = function(t, e) {
            if (t && e) {
                this.on(t, e);
                var i = this._onceEvents = this._onceEvents || {};
                return (i[t] = i[t] || {})[e] = !0, this
            }
        }, e.off = function(t, e) {
            var i = this._events && this._events[t];
            if (i && i.length) {
                var n = i.indexOf(e);
                return -1 != n && i.splice(n, 1), this
            }
        }, e.emitEvent = function(t, e) {
            var i = this._events && this._events[t];
            if (i && i.length) {
                var n = 0,
                    o = i[n];
                e = e || [];
                for (var a = this._onceEvents && this._onceEvents[t]; o;) {
                    var s = a && a[o];
                    s && (this.off(t, o), delete a[o]), o.apply(this, e), n += s ? 0 : 1, o = i[n]
                }
                return this
            }
        }, t
    }),
    function(t, i) {
        n = [], l = function() {
            return i()
        }.apply(e, n)
    }(window, function() {
        function t(t) {
            var e = parseFloat(t);
            return -1 == t.indexOf("%") && !isNaN(e) && e
        }

        function e() {}

        function i() {
            for (var t = {
                    "width": 0,
                    "height": 0,
                    "innerWidth": 0,
                    "innerHeight": 0,
                    "outerWidth": 0,
                    "outerHeight": 0
                }, e = 0; c > e; e++) {
                t[l[e]] = 0
            }
            return t
        }

        function n(t) {
            var e = getComputedStyle(t);
            return e || r("Style returned " + e + ". Are you running this code in a hidden iframe on Firefox? See http://bit.ly/getsizebug1"), e
        }

        function o() {
            if (!d) {
                d = !0;
                var e = document.createElement("div");
                e.style.width = "200px", e.style.padding = "1px 2px 3px 4px", e.style.borderStyle = "solid", e.style.borderWidth = "1px 2px 3px 4px", e.style.boxSizing = "border-box";
                var i = document.body || document.documentElement;
                i.appendChild(e);
                var o = n(e);
                a.isBoxSizeOuter = s = 200 == t(o.width), i.removeChild(e)
            }
        }

        function a(e) {
            if (o(), "string" == typeof e && (e = document.querySelector(e)), e && "object" == (void 0 === e ? "undefined" : g(e)) && e.nodeType) {
                var a = n(e);
                if ("none" == a.display) return i();
                var r = {};
                r.width = e.offsetWidth, r.height = e.offsetHeight;
                for (var d = r.isBorderBox = "border-box" == a.boxSizing, u = 0; c > u; u++) {
                    var h = l[u],
                        f = a[h],
                        p = parseFloat(f);
                    r[h] = isNaN(p) ? 0 : p
                }
                var m = r.paddingLeft + r.paddingRight,
                    v = r.paddingTop + r.paddingBottom,
                    y = r.marginLeft + r.marginRight,
                    _ = r.marginTop + r.marginBottom,
                    w = r.borderLeftWidth + r.borderRightWidth,
                    b = r.borderTopWidth + r.borderBottomWidth,
                    $ = d && s,
                    C = t(a.width);
                !1 !== C && (r.width = C + ($ ? 0 : m + w));
                var x = t(a.height);
                return !1 !== x && (r.height = x + ($ ? 0 : v + b)), r.innerWidth = r.width - (m + w), r.innerHeight = r.height - (v + b), r.outerWidth = r.width + y, r.outerHeight = r.height + _, r
            }
        }
        var s, r = "undefined" == typeof console ? e : function(t) {},
            l = ["paddingLeft", "paddingRight", "paddingTop", "paddingBottom", "marginLeft", "marginRight", "marginTop", "marginBottom", "borderLeftWidth", "borderRightWidth", "borderTopWidth", "borderBottomWidth"],
            c = l.length,
            d = !1;
        return a
    }),
    function(t, e) {
        d = e, u = {
            "id": "desandro-matches-selector/matches-selector",
            "exports": {},
            "loaded": !1
        }, c = "function" == typeof d ? d.call(u.exports, i, u.exports, u) : d, u.loaded = !0, c === undefined && (c = u.exports)
    }(window, function() {
        var t = function() {
            var t = window.Element.prototype;
            if (t.matches) return "matches";
            if (t.matchesSelector) return "matchesSelector";
            for (var e = ["webkit", "moz", "ms", "o"], i = 0; i < e.length; i++) {
                var n = e[i],
                    o = n + "MatchesSelector";
                if (t[o]) return o
            }
        }();
        return function(e, i) {
            return e[t](i)
        }
    }),
    function(t, i) {
        n = [c], h = function(e) {
            return i(t, e)
        }.apply(e, n)
    }(window, function(t, e) {
        var i = {};
        i.extend = function(t, e) {
            for (var i in e) t[i] = e[i];
            return t
        }, i.modulo = function(t, e) {
            return (t % e + e) % e
        }, i.makeArray = function(t) {
            var e = [];
            if (Array.isArray(t)) e = t;
            else if (t && "object" == (void 0 === t ? "undefined" : g(t)) && "number" == typeof t.length)
                for (var i = 0; i < t.length; i++) e.push(t[i]);
            else e.push(t);
            return e
        }, i.removeFrom = function(t, e) {
            var i = t.indexOf(e); - 1 != i && t.splice(i, 1)
        }, i.getParent = function(t, i) {
            for (; t != document.body;)
                if (t = t.parentNode, e(t, i)) return t
        }, i.getQueryElement = function(t) {
            return "string" == typeof t ? document.querySelector(t) : t
        }, i.handleEvent = function(t) {
            var e = "on" + t.type;
            this[e] && this[e](t)
        }, i.filterFindElements = function(t, n) {
            t = i.makeArray(t);
            var o = [];
            return t.forEach(function(t) {
                if (t instanceof HTMLElement) {
                    if (!n) return void o.push(t);
                    e(t, n) && o.push(t);
                    for (var i = t.querySelectorAll(n), a = 0; a < i.length; a++) o.push(i[a])
                }
            }), o
        }, i.debounceMethod = function(t, e, i) {
            var n = t.prototype[e],
                o = e + "Timeout";
            t.prototype[e] = function() {
                var t = this[o];
                t && clearTimeout(t);
                var e = arguments,
                    a = this;
                this[o] = setTimeout(function() {
                    n.apply(a, e), delete a[o]
                }, i || 100)
            }
        }, i.docReady = function(t) {
            var e = document.readyState;
            "complete" == e || "interactive" == e ? setTimeout(t) : document.addEventListener("DOMContentLoaded", t)
        }, i.toDashed = function(t) {
            return t.replace(/(.)([A-Z])/g, function(t, e, i) {
                return e + "-" + i
            }).toLowerCase()
        };
        var n = t.console;
        return i.htmlInit = function(e, o) {
            i.docReady(function() {
                var a = i.toDashed(o),
                    s = "data-" + a,
                    r = document.querySelectorAll("[" + s + "]"),
                    l = document.querySelectorAll(".js-" + a),
                    c = i.makeArray(r).concat(i.makeArray(l)),
                    d = s + "-options",
                    u = t.jQuery;
                c.forEach(function(t) {
                    var i, a = t.getAttribute(s) || t.getAttribute(d);
                    try {
                        i = a && JSON.parse(a)
                    } catch (r) {
                        return void(n && n.error("Error parsing " + s + " on " + t.className + ": " + r))
                    }
                    var l = new e(t, i);
                    u && u.data(t, o, l)
                })
            })
        }, i
    }),
    function(t, i) {
        n = [a, l], f = i, p = "function" == typeof f ? f.apply(e, n) : f
    }(window, function(t, e) {
        function i(t) {
            for (var e in t) return !1;
            return null, !0
        }

        function n(t, e) {
            t && (this.element = t, this.layout = e, this.position = {
                "x": 0,
                "y": 0
            }, this._create())
        }
        var o = document.documentElement.style,
            a = "string" == typeof o.transition ? "transition" : "WebkitTransition",
            s = "string" == typeof o.transform ? "transform" : "WebkitTransform",
            r = {
                "WebkitTransition": "webkitTransitionEnd",
                "transition": "transitionend"
            }[a],
            l = {
                "transform": s,
                "transition": a,
                "transitionDuration": a + "Duration",
                "transitionProperty": a + "Property",
                "transitionDelay": a + "Delay"
            },
            c = n.prototype = Object.create(t.prototype);
        c.constructor = n, c._create = function() {
            this._transn = {
                "ingProperties": {},
                "clean": {},
                "onEnd": {}
            }, this.css({
                "position": "absolute"
            })
        }, c.handleEvent = function(t) {
            var e = "on" + t.type;
            this[e] && this[e](t)
        }, c.getSize = function() {
            this.size = e(this.element)
        }, c.css = function(t) {
            var e = this.element.style;
            for (var i in t) {
                e[l[i] || i] = t[i]
            }
        }, c.getPosition = function() {
            var t = getComputedStyle(this.element),
                e = this.layout._getOption("originLeft"),
                i = this.layout._getOption("originTop"),
                n = t[e ? "left" : "right"],
                o = t[i ? "top" : "bottom"],
                a = this.layout.size,
                s = -1 != n.indexOf("%") ? parseFloat(n) / 100 * a.width : parseInt(n, 10),
                r = -1 != o.indexOf("%") ? parseFloat(o) / 100 * a.height : parseInt(o, 10);
            s = isNaN(s) ? 0 : s, r = isNaN(r) ? 0 : r, s -= e ? a.paddingLeft : a.paddingRight, r -= i ? a.paddingTop : a.paddingBottom, this.position.x = s, this.position.y = r
        }, c.layoutPosition = function() {
            var t = this.layout.size,
                e = {},
                i = this.layout._getOption("originLeft"),
                n = this.layout._getOption("originTop"),
                o = i ? "paddingLeft" : "paddingRight",
                a = i ? "left" : "right",
                s = i ? "right" : "left",
                r = this.position.x + t[o];
            e[a] = this.getXValue(r), e[s] = "";
            var l = n ? "paddingTop" : "paddingBottom",
                c = n ? "top" : "bottom",
                d = n ? "bottom" : "top",
                u = this.position.y + t[l];
            e[c] = this.getYValue(u), e[d] = "", this.css(e), this.emitEvent("layout", [this])
        }, c.getXValue = function(t) {
            var e = this.layout._getOption("horizontal");
            return this.layout.options.percentPosition && !e ? t / this.layout.size.width * 100 + "%" : t + "px"
        }, c.getYValue = function(t) {
            var e = this.layout._getOption("horizontal");
            return this.layout.options.percentPosition && e ? t / this.layout.size.height * 100 + "%" : t + "px"
        }, c._transitionTo = function(t, e) {
            this.getPosition();
            var i = this.position.x,
                n = this.position.y,
                o = parseInt(t, 10),
                a = parseInt(e, 10),
                s = o === this.position.x && a === this.position.y;
            if (this.setPosition(t, e), s && !this.isTransitioning) return void this.layoutPosition();
            var r = t - i,
                l = e - n,
                c = {};
            c.transform = this.getTranslate(r, l), this.transition({
                "to": c,
                "onTransitionEnd": {
                    "transform": this.layoutPosition
                },
                "isCleaning": !0
            })
        }, c.getTranslate = function(t, e) {
            var i = this.layout._getOption("originLeft"),
                n = this.layout._getOption("originTop");
            return t = i ? t : -t, e = n ? e : -e, "translate3d(" + t + "px, " + e + "px, 0)"
        }, c.goTo = function(t, e) {
            this.setPosition(t, e), this.layoutPosition()
        }, c.moveTo = c._transitionTo, c.setPosition = function(t, e) {
            this.position.x = parseInt(t, 10), this.position.y = parseInt(e, 10)
        }, c._nonTransition = function(t) {
            this.css(t.to), t.isCleaning && this._removeStyles(t.to);
            for (var e in t.onTransitionEnd) t.onTransitionEnd[e].call(this)
        }, c.transition = function(t) {
            if (!parseFloat(this.layout.options.transitionDuration)) return void this._nonTransition(t);
            var e = this._transn;
            for (var i in t.onTransitionEnd) e.onEnd[i] = t.onTransitionEnd[i];
            for (i in t.to) e.ingProperties[i] = !0, t.isCleaning && (e.clean[i] = !0);
            if (t.from) {
                this.css(t.from);
                this.element.offsetHeight;
                null
            }
            this.enableTransition(t.to), this.css(t.to), this.isTransitioning = !0
        };
        var d = "opacity," + function(t) {
            return t.replace(/([A-Z])/g, function(t) {
                return "-" + t.toLowerCase()
            })
        }(s);
        c.enableTransition = function() {
            if (!this.isTransitioning) {
                var t = this.layout.options.transitionDuration;
                t = "number" == typeof t ? t + "ms" : t, this.css({
                    "transitionProperty": d,
                    "transitionDuration": t,
                    "transitionDelay": this.staggerDelay || 0
                }), this.element.addEventListener(r, this, !1)
            }
        }, c.onwebkitTransitionEnd = function(t) {
            this.ontransitionend(t)
        }, c.onotransitionend = function(t) {
            this.ontransitionend(t)
        };
        var u = {
            "-webkit-transform": "transform"
        };
        c.ontransitionend = function(t) {
            if (t.target === this.element) {
                var e = this._transn,
                    n = u[t.propertyName] || t.propertyName;
                if (delete e.ingProperties[n], i(e.ingProperties) && this.disableTransition(), n in e.clean && (this.element.style[t.propertyName] = "", delete e.clean[n]), n in e.onEnd) {
                    e.onEnd[n].call(this), delete e.onEnd[n]
                }
                this.emitEvent("transitionEnd", [this])
            }
        }, c.disableTransition = function() {
            this.removeTransitionStyles(), this.element.removeEventListener(r, this, !1), this.isTransitioning = !1
        }, c._removeStyles = function(t) {
            var e = {};
            for (var i in t) e[i] = "";
            this.css(e)
        };
        var h = {
            "transitionProperty": "",
            "transitionDuration": "",
            "transitionDelay": ""
        };
        return c.removeTransitionStyles = function() {
            this.css(h)
        }, c.stagger = function(t) {
            t = isNaN(t) ? 0 : t, this.staggerDelay = t + "ms"
        }, c.removeElem = function() {
            this.element.parentNode.removeChild(this.element), this.css({
                "display": ""
            }), this.emitEvent("remove", [this])
        }, c.remove = function() {
            return a && parseFloat(this.layout.options.transitionDuration) ? (this.once("transitionEnd", function() {
                this.removeElem()
            }), void this.hide()) : void this.removeElem()
        }, c.reveal = function() {
            delete this.isHidden, this.css({
                "display": ""
            });
            var t = this.layout.options,
                e = {};
            e[this.getHideRevealTransitionEndProperty("visibleStyle")] = this.onRevealTransitionEnd, this.transition({
                "from": t.hiddenStyle,
                "to": t.visibleStyle,
                "isCleaning": !0,
                "onTransitionEnd": e
            })
        }, c.onRevealTransitionEnd = function() {
            this.isHidden || this.emitEvent("reveal")
        }, c.getHideRevealTransitionEndProperty = function(t) {
            var e = this.layout.options[t];
            if (e.opacity) return "opacity";
            for (var i in e) return i
        }, c.hide = function() {
            this.isHidden = !0, this.css({
                "display": ""
            });
            var t = this.layout.options,
                e = {};
            e[this.getHideRevealTransitionEndProperty("hiddenStyle")] = this.onHideTransitionEnd, this.transition({
                "from": t.visibleStyle,
                "to": t.hiddenStyle,
                "isCleaning": !0,
                "onTransitionEnd": e
            })
        }, c.onHideTransitionEnd = function() {
            this.isHidden && (this.css({
                "display": "none"
            }), this.emitEvent("hide"))
        }, c.destroy = function() {
            this.css({
                "position": "",
                "left": "",
                "right": "",
                "top": "",
                "bottom": "",
                "transition": "",
                "transform": ""
            })
        }, n
    }),
    function(t, i) {
        n = [a, l, h, p], m = function(e, n, o, a) {
            return i(t, e, n, o, a)
        }.apply(e, n)
    }(window, function(t, e, i, n, o) {
        function a(t, e) {
            var i = n.getQueryElement(t);
            if (!i) return void(l && l.error("Bad element for " + this.constructor.namespace + ": " + (i || t)));
            this.element = i, c && (this.$element = c(this.element)), this.options = n.extend({}, this.constructor.defaults), this.option(e);
            var o = ++u;
            this.element.outlayerGUID = o, h[o] = this, this._create(), this._getOption("initLayout") && this.layout()
        }

        function s(t) {
            function e() {
                t.apply(this, arguments)
            }
            return e.prototype = Object.create(t.prototype), e.prototype.constructor = e, e
        }

        function r(t) {
            if ("number" == typeof t) return t;
            var e = t.match(/(^\d*\.?\d*)(\w*)/),
                i = e && e[1],
                n = e && e[2];
            return i.length ? (i = parseFloat(i)) * (p[n] || 1) : 0
        }
        var l = t.console,
            c = t.jQuery,
            d = function() {},
            u = 0,
            h = {};
        a.namespace = "outlayer", a.Item = o, a.defaults = {
            "containerStyle": {
                "position": "relative"
            },
            "initLayout": !0,
            "originLeft": !0,
            "originTop": !0,
            "resize": !0,
            "resizeContainer": !0,
            "transitionDuration": "0.4s",
            "hiddenStyle": {
                "opacity": 0,
                "transform": "scale(0.001)"
            },
            "visibleStyle": {
                "opacity": 1,
                "transform": "scale(1)"
            }
        };
        var f = a.prototype;
        n.extend(f, e.prototype), f.option = function(t) {
            n.extend(this.options, t)
        }, f._getOption = function(t) {
            var e = this.constructor.compatOptions[t];
            return e && void 0 !== this.options[e] ? this.options[e] : this.options[t]
        }, a.compatOptions = {
            "initLayout": "isInitLayout",
            "horizontal": "isHorizontal",
            "layoutInstant": "isLayoutInstant",
            "originLeft": "isOriginLeft",
            "originTop": "isOriginTop",
            "resize": "isResizeBound",
            "resizeContainer": "isResizingContainer"
        }, f._create = function() {
            this.reloadItems(), this.stamps = [], this.stamp(this.options.stamp), n.extend(this.element.style, this.options.containerStyle), this._getOption("resize") && this.bindResize()
        }, f.reloadItems = function() {
            this.items = this._itemize(this.element.children)
        }, f._itemize = function(t) {
            for (var e = this._filterFindItemElements(t), i = this.constructor.Item, n = [], o = 0; o < e.length; o++) {
                var a = e[o],
                    s = new i(a, this);
                n.push(s)
            }
            return n
        }, f._filterFindItemElements = function(t) {
            return n.filterFindElements(t, this.options.itemSelector)
        }, f.getItemElements = function() {
            return this.items.map(function(t) {
                return t.element
            })
        }, f.layout = function() {
            this._resetLayout(), this._manageStamps();
            var t = this._getOption("layoutInstant"),
                e = void 0 !== t ? t : !this._isLayoutInited;
            this.layoutItems(this.items, e), this._isLayoutInited = !0
        }, f._init = f.layout, f._resetLayout = function() {
            this.getSize()
        }, f.getSize = function() {
            this.size = i(this.element)
        }, f._getMeasurement = function(t, e) {
            var n, o = this.options[t];
            o ? ("string" == typeof o ? n = this.element.querySelector(o) : o instanceof HTMLElement && (n = o), this[t] = n ? i(n)[e] : o) : this[t] = 0
        }, f.layoutItems = function(t, e) {
            t = this._getItemsForLayout(t), this._layoutItems(t, e), this._postLayout()
        }, f._getItemsForLayout = function(t) {
            return t.filter(function(t) {
                return !t.isIgnored
            })
        }, f._layoutItems = function(t, e) {
            if (this._emitCompleteOnItems("layout", t), t && t.length) {
                var i = [];
                t.forEach(function(t) {
                    var n = this._getItemLayoutPosition(t);
                    n.item = t, n.isInstant = e || t.isLayoutInstant, i.push(n)
                }, this), this._processLayoutQueue(i)
            }
        }, f._getItemLayoutPosition = function() {
            return {
                "x": 0,
                "y": 0
            }
        }, f._processLayoutQueue = function(t) {
            this.updateStagger(), t.forEach(function(t, e) {
                this._positionItem(t.item, t.x, t.y, t.isInstant, e)
            }, this)
        }, f.updateStagger = function() {
            var t = this.options.stagger;
            return null === t || void 0 === t ? void(this.stagger = 0) : (this.stagger = r(t), this.stagger)
        }, f._positionItem = function(t, e, i, n, o) {
            n ? t.goTo(e, i) : (t.stagger(o * this.stagger), t.moveTo(e, i))
        }, f._postLayout = function() {
            this.resizeContainer()
        }, f.resizeContainer = function() {
            if (this._getOption("resizeContainer")) {
                var t = this._getContainerSize();
                t && (this._setContainerMeasure(t.width, !0), this._setContainerMeasure(t.height, !1))
            }
        }, f._getContainerSize = d, f._setContainerMeasure = function(t, e) {
            if (void 0 !== t) {
                var i = this.size;
                i.isBorderBox && (t += e ? i.paddingLeft + i.paddingRight + i.borderLeftWidth + i.borderRightWidth : i.paddingBottom + i.paddingTop + i.borderTopWidth + i.borderBottomWidth), t = Math.max(t, 0), this.element.style[e ? "width" : "height"] = t + "px"
            }
        }, f._emitCompleteOnItems = function(t, e) {
            function i() {
                o.dispatchEvent(t + "Complete", null, [e])
            }

            function n() {
                ++s == a && i()
            }
            var o = this,
                a = e.length;
            if (!e || !a) return void i();
            var s = 0;
            e.forEach(function(e) {
                e.once(t, n)
            })
        }, f.dispatchEvent = function(t, e, i) {
            var n = e ? [e].concat(i) : i;
            if (this.emitEvent(t, n), c)
                if (this.$element = this.$element || c(this.element), e) {
                    var o = c.Event(e);
                    o.type = t, this.$element.trigger(o, i)
                } else this.$element.trigger(t, i)
        }, f.ignore = function(t) {
            var e = this.getItem(t);
            e && (e.isIgnored = !0)
        }, f.unignore = function(t) {
            var e = this.getItem(t);
            e && delete e.isIgnored
        }, f.stamp = function(t) {
            (t = this._find(t)) && (this.stamps = this.stamps.concat(t), t.forEach(this.ignore, this))
        }, f.unstamp = function(t) {
            (t = this._find(t)) && t.forEach(function(t) {
                n.removeFrom(this.stamps, t), this.unignore(t)
            }, this)
        }, f._find = function(t) {
            return t ? ("string" == typeof t && (t = this.element.querySelectorAll(t)), t = n.makeArray(t)) : void 0
        }, f._manageStamps = function() {
            this.stamps && this.stamps.length && (this._getBoundingRect(), this.stamps.forEach(this._manageStamp, this))
        }, f._getBoundingRect = function() {
            var t = this.element.getBoundingClientRect(),
                e = this.size;
            this._boundingRect = {
                "left": t.left + e.paddingLeft + e.borderLeftWidth,
                "top": t.top + e.paddingTop + e.borderTopWidth,
                "right": t.right - (e.paddingRight + e.borderRightWidth),
                "bottom": t.bottom - (e.paddingBottom + e.borderBottomWidth)
            }
        }, f._manageStamp = d, f._getElementOffset = function(t) {
            var e = t.getBoundingClientRect(),
                n = this._boundingRect,
                o = i(t);
            return {
                "left": e.left - n.left - o.marginLeft,
                "top": e.top - n.top - o.marginTop,
                "right": n.right - e.right - o.marginRight,
                "bottom": n.bottom - e.bottom - o.marginBottom
            }
        }, f.handleEvent = n.handleEvent, f.bindResize = function() {
            t.addEventListener("resize", this), this.isResizeBound = !0
        }, f.unbindResize = function() {
            t.removeEventListener("resize", this), this.isResizeBound = !1
        }, f.onresize = function() {
            this.resize()
        }, n.debounceMethod(a, "onresize", 100), f.resize = function() {
            this.isResizeBound && this.needsResizeLayout() && this.layout()
        }, f.needsResizeLayout = function() {
            var t = i(this.element);
            return this.size && t && t.innerWidth !== this.size.innerWidth
        }, f.addItems = function(t) {
            var e = this._itemize(t);
            return e.length && (this.items = this.items.concat(e)), e
        }, f.appended = function(t) {
            var e = this.addItems(t);
            e.length && (this.layoutItems(e, !0), this.reveal(e))
        }, f.prepended = function(t) {
            var e = this._itemize(t);
            if (e.length) {
                var i = this.items.slice(0);
                this.items = e.concat(i), this._resetLayout(), this._manageStamps(), this.layoutItems(e, !0), this.reveal(e), this.layoutItems(i)
            }
        }, f.reveal = function(t) {
            if (this._emitCompleteOnItems("reveal", t), t && t.length) {
                var e = this.updateStagger();
                t.forEach(function(t, i) {
                    t.stagger(i * e), t.reveal()
                })
            }
        }, f.hide = function(t) {
            if (this._emitCompleteOnItems("hide", t), t && t.length) {
                var e = this.updateStagger();
                t.forEach(function(t, i) {
                    t.stagger(i * e), t.hide()
                })
            }
        }, f.revealItemElements = function(t) {
            var e = this.getItems(t);
            this.reveal(e)
        }, f.hideItemElements = function(t) {
            var e = this.getItems(t);
            this.hide(e)
        }, f.getItem = function(t) {
            for (var e = 0; e < this.items.length; e++) {
                var i = this.items[e];
                if (i.element == t) return i
            }
        }, f.getItems = function(t) {
            t = n.makeArray(t);
            var e = [];
            return t.forEach(function(t) {
                var i = this.getItem(t);
                i && e.push(i)
            }, this), e
        }, f.remove = function(t) {
            var e = this.getItems(t);
            this._emitCompleteOnItems("remove", e), e && e.length && e.forEach(function(t) {
                t.remove(), n.removeFrom(this.items, t)
            }, this)
        }, f.destroy = function() {
            var t = this.element.style;
            t.height = "", t.position = "", t.width = "", this.items.forEach(function(t) {
                t.destroy()
            }), this.unbindResize();
            var e = this.element.outlayerGUID;
            delete h[e], delete this.element.outlayerGUID, c && c.removeData(this.element, this.constructor.namespace)
        }, a.data = function(t) {
            t = n.getQueryElement(t);
            var e = t && t.outlayerGUID;
            return e && h[e]
        }, a.create = function(t, e) {
            var i = s(a);
            return i.defaults = n.extend({}, a.defaults), n.extend(i.defaults, e), i.compatOptions = n.extend({}, a.compatOptions), i.namespace = t, i.data = a.data, i.Item = s(o), n.htmlInit(i, t), c && c.bridget && c.bridget(t, i), i
        };
        var p = {
            "ms": 1,
            "s": 1e3
        };
        return a.Item = o, a
    }),
    function(i, a) {
        n = [m, l], f = a, (o = "function" == typeof f ? f.apply(e, n) : f) !== undefined && (t.exports = o)
    }(window, function(t, e) {
        var i = t.create("masonry");
        i.compatOptions.fitWidth = "isFitWidth";
        var n = i.prototype;
        return n._resetLayout = function() {
            this.getSize(), this._getMeasurement("columnWidth", "outerWidth"), this._getMeasurement("gutter", "outerWidth"), this.measureColumns(), this.colYs = [];
            for (var t = 0; t < this.cols; t++) this.colYs.push(0);
            this.maxY = 0, this.horizontalColIndex = 0
        }, n.measureColumns = function() {
            if (this.getContainerWidth(), !this.columnWidth) {
                var t = this.items[0],
                    i = t && t.element;
                this.columnWidth = i && e(i).outerWidth || this.containerWidth
            }
            var n = this.columnWidth += this.gutter,
                o = this.containerWidth + this.gutter,
                a = o / n,
                s = n - o % n,
                r = s && 1 > s ? "round" : "floor";
            a = Math[r](a), this.cols = Math.max(a, 1)
        }, n.getContainerWidth = function() {
            var t = this._getOption("fitWidth"),
                i = t ? this.element.parentNode : this.element,
                n = e(i);
            this.containerWidth = n && n.innerWidth
        }, n._getItemLayoutPosition = function(t) {
            t.getSize();
            var e = t.size.outerWidth % this.columnWidth,
                i = e && 1 > e ? "round" : "ceil",
                n = Math[i](t.size.outerWidth / this.columnWidth);
            n = Math.min(n, this.cols);
            for (var o = this.options.horizontalOrder ? "_getHorizontalColPosition" : "_getTopColPosition", a = this[o](n, t), s = {
                    "x": this.columnWidth * a.col,
                    "y": a.y
                }, r = a.y + t.size.outerHeight, l = n + a.col, c = a.col; l > c; c++) this.colYs[c] = r;
            return s
        }, n._getTopColPosition = function(t) {
            var e = this._getTopColGroup(t),
                i = Math.min.apply(Math, e);
            return {
                "col": e.indexOf(i),
                "y": i
            }
        }, n._getTopColGroup = function(t) {
            if (2 > t) return this.colYs;
            for (var e = [], i = this.cols + 1 - t, n = 0; i > n; n++) e[n] = this._getColGroupY(n, t);
            return e
        }, n._getColGroupY = function(t, e) {
            if (2 > e) return this.colYs[t];
            var i = this.colYs.slice(t, t + e);
            return Math.max.apply(Math, i)
        }, n._getHorizontalColPosition = function(t, e) {
            var i = this.horizontalColIndex % this.cols;
            i = t > 1 && i + t > this.cols ? 0 : i;
            var n = e.size.outerWidth && e.size.outerHeight;
            return this.horizontalColIndex = n ? i + t : this.horizontalColIndex, {
                "col": i,
                "y": this._getColGroupY(i, t)
            }
        }, n._manageStamp = function(t) {
            var i = e(t),
                n = this._getElementOffset(t),
                o = this._getOption("originLeft"),
                a = o ? n.left : n.right,
                s = a + i.outerWidth,
                r = Math.floor(a / this.columnWidth);
            r = Math.max(0, r);
            var l = Math.floor(s / this.columnWidth);
            l -= s % this.columnWidth ? 0 : 1, l = Math.min(this.cols - 1, l);
            for (var c = this._getOption("originTop"), d = (c ? n.top : n.bottom) + i.outerHeight, u = r; l >= u; u++) this.colYs[u] = Math.max(d, this.colYs[u])
        }, n._getContainerSize = function() {
            this.maxY = Math.max.apply(Math, this.colYs);
            var t = {
                "height": this.maxY
            };
            return this._getOption("fitWidth") && (t.width = this._getContainerFitWidth()), t
        }, n._getContainerFitWidth = function() {
            for (var t = 0, e = this.cols; --e && 0 === this.colYs[e];) t++;
            return (this.cols - t) * this.columnWidth - this.gutter
        }, n.needsResizeLayout = function() {
            var t = this.containerWidth;
            return this.getContainerWidth(), t != this.containerWidth
        }, i
    })
}, function(t, e, i) {
    "use strict";
    coolsite360.PlayerPlugins.push({
        "config": {
            "type": "navbar"
        },
        "onInit": function() {
            coolsite_play.doc.find(".navbar.c-navbar").each(function() {
                if ("undefined" != typeof page_slug) {
                    var t = page_slug;
                    $(this).find('.c-navlink[href!="#"]').each(function() {
                        var e = $(this).attr("href");
                        if (e && e.indexOf) {
                            if (-1 != e.indexOf("//")) return;
                            if (0 == e.indexOf("#")) return;
                            e.match(/\w+\.html/i) && (e = e.match(/\w+\.html/i)[0], e.replace(".html", "") === t ? $(this).parent().addClass("active") : $(this).parent().removeClass("active"))
                        }
                    })
                }
            })
        }
    })
}, function(t, e, i) {
    "use strict";
    coolsite360.PlayerPlugins.push({
        "config": {
            "type": "grid"
        },
        "onInit": function() {
            i(13).makeJQueryPlugin($), 0 != coolsite_play.doc.find(".masonry").length && coolsite_play.doc.find(".masonry").each(function() {
                if ($(this).children().eq(0).hasClass("c-row")) {
                    var t = $(this).children().eq(0);
                    t.masonry({
                        "resize": !0
                    }), t.imagesLoaded().progress(function() {
                        t.masonry("layout")
                    })
                } else {
                    var t = $(this);
                    $(this).masonry({
                        "resize": !0
                    }), t.imagesLoaded().progress(function() {
                        t.masonry("layout")
                    })
                }
            })
        }
    })
}, function(t, e, i) {
    "use strict";
    coolsite360.PlayerPlugins.push({
        "config": {
            "type": "map"
        },
        "onInit": function() {
            coolsite_play.doc.find(".tag-map").each(function() {
                var t = $(this);
                t.html('<iframe id="map_iframe" frameborder="no" style="width: 100%;height: 100%;"></iframe>');
                var e = t.find("#map_iframe")[0];
                e.contentDocument.open();
                var i = t.attr("center_longitude"),
                    n = t.attr("center_latitude"),
                    o = t.attr("marker_longitude"),
                    a = t.attr("marker_latitude"),
                    s = t.attr("zoom"),
                    r = t.attr("description").trim();
                i = Number(i) ? Number(i) : 121.39979660511018, n = Number(n) ? Number(n) : 31.206074968092846, o = Number(o) ? Number(o) : 121.39979660511018, a = Number(a) ? Number(a) : 31.206074968092846, s = Number(s) ? Number(s) : 13, e.contentDocument.write('<html><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8" /><meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"/><style type="text/css">* {margin:0px;padding:0px;}</style><script charset="utf-8" src="http://map.qq.com/api/js?v=2.exp&key=6LLBZ-QMLCX-HNA4L-T3ADN-4O3V5-BFFLB"><\/script></head><body style="width: 100%;height: 100%;"><div id="map" style="width:100%;height:100%;"></div><script>var map_center = new qq.maps.LatLng(' + n + ", " + i + "),    marker_center = new qq.maps.LatLng(" + a + ", " + o + ');/* create地图 */var map = new qq.maps.Map(document.getElementById("map"), {    center: map_center,    zoom: ' + s + ',    scrollwheel: false});/* 地址标志 */var marker = new qq.maps.Marker({    position: marker_center,    draggable: true,    map: map});marker.setDraggable(false);/* 标签文字 */var infoLabel = new qq.maps.Label({    map: map,    style: {borderColor:"red"}});infoLabel.setContent("' + r + '");infoLabel.setPosition(marker_center);<\/script></body></html>'), e.contentDocument.close()
            })
        }
    })
}, function(t, e, i) {
    "use strict";
    coolsite360.PlayerPlugins.push({
        "config": {
            "type": "svg"
        },
        "onInit": function() {
            function t(t, e) {
                var i, n = document.createElementNS("http://www.w3.org/2000/svg", t),
                    o = /([a-z])([A-Z])/g;
                for (i in e) n.setAttributeNS(null, i.replace(o, "$1-$2").toLowerCase(), e[i]);
                return n
            }
            coolsite_play.doc.find(".tag-svg").each(function() {
                var e = $(this),
                    i = e.attr("data-c_ani_id");
                if (i && i.split) {
                    i = i.split("|");
                    var n = coolsite_play.animationlist.models.filter(function(t) {
                        return 12 == t.attributes.data.type && _.include(i, t.id)
                    });
                    if (n.length > 0) {
                        if ("undefined" == typeof TweenMax) return;
                        TweenMax.set(e.find("path"), {
                            "display": "none"
                        }), e.append(t("g", {
                            "id": "cloneArea",
                            "style": "display:none;"
                        })), e.find("#cloneArea").append(e.find("path").clone()), e.find("#cloneArea path").each(function(t, e) {
                            e.id = "clone_" + e.id, $(e).attr("data-attr", "morphCloneElement")
                        });
                        var o = n[0].attributes.data.d.pathIndex;
                        if (!_.isEmpty(o)) {
                            var a = _.find(o, function(t) {
                                return null != t.selected
                            });
                            if (a) {
                                a.id;
                                TweenMax.set(e.find("path#" + a.id), {
                                    "display": "block"
                                })
                            }
                        }
                    }
                }
            })
        }
    })
}, function(t, e, i) {
    "use strict";
    coolsite360.PlayerPlugins.push({
        "config": {
            "type": "imagemap"
        },
        "onInit": function() {
            coolsite_play.doc.find(".tag-imagemap").each(function() {
                var t = $(this),
                    e = t.attr("mapdata");
                if ("" != e) {
                    t.html('<div id="image-map-pro-container" style="margin:0 auto;max-width:100%;max-height:100%;"></div>');
                    var i = JSON.parse(e),
                        n = i.general.width,
                        o = i.general.height,
                        a = t.width(),
                        s = t.height();
                    s > 0 && (a / s > n / o ? a = s * n / o : a / s < n / o && (s = a * o / n), t.find("#image-map-pro-container").width(a).height(s)), t.find("#image-map-pro-container").imageMapPro(i)
                } else t.html('<img src="' + t.attr("src") + '">')
            })
        }
    })
}, function(t, e, i) {
    "use strict";
    coolsite360.PlayerPlugins.push({
        "config": {
            "type": "searchbox"
        },
        "onInit": function() {
            coolsite_play.doc.find(".c-searchbox ").each(function() {
                var t = $(this).attr("searchSlug"),
                    e = $(this);
                t && e.find(".c-search-box-input").off("keyup").on("keyup", function(i) {
                    var n = $(this).val(),
                        o = e.find(".c-search-box-btn"),
                        a = o.attr("target");
                    if (o && o.length && 13 == i.keyCode) {
                        var s;
                        s = n ? portal_url + t + "/keywords!!" + n + "/" : portal_url + t + ".html", "_blank" == a ? window.open(s) : window.location = s
                    }
                }), e.find(".c-search-box-btn").off("click").on("click", function(i) {
                    var n = e.find(".c-search-box-input").val();
                    if (n) {
                        var o = portal_url + t + "/keywords!!" + n + "/";
                        $(this).attr("href", o)
                    } else {
                        var o = portal_url + t + ".html";
                        $(this).attr("href", o)
                    }
                })
            })
        }
    })
}, function(t, e, i) {
    "use strict";
    coolsite360.PlayerPlugins.push({
        "config": {
            "type": "btn_list_item"
        },
        "onInit": function() {
            var t = this,
                e = coolsite_play.doc.find(".btn-listitem"),
                i = coolsite_play.doc.find(".c-btn-group-listitem");
            e.each(function() {
                t.addActive($(this))
            }), i.each(function() {
                t.addActive($(this))
            })
        },
        "addActive": function(t) {
            t.hasClass("active") && t.trigger("button_active"), t.off("click").on("click", function(e) {
                e.preventDefault(), t.hasClass("active") || (t.addClass("active").children(".btn_list_linkwrap").addClass("active"), t.siblings().removeClass("active").children(".btn_list_linkwrap").removeClass("active")), $(e.target).trigger("button_active")
            }), t.on("button_active", function(e) {
                t.hasClass("active") || (t.addClass("active").children(".btn_list_linkwrap").addClass("active"), t.siblings().removeClass("active").children(".btn_list_linkwrap").removeClass("active"))
            })
        }
    })
}, function(t, e, i) {
    "use strict";
    coolsite360.PlayerPlugins.push({
        "config": {
            "type": "contentgridviewv2"
        },
        "onInit": function() {
            coolsite_play.util.refreshcontentlist.generate()
        }
    })
}, function(t, e, i) {
    "use strict";
    coolsite360.PlayerPlugins.push({
        "config": {
            "type": "contentlistviewv2"
        },
        "onInit": function() {
            coolsite_play.util.refreshcontentlist.generate()
        }
    })
}, function(t, e, i) {
    "use strict";
    coolsite360.PlayerPlugins.push({
        "config": {
            "type": "qrcode"
        },
        "onInit": function() {
            coolsite_play.util.refreshcontentlist.initQrcode(coolsite_play.doc)
        }
    })
}, function(t, e, i) {
    "use strict";
    coolsite360.PlayerPlugins.push({
        "config": {
            "type": "treeNavigation"
        },
        "onInit": function() {
            var t = window.location.pathname,
                e = window.page_slug,
                i = coolsite_play.doc.find(".treeview"),
                n = this;
            i.each(function() {
                n.bfSearchTree(this, n.judgeManage, {
                    "path": t,
                    "href": e
                })
            })
        },
        "bfSearchTree": function(t, e, i) {
            for (var n = []; null != t;) {
                var o = $(t).children(".treeview-item");
                if (e && e(t, o, i), o.length)
                    for (var a = 0; a < o.length; a++) n.push(o[a]);
                t = n.shift()
            }
        },
        "judgeManage": function(t, e, i) {
            var n = $(t),
                o = n.children(".treeview-linkwrap").eq(0);
            if (n.hasClass("treeview")) return !1;
            if (o) {
                var a = o.find(".treeview-link ").attr("href");
                if (e.length && o.find("a").off("click").on("click", function(t) {
                        n.toggleClass("open")
                    }), !a) return !1;
                if (a.match(/\w+\.html/i)) {
                    if (a = a.match(/\w+\.html/i)[0], a.replace(".html", "") === i.href) return $(t).addClass("open").parents(".treeview-item").addClass("open"), !0
                } else if (a === i.path) return $(t).addClass("open").parents(".treeview-item").addClass("open"), !0
            }
            return !1
        },
        "bindScroll": function() {}
    })
}, function(t, e, i) {
    "use strict";
    coolsite360.PlayerPlugins.push({
        "type": "actionexecute",
        "config": {
            "type": 105,
            "exec": function(t) {
                for (var e = t.model.get("data").args.e_ids, i = 0; i < e.length; i++) coolsite_play.util.canvasCirAni.generate($("[canvas-id='" + e[i] + "']"), !0)
            }
        }
    })
}, function(module, exports, __webpack_require__) {
    "use strict";
    coolsite360.PlayerPlugins.push({
        "type": "actionexecute",
        "config": {
            "type": 106,
            "exec": function exec(actionview) {
                var data = unescape(actionview.model.toJSON().data.api_data),
                    element = actionview.$el;
                if (data) {
                    data = "function($element){" + data + "}";
                    try {
                        eval("(" + data + ")")(element)
                    } catch (e) {
                        _g.getUrlParameterByName("-debug") && alert(e)
                    }
                }
            }
        }
    })
}, function(t, e, i) {
    "use strict";
    coolsite360.PlayerPlugins.push({
        "type": "actionexecute",
        "config": {
            "type": 107,
            "exec": function(t) {
                var e = t.model.toJSON().data.args,
                    i = t.model.iview.$el,
                    n = i.closest(".btn-listitem"),
                    o = e.paramType;
                if (n.hasClass("active") || (n.addClass("active"), n.siblings().removeClass("active")), e.content_list && o != undefined) {
                    var a = window.location.pathname + "?list_id=" + e.content_list,
                        s = "";
                    if (coolsite_play.cmsfilter || (coolsite_play.cmsfilter = {}), 1 === Number(o) ? s = "&tags=" + (e.tag_list || "") : 0 === Number(o) && (s = "&categories=" + (e.category_list || "")), a += s, coolsite_play.cmsfilter[e.content_list] = s, e.content_class) {
                        var r = e.content_class.join(".");
                        coolsite_play.util.refreshcontentlist.refresh(a, $("." + r))
                    }
                }
            }
        }
    })
}, function(t, e, i) {
    "use strict";
    ! function(t) {
        t.fn.qrcode = function(e) {
            function i(t) {
                this.mode = r, this.data = t
            }

            function n(t, e) {
                this.typeNumber = t, this.errorCorrectLevel = e, this.modules = null, this.moduleCount = 0, this.dataCache = null, this.dataList = []
            }

            function o(t, e) {
                if (void 0 == t.length) throw Error(t.length + "/" + e);
                for (var i = 0; i < t.length && 0 == t[i];) i++;
                this.num = Array(t.length - i + e);
                for (var n = 0; n < t.length - i; n++) this.num[n] = t[n + i]
            }

            function a(t, e) {
                this.totalCount = t, this.dataCount = e
            }

            function s() {
                this.buffer = [], this.length = 0
            }
            var r;
            i.prototype = {
                "getLength": function() {
                    return this.data.length
                },
                "write": function(t) {
                    for (var e = 0; e < this.data.length; e++) t.put(this.data.charCodeAt(e), 8)
                }
            }, n.prototype = {
                "addData": function(t) {
                    this.dataList.push(new i(t)), this.dataCache = null
                },
                "isDark": function(t, e) {
                    if (0 > t || this.moduleCount <= t || 0 > e || this.moduleCount <= e) throw Error(t + "," + e);
                    return this.modules[t][e]
                },
                "getModuleCount": function() {
                    return this.moduleCount
                },
                "make": function() {
                    if (1 > this.typeNumber) {
                        for (var t = 1, t = 1; 40 > t; t++) {
                            for (var e = a.getRSBlocks(t, this.errorCorrectLevel), i = new s, n = 0, o = 0; o < e.length; o++) n += e[o].dataCount;
                            for (o = 0; o < this.dataList.length; o++) e = this.dataList[o], i.put(e.mode, 4), i.put(e.getLength(), l.getLengthInBits(e.mode, t)), e.write(i);
                            if (i.getLengthInBits() <= 8 * n) break
                        }
                        this.typeNumber = t
                    }
                    this.makeImpl(!1, this.getBestMaskPattern())
                },
                "makeImpl": function(t, e) {
                    this.moduleCount = 4 * this.typeNumber + 17, this.modules = Array(this.moduleCount);
                    for (var i = 0; i < this.moduleCount; i++) {
                        this.modules[i] = Array(this.moduleCount);
                        for (var o = 0; o < this.moduleCount; o++) this.modules[i][o] = null
                    }
                    this.setupPositionProbePattern(0, 0), this.setupPositionProbePattern(this.moduleCount - 7, 0), this.setupPositionProbePattern(0, this.moduleCount - 7), this.setupPositionAdjustPattern(), this.setupTimingPattern(), this.setupTypeInfo(t, e), 7 <= this.typeNumber && this.setupTypeNumber(t), null == this.dataCache && (this.dataCache = n.createData(this.typeNumber, this.errorCorrectLevel, this.dataList)), this.mapData(this.dataCache, e)
                },
                "setupPositionProbePattern": function(t, e) {
                    for (var i = -1; 7 >= i; i++)
                        if (!(-1 >= t + i || this.moduleCount <= t + i))
                            for (var n = -1; 7 >= n; n++) - 1 >= e + n || this.moduleCount <= e + n || (this.modules[t + i][e + n] = 0 <= i && 6 >= i && (0 == n || 6 == n) || 0 <= n && 6 >= n && (0 == i || 6 == i) || 2 <= i && 4 >= i && 2 <= n && 4 >= n)
                },
                "getBestMaskPattern": function() {
                    for (var t = 0, e = 0, i = 0; 8 > i; i++) {
                        this.makeImpl(!0, i);
                        var n = l.getLostPoint(this);
                        (0 == i || t > n) && (t = n, e = i)
                    }
                    return e
                },
                "createMovieClip": function(t, e, i) {
                    for (t = t.createEmptyMovieClip(e, i), this.make(), e = 0; e < this.modules.length; e++)
                        for (var i = 1 * e, n = 0; n < this.modules[e].length; n++) {
                            var o = 1 * n;
                            this.modules[e][n] && (t.beginFill(0, 100), t.moveTo(o, i), t.lineTo(o + 1, i), t.lineTo(o + 1, i + 1), t.lineTo(o, i + 1), t.endFill())
                        }
                    return t
                },
                "setupTimingPattern": function() {
                    for (var t = 8; t < this.moduleCount - 8; t++) null == this.modules[t][6] && (this.modules[t][6] = 0 == t % 2);
                    for (t = 8; t < this.moduleCount - 8; t++) null == this.modules[6][t] && (this.modules[6][t] = 0 == t % 2)
                },
                "setupPositionAdjustPattern": function() {
                    for (var t = l.getPatternPosition(this.typeNumber), e = 0; e < t.length; e++)
                        for (var i = 0; i < t.length; i++) {
                            var n = t[e],
                                o = t[i];
                            if (null == this.modules[n][o])
                                for (var a = -2; 2 >= a; a++)
                                    for (var s = -2; 2 >= s; s++) this.modules[n + a][o + s] = -2 == a || 2 == a || -2 == s || 2 == s || 0 == a && 0 == s
                        }
                },
                "setupTypeNumber": function(t) {
                    for (var e = l.getBCHTypeNumber(this.typeNumber), i = 0; 18 > i; i++) {
                        var n = !t && 1 == (e >> i & 1);
                        this.modules[Math.floor(i / 3)][i % 3 + this.moduleCount - 8 - 3] = n
                    }
                    for (i = 0; 18 > i; i++) n = !t && 1 == (e >> i & 1), this.modules[i % 3 + this.moduleCount - 8 - 3][Math.floor(i / 3)] = n
                },
                "setupTypeInfo": function(t, e) {
                    for (var i = l.getBCHTypeInfo(this.errorCorrectLevel << 3 | e), n = 0; 15 > n; n++) {
                        var o = !t && 1 == (i >> n & 1);
                        6 > n ? this.modules[n][8] = o : 8 > n ? this.modules[n + 1][8] = o : this.modules[this.moduleCount - 15 + n][8] = o
                    }
                    for (n = 0; 15 > n; n++) o = !t && 1 == (i >> n & 1), 8 > n ? this.modules[8][this.moduleCount - n - 1] = o : 9 > n ? this.modules[8][15 - n - 1 + 1] = o : this.modules[8][15 - n - 1] = o;
                    this.modules[this.moduleCount - 8][8] = !t
                },
                "mapData": function(t, e) {
                    for (var i = -1, n = this.moduleCount - 1, o = 7, a = 0, s = this.moduleCount - 1; 0 < s; s -= 2)
                        for (6 == s && s--;;) {
                            for (var r = 0; 2 > r; r++)
                                if (null == this.modules[n][s - r]) {
                                    var c = !1;
                                    a < t.length && (c = 1 == (t[a] >>> o & 1)), l.getMask(e, n, s - r) && (c = !c), this.modules[n][s - r] = c, o--, -1 == o && (a++, o = 7)
                                }
                            if (0 > (n += i) || this.moduleCount <= n) {
                                n -= i, i = -i;
                                break
                            }
                        }
                }
            }, n.PAD0 = 236, n.PAD1 = 17, n.createData = function(t, e, i) {
                for (var e = a.getRSBlocks(t, e), o = new s, r = 0; r < i.length; r++) {
                    var c = i[r];
                    o.put(c.mode, 4), o.put(c.getLength(), l.getLengthInBits(c.mode, t)), c.write(o)
                }
                for (r = t = 0; r < e.length; r++) t += e[r].dataCount;
                if (o.getLengthInBits() > 8 * t) throw Error("code length overflow. (" + o.getLengthInBits() + ">" + 8 * t + ")");
                for (o.getLengthInBits() + 4 <= 8 * t && o.put(0, 4); 0 != o.getLengthInBits() % 8;) o.putBit(!1);
                for (; !(o.getLengthInBits() >= 8 * t) && (o.put(n.PAD0, 8), !(o.getLengthInBits() >= 8 * t));) o.put(n.PAD1, 8);
                return n.createBytes(o, e)
            }, n.createBytes = function(t, e) {
                for (var i = 0, n = 0, a = 0, s = Array(e.length), r = Array(e.length), c = 0; c < e.length; c++) {
                    var d = e[c].dataCount,
                        u = e[c].totalCount - d,
                        n = Math.max(n, d),
                        a = Math.max(a, u);
                    s[c] = Array(d);
                    for (var h = 0; h < s[c].length; h++) s[c][h] = 255 & t.buffer[h + i];
                    for (i += d, h = l.getErrorCorrectPolynomial(u), d = new o(s[c], h.getLength() - 1).mod(h), r[c] = Array(h.getLength() - 1), h = 0; h < r[c].length; h++) u = h + d.getLength() - r[c].length, r[c][h] = 0 <= u ? d.get(u) : 0
                }
                for (h = c = 0; h < e.length; h++) c += e[h].totalCount;
                for (i = Array(c), h = d = 0; h < n; h++)
                    for (c = 0; c < e.length; c++) h < s[c].length && (i[d++] = s[c][h]);
                for (h = 0; h < a; h++)
                    for (c = 0; c < e.length; c++) h < r[c].length && (i[d++] = r[c][h]);
                return i
            }, r = 4;
            for (var l = {
                    "PATTERN_POSITION_TABLE": [
                        [],
                        [6, 18],
                        [6, 22],
                        [6, 26],
                        [6, 30],
                        [6, 34],
                        [6, 22, 38],
                        [6, 24, 42],
                        [6, 26, 46],
                        [6, 28, 50],
                        [6, 30, 54],
                        [6, 32, 58],
                        [6, 34, 62],
                        [6, 26, 46, 66],
                        [6, 26, 48, 70],
                        [6, 26, 50, 74],
                        [6, 30, 54, 78],
                        [6, 30, 56, 82],
                        [6, 30, 58, 86],
                        [6, 34, 62, 90],
                        [6, 28, 50, 72, 94],
                        [6, 26, 50, 74, 98],
                        [6, 30, 54, 78, 102],
                        [6, 28, 54, 80, 106],
                        [6, 32, 58, 84, 110],
                        [6, 30, 58, 86, 114],
                        [6, 34, 62, 90, 118],
                        [6, 26, 50, 74, 98, 122],
                        [6, 30, 54, 78, 102, 126],
                        [6, 26, 52, 78, 104, 130],
                        [6, 30, 56, 82, 108, 134],
                        [6, 34, 60, 86, 112, 138],
                        [6, 30, 58, 86, 114, 142],
                        [6, 34, 62, 90, 118, 146],
                        [6, 30, 54, 78, 102, 126, 150],
                        [6, 24, 50, 76, 102, 128, 154],
                        [6, 28, 54, 80, 106, 132, 158],
                        [6, 32, 58, 84, 110, 136, 162],
                        [6, 26, 54, 82, 110, 138, 166],
                        [6, 30, 58, 86, 114, 142, 170]
                    ],
                    "G15": 1335,
                    "G18": 7973,
                    "G15_MASK": 21522,
                    "getBCHTypeInfo": function(t) {
                        for (var e = t << 10; 0 <= l.getBCHDigit(e) - l.getBCHDigit(l.G15);) e ^= l.G15 << l.getBCHDigit(e) - l.getBCHDigit(l.G15);
                        return (t << 10 | e) ^ l.G15_MASK
                    },
                    "getBCHTypeNumber": function(t) {
                        for (var e = t << 12; 0 <= l.getBCHDigit(e) - l.getBCHDigit(l.G18);) e ^= l.G18 << l.getBCHDigit(e) - l.getBCHDigit(l.G18);
                        return t << 12 | e
                    },
                    "getBCHDigit": function(t) {
                        for (var e = 0; 0 != t;) e++, t >>>= 1;
                        return e
                    },
                    "getPatternPosition": function(t) {
                        return l.PATTERN_POSITION_TABLE[t - 1]
                    },
                    "getMask": function(t, e, i) {
                        switch (t) {
                            case 0:
                                return 0 == (e + i) % 2;
                            case 1:
                                return 0 == e % 2;
                            case 2:
                                return 0 == i % 3;
                            case 3:
                                return 0 == (e + i) % 3;
                            case 4:
                                return 0 == (Math.floor(e / 2) + Math.floor(i / 3)) % 2;
                            case 5:
                                return 0 == e * i % 2 + e * i % 3;
                            case 6:
                                return 0 == (e * i % 2 + e * i % 3) % 2;
                            case 7:
                                return 0 == (e * i % 3 + (e + i) % 2) % 2;
                            default:
                                throw Error("bad maskPattern:" + t)
                        }
                    },
                    "getErrorCorrectPolynomial": function(t) {
                        for (var e = new o([1], 0), i = 0; i < t; i++) e = e.multiply(new o([1, c.gexp(i)], 0));
                        return e
                    },
                    "getLengthInBits": function(t, e) {
                        if (1 <= e && 10 > e) switch (t) {
                            case 1:
                                return 10;
                            case 2:
                                return 9;
                            case r:
                            case 8:
                                return 8;
                            default:
                                throw Error("mode:" + t)
                        } else if (27 > e) switch (t) {
                            case 1:
                                return 12;
                            case 2:
                                return 11;
                            case r:
                                return 16;
                            case 8:
                                return 10;
                            default:
                                throw Error("mode:" + t)
                        } else {
                            if (!(41 > e)) throw Error("type:" + e);
                            switch (t) {
                                case 1:
                                    return 14;
                                case 2:
                                    return 13;
                                case r:
                                    return 16;
                                case 8:
                                    return 12;
                                default:
                                    throw Error("mode:" + t)
                            }
                        }
                    },
                    "getLostPoint": function(t) {
                        for (var e = t.getModuleCount(), i = 0, n = 0; n < e; n++)
                            for (var o = 0; o < e; o++) {
                                for (var a = 0, s = t.isDark(n, o), r = -1; 1 >= r; r++)
                                    if (!(0 > n + r || e <= n + r))
                                        for (var l = -1; 1 >= l; l++) 0 > o + l || e <= o + l || 0 == r && 0 == l || s == t.isDark(n + r, o + l) && a++;
                                5 < a && (i += 3 + a - 5)
                            }
                        for (n = 0; n < e - 1; n++)
                            for (o = 0; o < e - 1; o++) a = 0, t.isDark(n, o) && a++, t.isDark(n + 1, o) && a++, t.isDark(n, o + 1) && a++, t.isDark(n + 1, o + 1) && a++, (0 == a || 4 == a) && (i += 3);
                        for (n = 0; n < e; n++)
                            for (o = 0; o < e - 6; o++) t.isDark(n, o) && !t.isDark(n, o + 1) && t.isDark(n, o + 2) && t.isDark(n, o + 3) && t.isDark(n, o + 4) && !t.isDark(n, o + 5) && t.isDark(n, o + 6) && (i += 40);
                        for (o = 0; o < e; o++)
                            for (n = 0; n < e - 6; n++) t.isDark(n, o) && !t.isDark(n + 1, o) && t.isDark(n + 2, o) && t.isDark(n + 3, o) && t.isDark(n + 4, o) && !t.isDark(n + 5, o) && t.isDark(n + 6, o) && (i += 40);
                        for (o = a = 0; o < e; o++)
                            for (n = 0; n < e; n++) t.isDark(n, o) && a++;
                        return t = Math.abs(100 * a / e / e - 50) / 5, i + 10 * t
                    }
                }, c = {
                    "glog": function(t) {
                        if (1 > t) throw Error("glog(" + t + ")");
                        return c.LOG_TABLE[t]
                    },
                    "gexp": function(t) {
                        for (; 0 > t;) t += 255;
                        for (; 256 <= t;) t -= 255;
                        return c.EXP_TABLE[t]
                    },
                    "EXP_TABLE": Array(256),
                    "LOG_TABLE": Array(256)
                }, d = 0; 8 > d; d++) c.EXP_TABLE[d] = 1 << d;
            for (d = 8; 256 > d; d++) c.EXP_TABLE[d] = c.EXP_TABLE[d - 4] ^ c.EXP_TABLE[d - 5] ^ c.EXP_TABLE[d - 6] ^ c.EXP_TABLE[d - 8];
            for (d = 0; 255 > d; d++) c.LOG_TABLE[c.EXP_TABLE[d]] = d;
            return o.prototype = {
                "get": function(t) {
                    return this.num[t]
                },
                "getLength": function() {
                    return this.num.length
                },
                "multiply": function(t) {
                    for (var e = Array(this.getLength() + t.getLength() - 1), i = 0; i < this.getLength(); i++)
                        for (var n = 0; n < t.getLength(); n++) e[i + n] ^= c.gexp(c.glog(this.get(i)) + c.glog(t.get(n)));
                    return new o(e, 0)
                },
                "mod": function(t) {
                    if (0 > this.getLength() - t.getLength()) return this;
                    for (var e = c.glog(this.get(0)) - c.glog(t.get(0)), i = Array(this.getLength()), n = 0; n < this.getLength(); n++) i[n] = this.get(n);
                    for (n = 0; n < t.getLength(); n++) i[n] ^= c.gexp(c.glog(t.get(n)) + e);
                    return new o(i, 0).mod(t)
                }
            }, a.RS_BLOCK_TABLE = [
                [1, 26, 19],
                [1, 26, 16],
                [1, 26, 13],
                [1, 26, 9],
                [1, 44, 34],
                [1, 44, 28],
                [1, 44, 22],
                [1, 44, 16],
                [1, 70, 55],
                [1, 70, 44],
                [2, 35, 17],
                [2, 35, 13],
                [1, 100, 80],
                [2, 50, 32],
                [2, 50, 24],
                [4, 25, 9],
                [1, 134, 108],
                [2, 67, 43],
                [2, 33, 15, 2, 34, 16],
                [2, 33, 11, 2, 34, 12],
                [2, 86, 68],
                [4, 43, 27],
                [4, 43, 19],
                [4, 43, 15],
                [2, 98, 78],
                [4, 49, 31],
                [2, 32, 14, 4, 33, 15],
                [4, 39, 13, 1, 40, 14],
                [2, 121, 97],
                [2, 60, 38, 2, 61, 39],
                [4, 40, 18, 2, 41, 19],
                [4, 40, 14, 2, 41, 15],
                [2, 146, 116],
                [3, 58, 36, 2, 59, 37],
                [4, 36, 16, 4, 37, 17],
                [4, 36, 12, 4, 37, 13],
                [2, 86, 68, 2, 87, 69],
                [4, 69, 43, 1, 70, 44],
                [6, 43, 19, 2, 44, 20],
                [6, 43, 15, 2, 44, 16],
                [4, 101, 81],
                [1, 80, 50, 4, 81, 51],
                [4, 50, 22, 4, 51, 23],
                [3, 36, 12, 8, 37, 13],
                [2, 116, 92, 2, 117, 93],
                [6, 58, 36, 2, 59, 37],
                [4, 46, 20, 6, 47, 21],
                [7, 42, 14, 4, 43, 15],
                [4, 133, 107],
                [8, 59, 37, 1, 60, 38],
                [8, 44, 20, 4, 45, 21],
                [12, 33, 11, 4, 34, 12],
                [3, 145, 115, 1, 146, 116],
                [4, 64, 40, 5, 65, 41],
                [11, 36, 16, 5, 37, 17],
                [11, 36, 12, 5, 37, 13],
                [5, 109, 87, 1, 110, 88],
                [5, 65, 41, 5, 66, 42],
                [5, 54, 24, 7, 55, 25],
                [11, 36, 12],
                [5, 122, 98, 1, 123, 99],
                [7, 73, 45, 3, 74, 46],
                [15, 43, 19, 2, 44, 20],
                [3, 45, 15, 13, 46, 16],
                [1, 135, 107, 5, 136, 108],
                [10, 74, 46, 1, 75, 47],
                [1, 50, 22, 15, 51, 23],
                [2, 42, 14, 17, 43, 15],
                [5, 150, 120, 1, 151, 121],
                [9, 69, 43, 4, 70, 44],
                [17, 50, 22, 1, 51, 23],
                [2, 42, 14, 19, 43, 15],
                [3, 141, 113, 4, 142, 114],
                [3, 70, 44, 11, 71, 45],
                [17, 47, 21, 4, 48, 22],
                [9, 39, 13, 16, 40, 14],
                [3, 135, 107, 5, 136, 108],
                [3, 67, 41, 13, 68, 42],
                [15, 54, 24, 5, 55, 25],
                [15, 43, 15, 10, 44, 16],
                [4, 144, 116, 4, 145, 117],
                [17, 68, 42],
                [17, 50, 22, 6, 51, 23],
                [19, 46, 16, 6, 47, 17],
                [2, 139, 111, 7, 140, 112],
                [17, 74, 46],
                [7, 54, 24, 16, 55, 25],
                [34, 37, 13],
                [4, 151, 121, 5, 152, 122],
                [4, 75, 47, 14, 76, 48],
                [11, 54, 24, 14, 55, 25],
                [16, 45, 15, 14, 46, 16],
                [6, 147, 117, 4, 148, 118],
                [6, 73, 45, 14, 74, 46],
                [11, 54, 24, 16, 55, 25],
                [30, 46, 16, 2, 47, 17],
                [8, 132, 106, 4, 133, 107],
                [8, 75, 47, 13, 76, 48],
                [7, 54, 24, 22, 55, 25],
                [22, 45, 15, 13, 46, 16],
                [10, 142, 114, 2, 143, 115],
                [19, 74, 46, 4, 75, 47],
                [28, 50, 22, 6, 51, 23],
                [33, 46, 16, 4, 47, 17],
                [8, 152, 122, 4, 153, 123],
                [22, 73, 45, 3, 74, 46],
                [8, 53, 23, 26, 54, 24],
                [12, 45, 15, 28, 46, 16],
                [3, 147, 117, 10, 148, 118],
                [3, 73, 45, 23, 74, 46],
                [4, 54, 24, 31, 55, 25],
                [11, 45, 15, 31, 46, 16],
                [7, 146, 116, 7, 147, 117],
                [21, 73, 45, 7, 74, 46],
                [1, 53, 23, 37, 54, 24],
                [19, 45, 15, 26, 46, 16],
                [5, 145, 115, 10, 146, 116],
                [19, 75, 47, 10, 76, 48],
                [15, 54, 24, 25, 55, 25],
                [23, 45, 15, 25, 46, 16],
                [13, 145, 115, 3, 146, 116],
                [2, 74, 46, 29, 75, 47],
                [42, 54, 24, 1, 55, 25],
                [23, 45, 15, 28, 46, 16],
                [17, 145, 115],
                [10, 74, 46, 23, 75, 47],
                [10, 54, 24, 35, 55, 25],
                [19, 45, 15, 35, 46, 16],
                [17, 145, 115, 1, 146, 116],
                [14, 74, 46, 21, 75, 47],
                [29, 54, 24, 19, 55, 25],
                [11, 45, 15, 46, 46, 16],
                [13, 145, 115, 6, 146, 116],
                [14, 74, 46, 23, 75, 47],
                [44, 54, 24, 7, 55, 25],
                [59, 46, 16, 1, 47, 17],
                [12, 151, 121, 7, 152, 122],
                [12, 75, 47, 26, 76, 48],
                [39, 54, 24, 14, 55, 25],
                [22, 45, 15, 41, 46, 16],
                [6, 151, 121, 14, 152, 122],
                [6, 75, 47, 34, 76, 48],
                [46, 54, 24, 10, 55, 25],
                [2, 45, 15, 64, 46, 16],
                [17, 152, 122, 4, 153, 123],
                [29, 74, 46, 14, 75, 47],
                [49, 54, 24, 10, 55, 25],
                [24, 45, 15, 46, 46, 16],
                [4, 152, 122, 18, 153, 123],
                [13, 74, 46, 32, 75, 47],
                [48, 54, 24, 14, 55, 25],
                [42, 45, 15, 32, 46, 16],
                [20, 147, 117, 4, 148, 118],
                [40, 75, 47, 7, 76, 48],
                [43, 54, 24, 22, 55, 25],
                [10, 45, 15, 67, 46, 16],
                [19, 148, 118, 6, 149, 119],
                [18, 75, 47, 31, 76, 48],
                [34, 54, 24, 34, 55, 25],
                [20, 45, 15, 61, 46, 16]
            ], a.getRSBlocks = function(t, e) {
                var i = a.getRsBlockTable(t, e);
                if (void 0 == i) throw Error("bad rs block @ typeNumber:" + t + "/errorCorrectLevel:" + e);
                for (var n = i.length / 3, o = [], s = 0; s < n; s++)
                    for (var r = i[3 * s + 0], l = i[3 * s + 1], c = i[3 * s + 2], d = 0; d < r; d++) o.push(new a(l, c));
                return o
            }, a.getRsBlockTable = function(t, e) {
                switch (e) {
                    case 1:
                        return a.RS_BLOCK_TABLE[4 * (t - 1) + 0];
                    case 0:
                        return a.RS_BLOCK_TABLE[4 * (t - 1) + 1];
                    case 3:
                        return a.RS_BLOCK_TABLE[4 * (t - 1) + 2];
                    case 2:
                        return a.RS_BLOCK_TABLE[4 * (t - 1) + 3]
                }
            }, s.prototype = {
                "get": function(t) {
                    return 1 == (this.buffer[Math.floor(t / 8)] >>> 7 - t % 8 & 1)
                },
                "put": function(t, e) {
                    for (var i = 0; i < e; i++) this.putBit(1 == (t >>> e - i - 1 & 1))
                },
                "getLengthInBits": function() {
                    return this.length
                },
                "putBit": function(t) {
                    var e = Math.floor(this.length / 8);
                    this.buffer.length <= e && this.buffer.push(0), t && (this.buffer[e] |= 128 >>> this.length % 8), this.length++
                }
            }, "string" == typeof e && (e = {
                "text": e
            }), e = t.extend({}, {
                "render": "canvas",
                "width": 256,
                "height": 256,
                "typeNumber": -1,
                "correctLevel": 2,
                "background": "#ffffff",
                "foreground": "#000000"
            }, e), this.each(function() {
                var i;
                if ("canvas" == e.render) {
                    i = new n(e.typeNumber, e.correctLevel), i.addData(e.text), i.make();
                    var o = document.createElement("canvas");
                    o.width = e.width, o.height = e.height;
                    for (var a = o.getContext("2d"), s = e.width / i.getModuleCount(), r = e.height / i.getModuleCount(), l = 0; l < i.getModuleCount(); l++)
                        for (var c = 0; c < i.getModuleCount(); c++) {
                            a.fillStyle = i.isDark(l, c) ? e.foreground : e.background;
                            var d = Math.ceil((c + 1) * s) - Math.floor(c * s),
                                u = Math.ceil((l + 1) * s) - Math.floor(l * s);
                            a.fillRect(Math.round(c * s), Math.round(l * r), d, u)
                        }
                } else
                    for (i = new n(e.typeNumber, e.correctLevel), i.addData(e.text), i.make(), o = t("<table></table>").css("width", e.width + "px").css("height", e.height + "px").css("border", "0px").css("border-collapse", "collapse").css("background-color", e.background), a = e.width / i.getModuleCount(), s = e.height / i.getModuleCount(), r = 0; r < i.getModuleCount(); r++)
                        for (l = t("<tr></tr>").css("height", s + "px").appendTo(o), c = 0; c < i.getModuleCount(); c++) t("<td></td>").css("width", a + "px").css("background-color", i.isDark(r, c) ? e.foreground : e.background).appendTo(l);
                i = o, jQuery(i).appendTo(this)
            })
        }
    }(jQuery)
}, function(t, e, i) {
    "use strict";
    var n, o, a, s = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
        return typeof t
    } : function(t) {
        return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
    };
    ! function(r, l) {
        "object" == s(e) && void 0 !== t ? l(i(0)) : (o = [i(0)], n = l, (a = "function" == typeof n ? n.apply(e, o) : n) !== undefined && (t.exports = a))
    }(undefined, function(t) {
        t = "default" in t ? t["default"] : t;
        var e = {
                "autoselect": 0,
                "placeholder": !0,
                "valueType": "name",
                "province": "—— 省 ——",
                "city": "—— 市 ——",
                "district": "—— 区 ——"
            },
            i = {
                "100000": {
                    "110000": "北京市",
                    "120000": "天津市",
                    "130000": "河北省",
                    "140000": "山西省",
                    "150000": "内蒙古自治区",
                    "210000": "辽宁省",
                    "220000": "吉林省",
                    "230000": "黑龙江省",
                    "310000": "上海市",
                    "320000": "江苏省",
                    "330000": "浙江省",
                    "340000": "安徽省",
                    "350000": "福建省",
                    "360000": "江西省",
                    "370000": "山东省",
                    "410000": "河南省",
                    "420000": "湖北省",
                    "430000": "湖南省",
                    "440000": "广东省",
                    "450000": "广西壮族自治区",
                    "460000": "海南省",
                    "500000": "重庆市",
                    "510000": "四川省",
                    "520000": "贵州省",
                    "530000": "云南省",
                    "540000": "西藏自治区",
                    "610000": "陕西省",
                    "620000": "甘肃省",
                    "630000": "青海省",
                    "640000": "宁夏回族自治区",
                    "650000": "新疆维吾尔自治区",
                    "710000": "台湾省",
                    "810000": "香港特别行政区",
                    "820000": "澳门特别行政区"
                },
                "110000": {
                    "110100": "北京市市辖区"
                },
                "110100": {
                    "110101": "东城区",
                    "110102": "西城区",
                    "110105": "朝阳区",
                    "110106": "丰台区",
                    "110107": "石景山区",
                    "110108": "海淀区",
                    "110109": "门头沟区",
                    "110111": "房山区",
                    "110112": "通州区",
                    "110113": "顺义区",
                    "110114": "昌平区",
                    "110115": "大兴区",
                    "110116": "怀柔区",
                    "110117": "平谷区",
                    "110118": "密云区",
                    "110119": "延庆区"
                },
                "120000": {
                    "120100": "天津市市辖区"
                },
                "120100": {
                    "120101": "和平区",
                    "120102": "河东区",
                    "120103": "河西区",
                    "120104": "南开区",
                    "120105": "河北区",
                    "120106": "红桥区",
                    "120110": "东丽区",
                    "120111": "西青区",
                    "120112": "津南区",
                    "120113": "北辰区",
                    "120114": "武清区",
                    "120115": "宝坻区",
                    "120116": "滨海新区",
                    "120117": "宁河区",
                    "120118": "静海区",
                    "120119": "蓟州区"
                },
                "130000": {
                    "130100": "石家庄市",
                    "130200": "唐山市",
                    "130300": "秦皇岛市",
                    "130400": "邯郸市",
                    "130500": "邢台市",
                    "130600": "保定市",
                    "130700": "张家口市",
                    "130800": "承德市",
                    "130900": "沧州市",
                    "131000": "廊坊市",
                    "131100": "衡水市"
                },
                "130100": {
                    "130102": "长安区",
                    "130104": "桥西区",
                    "130105": "新华区",
                    "130107": "井陉矿区",
                    "130108": "裕华区",
                    "130109": "藁城区",
                    "130110": "鹿泉区",
                    "130111": "栾城区",
                    "130121": "井陉县",
                    "130123": "正定县",
                    "130125": "行唐县",
                    "130126": "灵寿县",
                    "130127": "高邑县",
                    "130128": "深泽县",
                    "130129": "赞皇县",
                    "130130": "无极县",
                    "130131": "平山县",
                    "130132": "元氏县",
                    "130133": "赵县",
                    "130181": "辛集市",
                    "130183": "晋州市",
                    "130184": "新乐市"
                },
                "130200": {
                    "130202": "路南区",
                    "130203": "路北区",
                    "130204": "古冶区",
                    "130205": "开平区",
                    "130207": "丰南区",
                    "130208": "丰润区",
                    "130209": "曹妃甸区",
                    "130223": "滦县",
                    "130224": "滦南县",
                    "130225": "乐亭县",
                    "130227": "迁西县",
                    "130229": "玉田县",
                    "130281": "遵化市",
                    "130283": "迁安市"
                },
                "130300": {
                    "130302": "海港区",
                    "130303": "山海关区",
                    "130304": "北戴河区",
                    "130306": "抚宁区",
                    "130321": "青龙满族自治县",
                    "130322": "昌黎县",
                    "130324": "卢龙县"
                },
                "130400": {
                    "130402": "邯山区",
                    "130403": "丛台区",
                    "130404": "复兴区",
                    "130406": "峰峰矿区",
                    "130423": "临漳县",
                    "130424": "成安县",
                    "130425": "大名县",
                    "130426": "涉县",
                    "130427": "磁县",
                    "130428": "肥乡区",
                    "130429": "永年区",
                    "130430": "邱县",
                    "130431": "鸡泽县",
                    "130432": "广平县",
                    "130433": "馆陶县",
                    "130434": "魏县",
                    "130435": "曲周县",
                    "130481": "武安市"
                },
                "130500": {
                    "130502": "桥东区",
                    "130503": "桥西区",
                    "130521": "邢台县",
                    "130522": "临城县",
                    "130523": "内丘县",
                    "130524": "柏乡县",
                    "130525": "隆尧县",
                    "130526": "任县",
                    "130527": "南和县",
                    "130528": "宁晋县",
                    "130529": "巨鹿县",
                    "130530": "新河县",
                    "130531": "广宗县",
                    "130532": "平乡县",
                    "130533": "威县",
                    "130534": "清河县",
                    "130535": "临西县",
                    "130581": "南宫市",
                    "130582": "沙河市"
                },
                "130600": {
                    "130602": "竞秀区",
                    "130606": "莲池区",
                    "130607": "满城区",
                    "130608": "清苑区",
                    "130609": "徐水区",
                    "130623": "涞水县",
                    "130624": "阜平县",
                    "130626": "定兴县",
                    "130627": "唐县",
                    "130628": "高阳县",
                    "130629": "容城县",
                    "130630": "涞源县",
                    "130631": "望都县",
                    "130632": "安新县",
                    "130633": "易县",
                    "130634": "曲阳县",
                    "130635": "蠡县",
                    "130636": "顺平县",
                    "130637": "博野县",
                    "130638": "雄县",
                    "130681": "涿州市",
                    "130682": "定州市",
                    "130683": "安国市",
                    "130684": "高碑店市"
                },
                "130700": {
                    "130702": "桥东区",
                    "130703": "桥西区",
                    "130705": "宣化区",
                    "130706": "下花园区",
                    "130708": "万全区",
                    "130709": "崇礼区",
                    "130722": "张北县",
                    "130723": "康保县",
                    "130724": "沽源县",
                    "130725": "尚义县",
                    "130726": "蔚县",
                    "130727": "阳原县",
                    "130728": "怀安县",
                    "130730": "怀来县",
                    "130731": "涿鹿县",
                    "130732": "赤城县"
                },
                "130800": {
                    "130802": "双桥区",
                    "130803": "双滦区",
                    "130804": "鹰手营子矿区",
                    "130821": "承德县",
                    "130822": "兴隆县",
                    "130823": "平泉县",
                    "130824": "滦平县",
                    "130825": "隆化县",
                    "130826": "丰宁满族自治县",
                    "130827": "宽城满族自治县",
                    "130828": "围场满族蒙古族自治县"
                },
                "130900": {
                    "130902": "新华区",
                    "130903": "运河区",
                    "130921": "沧县",
                    "130922": "青县",
                    "130923": "东光县",
                    "130924": "海兴县",
                    "130925": "盐山县",
                    "130926": "肃宁县",
                    "130927": "南皮县",
                    "130928": "吴桥县",
                    "130929": "献县",
                    "130930": "孟村回族自治县",
                    "130981": "泊头市",
                    "130982": "任丘市",
                    "130983": "黄骅市",
                    "130984": "河间市"
                },
                "131000": {
                    "131002": "安次区",
                    "131003": "广阳区",
                    "131022": "固安县",
                    "131023": "永清县",
                    "131024": "香河县",
                    "131025": "大城县",
                    "131026": "文安县",
                    "131028": "大厂回族自治县",
                    "131081": "霸州市",
                    "131082": "三河市"
                },
                "131100": {
                    "131102": "桃城区",
                    "131103": "冀州区",
                    "131121": "枣强县",
                    "131122": "武邑县",
                    "131123": "武强县",
                    "131124": "饶阳县",
                    "131125": "安平县",
                    "131126": "故城县",
                    "131127": "景县",
                    "131128": "阜城县",
                    "131182": "深州市"
                },
                "140000": {
                    "140100": "太原市",
                    "140200": "大同市",
                    "140300": "阳泉市",
                    "140400": "长治市",
                    "140500": "晋城市",
                    "140600": "朔州市",
                    "140700": "晋中市",
                    "140800": "运城市",
                    "140900": "忻州市",
                    "141000": "临汾市",
                    "141100": "吕梁市"
                },
                "140100": {
                    "140105": "小店区",
                    "140106": "迎泽区",
                    "140107": "杏花岭区",
                    "140108": "尖草坪区",
                    "140109": "万柏林区",
                    "140110": "晋源区",
                    "140121": "清徐县",
                    "140122": "阳曲县",
                    "140123": "娄烦县",
                    "140181": "古交市"
                },
                "140200": {
                    "140202": "城区",
                    "140203": "矿区",
                    "140211": "南郊区",
                    "140212": "新荣区",
                    "140221": "阳高县",
                    "140222": "天镇县",
                    "140223": "广灵县",
                    "140224": "灵丘县",
                    "140225": "浑源县",
                    "140226": "左云县",
                    "140227": "大同县"
                },
                "140300": {
                    "140302": "城区",
                    "140303": "矿区",
                    "140311": "郊区",
                    "140321": "平定县",
                    "140322": "盂县"
                },
                "140400": {
                    "140402": "城区",
                    "140411": "郊区",
                    "140421": "长治县",
                    "140423": "襄垣县",
                    "140424": "屯留县",
                    "140425": "平顺县",
                    "140426": "黎城县",
                    "140427": "壶关县",
                    "140428": "长子县",
                    "140429": "武乡县",
                    "140430": "沁县",
                    "140431": "沁源县",
                    "140481": "潞城市"
                },
                "140500": {
                    "140502": "城区",
                    "140521": "沁水县",
                    "140522": "阳城县",
                    "140524": "陵川县",
                    "140525": "泽州县",
                    "140581": "高平市"
                },
                "140600": {
                    "140602": "朔城区",
                    "140603": "平鲁区",
                    "140621": "山阴县",
                    "140622": "应县",
                    "140623": "右玉县",
                    "140624": "怀仁县"
                },
                "140700": {
                    "140702": "榆次区",
                    "140721": "榆社县",
                    "140722": "左权县",
                    "140723": "和顺县",
                    "140724": "昔阳县",
                    "140725": "寿阳县",
                    "140726": "太谷县",
                    "140727": "祁县",
                    "140728": "平遥县",
                    "140729": "灵石县",
                    "140781": "介休市"
                },
                "140800": {
                    "140802": "盐湖区",
                    "140821": "临猗县",
                    "140822": "万荣县",
                    "140823": "闻喜县",
                    "140824": "稷山县",
                    "140825": "新绛县",
                    "140826": "绛县",
                    "140827": "垣曲县",
                    "140828": "夏县",
                    "140829": "平陆县",
                    "140830": "芮城县",
                    "140881": "永济市",
                    "140882": "河津市"
                },
                "140900": {
                    "140902": "忻府区",
                    "140921": "定襄县",
                    "140922": "五台县",
                    "140923": "代县",
                    "140924": "繁峙县",
                    "140925": "宁武县",
                    "140926": "静乐县",
                    "140927": "神池县",
                    "140928": "五寨县",
                    "140929": "岢岚县",
                    "140930": "河曲县",
                    "140931": "保德县",
                    "140932": "偏关县",
                    "140981": "原平市"
                },
                "141000": {
                    "141002": "尧都区",
                    "141021": "曲沃县",
                    "141022": "翼城县",
                    "141023": "襄汾县",
                    "141024": "洪洞县",
                    "141025": "古县",
                    "141026": "安泽县",
                    "141027": "浮山县",
                    "141028": "吉县",
                    "141029": "乡宁县",
                    "141030": "大宁县",
                    "141031": "隰县",
                    "141032": "永和县",
                    "141033": "蒲县",
                    "141034": "汾西县",
                    "141081": "侯马市",
                    "141082": "霍州市"
                },
                "141100": {
                    "141102": "离石区",
                    "141121": "文水县",
                    "141122": "交城县",
                    "141123": "兴县",
                    "141124": "临县",
                    "141125": "柳林县",
                    "141126": "石楼县",
                    "141127": "岚县",
                    "141128": "方山县",
                    "141129": "中阳县",
                    "141130": "交口县",
                    "141181": "孝义市",
                    "141182": "汾阳市"
                },
                "150000": {
                    "150100": "呼和浩特市",
                    "150200": "包头市",
                    "150300": "乌海市",
                    "150400": "赤峰市",
                    "150500": "通辽市",
                    "150600": "鄂尔多斯市",
                    "150700": "呼伦贝尔市",
                    "150800": "巴彦淖尔市",
                    "150900": "乌兰察布市",
                    "152200": "兴安盟",
                    "152500": "锡林郭勒盟",
                    "152900": "阿拉善盟"
                },
                "150100": {
                    "150102": "新城区",
                    "150103": "回民区",
                    "150104": "玉泉区",
                    "150105": "赛罕区",
                    "150121": "土默特左旗",
                    "150122": "托克托县",
                    "150123": "和林格尔县",
                    "150124": "清水河县",
                    "150125": "武川县"
                },
                "150200": {
                    "150202": "东河区",
                    "150203": "昆都仑区",
                    "150204": "青山区",
                    "150205": "石拐区",
                    "150206": "白云鄂博矿区",
                    "150207": "九原区",
                    "150221": "土默特右旗",
                    "150222": "固阳县",
                    "150223": "达尔罕茂明安联合旗"
                },
                "150300": {
                    "150302": "海勃湾区",
                    "150303": "海南区",
                    "150304": "乌达区"
                },
                "150400": {
                    "150402": "红山区",
                    "150403": "元宝山区",
                    "150404": "松山区",
                    "150421": "阿鲁科尔沁旗",
                    "150422": "巴林左旗",
                    "150423": "巴林右旗",
                    "150424": "林西县",
                    "150425": "克什克腾旗",
                    "150426": "翁牛特旗",
                    "150428": "喀喇沁旗",
                    "150429": "宁城县",
                    "150430": "敖汉旗"
                },
                "150500": {
                    "150502": "科尔沁区",
                    "150521": "科尔沁左翼中旗",
                    "150522": "科尔沁左翼后旗",
                    "150523": "开鲁县",
                    "150524": "库伦旗",
                    "150525": "奈曼旗",
                    "150526": "扎鲁特旗",
                    "150581": "霍林郭勒市"
                },
                "150600": {
                    "150602": "东胜区",
                    "150603": "康巴什区",
                    "150621": "达拉特旗",
                    "150622": "准格尔旗",
                    "150623": "鄂托克前旗",
                    "150624": "鄂托克旗",
                    "150625": "杭锦旗",
                    "150626": "乌审旗",
                    "150627": "伊金霍洛旗"
                },
                "150700": {
                    "150702": "海拉尔区",
                    "150703": "扎赉诺尔区",
                    "150721": "阿荣旗",
                    "150722": "莫力达瓦达斡尔族自治旗",
                    "150723": "鄂伦春自治旗",
                    "150724": "鄂温克族自治旗",
                    "150725": "陈巴尔虎旗",
                    "150726": "新巴尔虎左旗",
                    "150727": "新巴尔虎右旗",
                    "150781": "满洲里市",
                    "150782": "牙克石市",
                    "150783": "扎兰屯市",
                    "150784": "额尔古纳市",
                    "150785": "根河市"
                },
                "150800": {
                    "150802": "临河区",
                    "150821": "五原县",
                    "150822": "磴口县",
                    "150823": "乌拉特前旗",
                    "150824": "乌拉特中旗",
                    "150825": "乌拉特后旗",
                    "150826": "杭锦后旗"
                },
                "150900": {
                    "150902": "集宁区",
                    "150921": "卓资县",
                    "150922": "化德县",
                    "150923": "商都县",
                    "150924": "兴和县",
                    "150925": "凉城县",
                    "150926": "察哈尔右翼前旗",
                    "150927": "察哈尔右翼中旗",
                    "150928": "察哈尔右翼后旗",
                    "150929": "四子王旗",
                    "150981": "丰镇市"
                },
                "152200": {
                    "152201": "乌兰浩特市",
                    "152202": "阿尔山市",
                    "152221": "科尔沁右翼前旗",
                    "152222": "科尔沁右翼中旗",
                    "152223": "扎赉特旗",
                    "152224": "突泉县"
                },
                "152500": {
                    "152501": "二连浩特市",
                    "152502": "锡林浩特市",
                    "152522": "阿巴嘎旗",
                    "152523": "苏尼特左旗",
                    "152524": "苏尼特右旗",
                    "152525": "东乌珠穆沁旗",
                    "152526": "西乌珠穆沁旗",
                    "152527": "太仆寺旗",
                    "152528": "镶黄旗",
                    "152529": "正镶白旗",
                    "152530": "正蓝旗",
                    "152531": "多伦县"
                },
                "152900": {
                    "152921": "阿拉善左旗",
                    "152922": "阿拉善右旗",
                    "152923": "额济纳旗"
                },
                "210000": {
                    "210100": "沈阳市",
                    "210200": "大连市",
                    "210300": "鞍山市",
                    "210400": "抚顺市",
                    "210500": "本溪市",
                    "210600": "丹东市",
                    "210700": "锦州市",
                    "210800": "营口市",
                    "210900": "阜新市",
                    "211000": "辽阳市",
                    "211100": "盘锦市",
                    "211200": "铁岭市",
                    "211300": "朝阳市",
                    "211400": "葫芦岛市"
                },
                "210100": {
                    "210102": "和平区",
                    "210103": "沈河区",
                    "210104": "大东区",
                    "210105": "皇姑区",
                    "210106": "铁西区",
                    "210111": "苏家屯区",
                    "210112": "浑南区",
                    "210113": "沈北新区",
                    "210114": "于洪区",
                    "210115": "辽中区",
                    "210123": "康平县",
                    "210124": "法库县",
                    "210181": "新民市"
                },
                "210200": {
                    "210202": "中山区",
                    "210203": "西岗区",
                    "210204": "沙河口区",
                    "210211": "甘井子区",
                    "210212": "旅顺口区",
                    "210213": "金州区",
                    "210214": "普兰店区",
                    "210224": "长海县",
                    "210281": "瓦房店市",
                    "210283": "庄河市"
                },
                "210300": {
                    "210302": "铁东区",
                    "210303": "铁西区",
                    "210304": "立山区",
                    "210311": "千山区",
                    "210321": "台安县",
                    "210323": "岫岩满族自治县",
                    "210381": "海城市"
                },
                "210400": {
                    "210402": "新抚区",
                    "210403": "东洲区",
                    "210404": "望花区",
                    "210411": "顺城区",
                    "210421": "抚顺县",
                    "210422": "新宾满族自治县",
                    "210423": "清原满族自治县"
                },
                "210500": {
                    "210502": "平山区",
                    "210503": "溪湖区",
                    "210504": "明山区",
                    "210505": "南芬区",
                    "210521": "本溪满族自治县",
                    "210522": "桓仁满族自治县"
                },
                "210600": {
                    "210602": "元宝区",
                    "210603": "振兴区",
                    "210604": "振安区",
                    "210624": "宽甸满族自治县",
                    "210681": "东港市",
                    "210682": "凤城市"
                },
                "210700": {
                    "210702": "古塔区",
                    "210703": "凌河区",
                    "210711": "太和区",
                    "210726": "黑山县",
                    "210727": "义县",
                    "210781": "凌海市",
                    "210782": "北镇市"
                },
                "210800": {
                    "210802": "站前区",
                    "210803": "西市区",
                    "210804": "鲅鱼圈区",
                    "210811": "老边区",
                    "210881": "盖州市",
                    "210882": "大石桥市"
                },
                "210900": {
                    "210902": "海州区",
                    "210903": "新邱区",
                    "210904": "太平区",
                    "210905": "清河门区",
                    "210911": "细河区",
                    "210921": "阜新蒙古族自治县",
                    "210922": "彰武县"
                },
                "211000": {
                    "211002": "白塔区",
                    "211003": "文圣区",
                    "211004": "宏伟区",
                    "211005": "弓长岭区",
                    "211011": "太子河区",
                    "211021": "辽阳县",
                    "211081": "灯塔市"
                },
                "211100": {
                    "211102": "双台子区",
                    "211103": "兴隆台区",
                    "211104": "大洼区",
                    "211122": "盘山县"
                },
                "211200": {
                    "211202": "银州区",
                    "211204": "清河区",
                    "211221": "铁岭县",
                    "211223": "西丰县",
                    "211224": "昌图县",
                    "211281": "调兵山市",
                    "211282": "开原市"
                },
                "211300": {
                    "211302": "双塔区",
                    "211303": "龙城区",
                    "211321": "朝阳县",
                    "211322": "建平县",
                    "211324": "喀喇沁左翼蒙古族自治县",
                    "211381": "北票市",
                    "211382": "凌源市"
                },
                "211400": {
                    "211402": "连山区",
                    "211403": "龙港区",
                    "211404": "南票区",
                    "211421": "绥中县",
                    "211422": "建昌县",
                    "211481": "兴城市"
                },
                "220000": {
                    "220100": "长春市",
                    "220200": "吉林市",
                    "220300": "四平市",
                    "220400": "辽源市",
                    "220500": "通化市",
                    "220600": "白山市",
                    "220700": "松原市",
                    "220800": "白城市",
                    "222400": "延边朝鲜族自治州"
                },
                "220100": {
                    "220102": "南关区",
                    "220103": "宽城区",
                    "220104": "朝阳区",
                    "220105": "二道区",
                    "220106": "绿园区",
                    "220112": "双阳区",
                    "220113": "九台区",
                    "220122": "农安县",
                    "220182": "榆树市",
                    "220183": "德惠市"
                },
                "220200": {
                    "220202": "昌邑区",
                    "220203": "龙潭区",
                    "220204": "船营区",
                    "220211": "丰满区",
                    "220221": "永吉县",
                    "220281": "蛟河市",
                    "220282": "桦甸市",
                    "220283": "舒兰市",
                    "220284": "磐石市"
                },
                "220300": {
                    "220302": "铁西区",
                    "220303": "铁东区",
                    "220322": "梨树县",
                    "220323": "伊通满族自治县",
                    "220381": "公主岭市",
                    "220382": "双辽市"
                },
                "220400": {
                    "220402": "龙山区",
                    "220403": "西安区",
                    "220421": "东丰县",
                    "220422": "东辽县"
                },
                "220500": {
                    "220502": "东昌区",
                    "220503": "二道江区",
                    "220521": "通化县",
                    "220523": "辉南县",
                    "220524": "柳河县",
                    "220581": "梅河口市",
                    "220582": "集安市"
                },
                "220600": {
                    "220602": "浑江区",
                    "220605": "江源区",
                    "220621": "抚松县",
                    "220622": "靖宇县",
                    "220623": "长白朝鲜族自治县",
                    "220681": "临江市"
                },
                "220700": {
                    "220702": "宁江区",
                    "220721": "前郭尔罗斯蒙古族自治县",
                    "220722": "长岭县",
                    "220723": "乾安县",
                    "220781": "扶余市"
                },
                "220800": {
                    "220802": "洮北区",
                    "220821": "镇赉县",
                    "220822": "通榆县",
                    "220881": "洮南市",
                    "220882": "大安市"
                },
                "222400": {
                    "222401": "延吉市",
                    "222402": "图们市",
                    "222403": "敦化市",
                    "222404": "珲春市",
                    "222405": "龙井市",
                    "222406": "和龙市",
                    "222424": "汪清县",
                    "222426": "安图县"
                },
                "230000": {
                    "230100": "哈尔滨市",
                    "230200": "齐齐哈尔市",
                    "230300": "鸡西市",
                    "230400": "鹤岗市",
                    "230500": "双鸭山市",
                    "230600": "大庆市",
                    "230700": "伊春市",
                    "230800": "佳木斯市",
                    "230900": "七台河市",
                    "231000": "牡丹江市",
                    "231100": "黑河市",
                    "231200": "绥化市",
                    "232700": "大兴安岭地区"
                },
                "230100": {
                    "230102": "道里区",
                    "230103": "南岗区",
                    "230104": "道外区",
                    "230108": "平房区",
                    "230109": "松北区",
                    "230110": "香坊区",
                    "230111": "呼兰区",
                    "230112": "阿城区",
                    "230113": "双城区",
                    "230123": "依兰县",
                    "230124": "方正县",
                    "230125": "宾县",
                    "230126": "巴彦县",
                    "230127": "木兰县",
                    "230128": "通河县",
                    "230129": "延寿县",
                    "230183": "尚志市",
                    "230184": "五常市"
                },
                "230200": {
                    "230202": "龙沙区",
                    "230203": "建华区",
                    "230204": "铁锋区",
                    "230205": "昂昂溪区",
                    "230206": "富拉尔基区",
                    "230207": "碾子山区",
                    "230208": "梅里斯达斡尔族区",
                    "230221": "龙江县",
                    "230223": "依安县",
                    "230224": "泰来县",
                    "230225": "甘南县",
                    "230227": "富裕县",
                    "230229": "克山县",
                    "230230": "克东县",
                    "230231": "拜泉县",
                    "230281": "讷河市"
                },
                "230300": {
                    "230302": "鸡冠区",
                    "230303": "恒山区",
                    "230304": "滴道区",
                    "230305": "梨树区",
                    "230306": "城子河区",
                    "230307": "麻山区",
                    "230321": "鸡东县",
                    "230381": "虎林市",
                    "230382": "密山市"
                },
                "230400": {
                    "230402": "向阳区",
                    "230403": "工农区",
                    "230404": "南山区",
                    "230405": "兴安区",
                    "230406": "东山区",
                    "230407": "兴山区",
                    "230421": "萝北县",
                    "230422": "绥滨县"
                },
                "230500": {
                    "230502": "尖山区",
                    "230503": "岭东区",
                    "230505": "四方台区",
                    "230506": "宝山区",
                    "230521": "集贤县",
                    "230522": "友谊县",
                    "230523": "宝清县",
                    "230524": "饶河县"
                },
                "230600": {
                    "230602": "萨尔图区",
                    "230603": "龙凤区",
                    "230604": "让胡路区",
                    "230605": "红岗区",
                    "230606": "大同区",
                    "230621": "肇州县",
                    "230622": "肇源县",
                    "230623": "林甸县",
                    "230624": "杜尔伯特蒙古族自治县"
                },
                "230700": {
                    "230702": "伊春区",
                    "230703": "南岔区",
                    "230704": "友好区",
                    "230705": "西林区",
                    "230706": "翠峦区",
                    "230707": "新青区",
                    "230708": "美溪区",
                    "230709": "金山屯区",
                    "230710": "五营区",
                    "230711": "乌马河区",
                    "230712": "汤旺河区",
                    "230713": "带岭区",
                    "230714": "乌伊岭区",
                    "230715": "红星区",
                    "230716": "上甘岭区",
                    "230722": "嘉荫县",
                    "230781": "铁力市"
                },
                "230800": {
                    "230803": "向阳区",
                    "230804": "前进区",
                    "230805": "东风区",
                    "230811": "郊区",
                    "230822": "桦南县",
                    "230826": "桦川县",
                    "230828": "汤原县",
                    "230881": "同江市",
                    "230882": "富锦市",
                    "230883": "抚远市"
                },
                "230900": {
                    "230902": "新兴区",
                    "230903": "桃山区",
                    "230904": "茄子河区",
                    "230921": "勃利县"
                },
                "231000": {
                    "231002": "东安区",
                    "231003": "阳明区",
                    "231004": "爱民区",
                    "231005": "西安区",
                    "231025": "林口县",
                    "231081": "绥芬河市",
                    "231083": "海林市",
                    "231084": "宁安市",
                    "231085": "穆棱市",
                    "231086": "东宁市"
                },
                "231100": {
                    "231102": "爱辉区",
                    "231121": "嫩江县",
                    "231123": "逊克县",
                    "231124": "孙吴县",
                    "231181": "北安市",
                    "231182": "五大连池市"
                },
                "231200": {
                    "231202": "北林区",
                    "231221": "望奎县",
                    "231222": "兰西县",
                    "231223": "青冈县",
                    "231224": "庆安县",
                    "231225": "明水县",
                    "231226": "绥棱县",
                    "231281": "安达市",
                    "231282": "肇东市",
                    "231283": "海伦市"
                },
                "232700": {
                    "232701": "加格达奇区",
                    "232721": "呼玛县",
                    "232722": "塔河县",
                    "232723": "漠河县"
                },
                "310000": {
                    "310100": "上海市市辖区"
                },
                "310100": {
                    "310101": "黄浦区",
                    "310104": "徐汇区",
                    "310105": "长宁区",
                    "310106": "静安区",
                    "310107": "普陀区",
                    "310109": "虹口区",
                    "310110": "杨浦区",
                    "310112": "闵行区",
                    "310113": "宝山区",
                    "310114": "嘉定区",
                    "310115": "浦东新区",
                    "310116": "金山区",
                    "310117": "松江区",
                    "310118": "青浦区",
                    "310120": "奉贤区",
                    "310151": "崇明区"
                },
                "320000": {
                    "320100": "南京市",
                    "320200": "无锡市",
                    "320300": "徐州市",
                    "320400": "常州市",
                    "320500": "苏州市",
                    "320600": "南通市",
                    "320700": "连云港市",
                    "320800": "淮安市",
                    "320900": "盐城市",
                    "321000": "扬州市",
                    "321100": "镇江市",
                    "321200": "泰州市",
                    "321300": "宿迁市"
                },
                "320100": {
                    "320102": "玄武区",
                    "320104": "秦淮区",
                    "320105": "建邺区",
                    "320106": "鼓楼区",
                    "320111": "浦口区",
                    "320113": "栖霞区",
                    "320114": "雨花台区",
                    "320115": "江宁区",
                    "320116": "六合区",
                    "320117": "溧水区",
                    "320118": "高淳区"
                },
                "320200": {
                    "320205": "锡山区",
                    "320206": "惠山区",
                    "320211": "滨湖区",
                    "320213": "梁溪区",
                    "320214": "新吴区",
                    "320281": "江阴市",
                    "320282": "宜兴市"
                },
                "320300": {
                    "320302": "鼓楼区",
                    "320303": "云龙区",
                    "320305": "贾汪区",
                    "320311": "泉山区",
                    "320312": "铜山区",
                    "320321": "丰县",
                    "320322": "沛县",
                    "320324": "睢宁县",
                    "320381": "新沂市",
                    "320382": "邳州市"
                },
                "320400": {
                    "320402": "天宁区",
                    "320404": "钟楼区",
                    "320411": "新北区",
                    "320412": "武进区",
                    "320413": "金坛区",
                    "320481": "溧阳市"
                },
                "320500": {
                    "320505": "虎丘区",
                    "320506": "吴中区",
                    "320507": "相城区",
                    "320508": "姑苏区",
                    "320509": "吴江区",
                    "320581": "常熟市",
                    "320582": "张家港市",
                    "320583": "昆山市",
                    "320585": "太仓市"
                },
                "320600": {
                    "320602": "崇川区",
                    "320611": "港闸区",
                    "320612": "通州区",
                    "320621": "海安县",
                    "320623": "如东县",
                    "320681": "启东市",
                    "320682": "如皋市",
                    "320684": "海门市"
                },
                "320700": {
                    "320703": "连云区",
                    "320706": "海州区",
                    "320707": "赣榆区",
                    "320722": "东海县",
                    "320723": "灌云县",
                    "320724": "灌南县"
                },
                "320800": {
                    "320802": "清江浦区",
                    "320803": "淮安区",
                    "320804": "淮阴区",
                    "320813": "洪泽区",
                    "320826": "涟水县",
                    "320830": "盱眙县",
                    "320831": "金湖县"
                },
                "320900": {
                    "320902": "亭湖区",
                    "320903": "盐都区",
                    "320904": "大丰区",
                    "320921": "响水县",
                    "320922": "滨海县",
                    "320923": "阜宁县",
                    "320924": "射阳县",
                    "320925": "建湖县",
                    "320981": "东台市"
                },
                "321000": {
                    "321002": "广陵区",
                    "321003": "邗江区",
                    "321012": "江都区",
                    "321023": "宝应县",
                    "321081": "仪征市",
                    "321084": "高邮市"
                },
                "321100": {
                    "321102": "京口区",
                    "321111": "润州区",
                    "321112": "丹徒区",
                    "321181": "丹阳市",
                    "321182": "扬中市",
                    "321183": "句容市"
                },
                "321200": {
                    "321202": "海陵区",
                    "321203": "高港区",
                    "321204": "姜堰区",
                    "321281": "兴化市",
                    "321282": "靖江市",
                    "321283": "泰兴市"
                },
                "321300": {
                    "321302": "宿城区",
                    "321311": "宿豫区",
                    "321322": "沭阳县",
                    "321323": "泗阳县",
                    "321324": "泗洪县"
                },
                "330000": {
                    "330100": "杭州市",
                    "330200": "宁波市",
                    "330300": "温州市",
                    "330400": "嘉兴市",
                    "330500": "湖州市",
                    "330600": "绍兴市",
                    "330700": "金华市",
                    "330800": "衢州市",
                    "330900": "舟山市",
                    "331000": "台州市",
                    "331100": "丽水市"
                },
                "330100": {
                    "330102": "上城区",
                    "330103": "下城区",
                    "330104": "江干区",
                    "330105": "拱墅区",
                    "330106": "西湖区",
                    "330108": "滨江区",
                    "330109": "萧山区",
                    "330110": "余杭区",
                    "330111": "富阳区",
                    "330122": "桐庐县",
                    "330127": "淳安县",
                    "330182": "建德市",
                    "330185": "临安市"
                },
                "330200": {
                    "330203": "海曙区",
                    "330205": "江北区",
                    "330206": "北仑区",
                    "330211": "镇海区",
                    "330212": "鄞州区",
                    "330225": "象山县",
                    "330226": "宁海县",
                    "330281": "余姚市",
                    "330282": "慈溪市",
                    "330283": "奉化区"
                },
                "330300": {
                    "330302": "鹿城区",
                    "330303": "龙湾区",
                    "330304": "瓯海区",
                    "330305": "洞头区",
                    "330324": "永嘉县",
                    "330326": "平阳县",
                    "330327": "苍南县",
                    "330328": "文成县",
                    "330329": "泰顺县",
                    "330381": "瑞安市",
                    "330382": "乐清市"
                },
                "330400": {
                    "330402": "南湖区",
                    "330411": "秀洲区",
                    "330421": "嘉善县",
                    "330424": "海盐县",
                    "330481": "海宁市",
                    "330482": "平湖市",
                    "330483": "桐乡市"
                },
                "330500": {
                    "330502": "吴兴区",
                    "330503": "南浔区",
                    "330521": "德清县",
                    "330522": "长兴县",
                    "330523": "安吉县"
                },
                "330600": {
                    "330602": "越城区",
                    "330603": "柯桥区",
                    "330604": "上虞区",
                    "330624": "新昌县",
                    "330681": "诸暨市",
                    "330683": "嵊州市"
                },
                "330700": {
                    "330702": "婺城区",
                    "330703": "金东区",
                    "330723": "武义县",
                    "330726": "浦江县",
                    "330727": "磐安县",
                    "330781": "兰溪市",
                    "330782": "义乌市",
                    "330783": "东阳市",
                    "330784": "永康市"
                },
                "330800": {
                    "330802": "柯城区",
                    "330803": "衢江区",
                    "330822": "常山县",
                    "330824": "开化县",
                    "330825": "龙游县",
                    "330881": "江山市"
                },
                "330900": {
                    "330902": "定海区",
                    "330903": "普陀区",
                    "330921": "岱山县",
                    "330922": "嵊泗县"
                },
                "331000": {
                    "331002": "椒江区",
                    "331003": "黄岩区",
                    "331004": "路桥区",
                    "331021": "玉环县",
                    "331022": "三门县",
                    "331023": "天台县",
                    "331024": "仙居县",
                    "331081": "温岭市",
                    "331082": "临海市"
                },
                "331100": {
                    "331102": "莲都区",
                    "331121": "青田县",
                    "331122": "缙云县",
                    "331123": "遂昌县",
                    "331124": "松阳县",
                    "331125": "云和县",
                    "331126": "庆元县",
                    "331127": "景宁畲族自治县",
                    "331181": "龙泉市"
                },
                "340000": {
                    "340100": "合肥市",
                    "340200": "芜湖市",
                    "340300": "蚌埠市",
                    "340400": "淮南市",
                    "340500": "马鞍山市",
                    "340600": "淮北市",
                    "340700": "铜陵市",
                    "340800": "安庆市",
                    "341000": "黄山市",
                    "341100": "滁州市",
                    "341200": "阜阳市",
                    "341300": "宿州市",
                    "341500": "六安市",
                    "341600": "亳州市",
                    "341700": "池州市",
                    "341800": "宣城市"
                },
                "340100": {
                    "340102": "瑶海区",
                    "340103": "庐阳区",
                    "340104": "蜀山区",
                    "340111": "包河区",
                    "340121": "长丰县",
                    "340122": "肥东县",
                    "340123": "肥西县",
                    "340124": "庐江县",
                    "340181": "巢湖市"
                },
                "340200": {
                    "340202": "镜湖区",
                    "340203": "弋江区",
                    "340207": "鸠江区",
                    "340208": "三山区",
                    "340221": "芜湖县",
                    "340222": "繁昌县",
                    "340223": "南陵县",
                    "340225": "无为县"
                },
                "340300": {
                    "340302": "龙子湖区",
                    "340303": "蚌山区",
                    "340304": "禹会区",
                    "340311": "淮上区",
                    "340321": "怀远县",
                    "340322": "五河县",
                    "340323": "固镇县"
                },
                "340400": {
                    "340402": "大通区",
                    "340403": "田家庵区",
                    "340404": "谢家集区",
                    "340405": "八公山区",
                    "340406": "潘集区",
                    "340421": "凤台县",
                    "340422": "寿县"
                },
                "340500": {
                    "340503": "花山区",
                    "340504": "雨山区",
                    "340506": "博望区",
                    "340521": "当涂县",
                    "340522": "含山县",
                    "340523": "和县"
                },
                "340600": {
                    "340602": "杜集区",
                    "340603": "相山区",
                    "340604": "烈山区",
                    "340621": "濉溪县"
                },
                "340700": {
                    "340705": "铜官区",
                    "340706": "义安区",
                    "340711": "郊区",
                    "340722": "枞阳县"
                },
                "340800": {
                    "340802": "迎江区",
                    "340803": "大观区",
                    "340811": "宜秀区",
                    "340822": "怀宁县",
                    "340824": "潜山县",
                    "340825": "太湖县",
                    "340826": "宿松县",
                    "340827": "望江县",
                    "340828": "岳西县",
                    "340881": "桐城市"
                },
                "341000": {
                    "341002": "屯溪区",
                    "341003": "黄山区",
                    "341004": "徽州区",
                    "341021": "歙县",
                    "341022": "休宁县",
                    "341023": "黟县",
                    "341024": "祁门县"
                },
                "341100": {
                    "341102": "琅琊区",
                    "341103": "南谯区",
                    "341122": "来安县",
                    "341124": "全椒县",
                    "341125": "定远县",
                    "341126": "凤阳县",
                    "341181": "天长市",
                    "341182": "明光市"
                },
                "341200": {
                    "341202": "颍州区",
                    "341203": "颍东区",
                    "341204": "颍泉区",
                    "341221": "临泉县",
                    "341222": "太和县",
                    "341225": "阜南县",
                    "341226": "颍上县",
                    "341282": "界首市"
                },
                "341300": {
                    "341302": "埇桥区",
                    "341321": "砀山县",
                    "341322": "萧县",
                    "341323": "灵璧县",
                    "341324": "泗县"
                },
                "341500": {
                    "341502": "金安区",
                    "341503": "裕安区",
                    "341504": "叶集区",
                    "341522": "霍邱县",
                    "341523": "舒城县",
                    "341524": "金寨县",
                    "341525": "霍山县"
                },
                "341600": {
                    "341602": "谯城区",
                    "341621": "涡阳县",
                    "341622": "蒙城县",
                    "341623": "利辛县"
                },
                "341700": {
                    "341702": "贵池区",
                    "341721": "东至县",
                    "341722": "石台县",
                    "341723": "青阳县"
                },
                "341800": {
                    "341802": "宣州区",
                    "341821": "郎溪县",
                    "341822": "广德县",
                    "341823": "泾县",
                    "341824": "绩溪县",
                    "341825": "旌德县",
                    "341881": "宁国市"
                },
                "350000": {
                    "350100": "福州市",
                    "350200": "厦门市",
                    "350300": "莆田市",
                    "350400": "三明市",
                    "350500": "泉州市",
                    "350600": "漳州市",
                    "350700": "南平市",
                    "350800": "龙岩市",
                    "350900": "宁德市"
                },
                "350100": {
                    "350102": "鼓楼区",
                    "350103": "台江区",
                    "350104": "仓山区",
                    "350105": "马尾区",
                    "350111": "晋安区",
                    "350121": "闽侯县",
                    "350122": "连江县",
                    "350123": "罗源县",
                    "350124": "闽清县",
                    "350125": "永泰县",
                    "350128": "平潭县",
                    "350181": "福清市",
                    "350182": "长乐市"
                },
                "350200": {
                    "350203": "思明区",
                    "350205": "海沧区",
                    "350206": "湖里区",
                    "350211": "集美区",
                    "350212": "同安区",
                    "350213": "翔安区"
                },
                "350300": {
                    "350302": "城厢区",
                    "350303": "涵江区",
                    "350304": "荔城区",
                    "350305": "秀屿区",
                    "350322": "仙游县"
                },
                "350400": {
                    "350402": "梅列区",
                    "350403": "三元区",
                    "350421": "明溪县",
                    "350423": "清流县",
                    "350424": "宁化县",
                    "350425": "大田县",
                    "350426": "尤溪县",
                    "350427": "沙县",
                    "350428": "将乐县",
                    "350429": "泰宁县",
                    "350430": "建宁县",
                    "350481": "永安市"
                },
                "350500": {
                    "350502": "鲤城区",
                    "350503": "丰泽区",
                    "350504": "洛江区",
                    "350505": "泉港区",
                    "350521": "惠安县",
                    "350524": "安溪县",
                    "350525": "永春县",
                    "350526": "德化县",
                    "350527": "金门县",
                    "350581": "石狮市",
                    "350582": "晋江市",
                    "350583": "南安市"
                },
                "350600": {
                    "350602": "芗城区",
                    "350603": "龙文区",
                    "350622": "云霄县",
                    "350623": "漳浦县",
                    "350624": "诏安县",
                    "350625": "长泰县",
                    "350626": "东山县",
                    "350627": "南靖县",
                    "350628": "平和县",
                    "350629": "华安县",
                    "350681": "龙海市"
                },
                "350700": {
                    "350702": "延平区",
                    "350703": "建阳区",
                    "350721": "顺昌县",
                    "350722": "浦城县",
                    "350723": "光泽县",
                    "350724": "松溪县",
                    "350725": "政和县",
                    "350781": "邵武市",
                    "350782": "武夷山市",
                    "350783": "建瓯市"
                },
                "350800": {
                    "350802": "新罗区",
                    "350803": "永定区",
                    "350821": "长汀县",
                    "350823": "上杭县",
                    "350824": "武平县",
                    "350825": "连城县",
                    "350881": "漳平市"
                },
                "350900": {
                    "350902": "蕉城区",
                    "350921": "霞浦县",
                    "350922": "古田县",
                    "350923": "屏南县",
                    "350924": "寿宁县",
                    "350925": "周宁县",
                    "350926": "柘荣县",
                    "350981": "福安市",
                    "350982": "福鼎市"
                },
                "360000": {
                    "360100": "南昌市",
                    "360200": "景德镇市",
                    "360300": "萍乡市",
                    "360400": "九江市",
                    "360500": "新余市",
                    "360600": "鹰潭市",
                    "360700": "赣州市",
                    "360800": "吉安市",
                    "360900": "宜春市",
                    "361000": "抚州市",
                    "361100": "上饶市"
                },
                "360100": {
                    "360102": "东湖区",
                    "360103": "西湖区",
                    "360104": "青云谱区",
                    "360105": "湾里区",
                    "360111": "青山湖区",
                    "360112": "新建区",
                    "360121": "南昌县",
                    "360123": "安义县",
                    "360124": "进贤县"
                },
                "360200": {
                    "360202": "昌江区",
                    "360203": "珠山区",
                    "360222": "浮梁县",
                    "360281": "乐平市"
                },
                "360300": {
                    "360302": "安源区",
                    "360313": "湘东区",
                    "360321": "莲花县",
                    "360322": "上栗县",
                    "360323": "芦溪县"
                },
                "360400": {
                    "360402": "濂溪区",
                    "360403": "浔阳区",
                    "360421": "九江县",
                    "360423": "武宁县",
                    "360424": "修水县",
                    "360425": "永修县",
                    "360426": "德安县",
                    "360427": "庐山市",
                    "360428": "都昌县",
                    "360429": "湖口县",
                    "360430": "彭泽县",
                    "360481": "瑞昌市",
                    "360482": "共青城市"
                },
                "360500": {
                    "360502": "渝水区",
                    "360521": "分宜县"
                },
                "360600": {
                    "360602": "月湖区",
                    "360622": "余江县",
                    "360681": "贵溪市"
                },
                "360700": {
                    "360702": "章贡区",
                    "360703": "南康区",
                    "360721": "赣县区",
                    "360722": "信丰县",
                    "360723": "大余县",
                    "360724": "上犹县",
                    "360725": "崇义县",
                    "360726": "安远县",
                    "360727": "龙南县",
                    "360728": "定南县",
                    "360729": "全南县",
                    "360730": "宁都县",
                    "360731": "于都县",
                    "360732": "兴国县",
                    "360733": "会昌县",
                    "360734": "寻乌县",
                    "360735": "石城县",
                    "360781": "瑞金市"
                },
                "360800": {
                    "360802": "吉州区",
                    "360803": "青原区",
                    "360821": "吉安县",
                    "360822": "吉水县",
                    "360823": "峡江县",
                    "360824": "新干县",
                    "360825": "永丰县",
                    "360826": "泰和县",
                    "360827": "遂川县",
                    "360828": "万安县",
                    "360829": "安福县",
                    "360830": "永新县",
                    "360881": "井冈山市"
                },
                "360900": {
                    "360902": "袁州区",
                    "360921": "奉新县",
                    "360922": "万载县",
                    "360923": "上高县",
                    "360924": "宜丰县",
                    "360925": "靖安县",
                    "360926": "铜鼓县",
                    "360981": "丰城市",
                    "360982": "樟树市",
                    "360983": "高安市"
                },
                "361000": {
                    "361002": "临川区",
                    "361021": "南城县",
                    "361022": "黎川县",
                    "361023": "南丰县",
                    "361024": "崇仁县",
                    "361025": "乐安县",
                    "361026": "宜黄县",
                    "361027": "金溪县",
                    "361028": "资溪县",
                    "361029": "东乡县",
                    "361030": "广昌县"
                },
                "361100": {
                    "361102": "信州区",
                    "361103": "广丰区",
                    "361121": "上饶县",
                    "361123": "玉山县",
                    "361124": "铅山县",
                    "361125": "横峰县",
                    "361126": "弋阳县",
                    "361127": "余干县",
                    "361128": "鄱阳县",
                    "361129": "万年县",
                    "361130": "婺源县",
                    "361181": "德兴市"
                },
                "370000": {
                    "370100": "济南市",
                    "370200": "青岛市",
                    "370300": "淄博市",
                    "370400": "枣庄市",
                    "370500": "东营市",
                    "370600": "烟台市",
                    "370700": "潍坊市",
                    "370800": "济宁市",
                    "370900": "泰安市",
                    "371000": "威海市",
                    "371100": "日照市",
                    "371200": "莱芜市",
                    "371300": "临沂市",
                    "371400": "德州市",
                    "371500": "聊城市",
                    "371600": "滨州市",
                    "371700": "菏泽市"
                },
                "370100": {
                    "370102": "历下区",
                    "370103": "市中区",
                    "370104": "槐荫区",
                    "370105": "天桥区",
                    "370112": "历城区",
                    "370113": "长清区",
                    "370124": "平阴县",
                    "370125": "济阳县",
                    "370126": "商河县",
                    "370181": "章丘区"
                },
                "370200": {
                    "370202": "市南区",
                    "370203": "市北区",
                    "370211": "黄岛区",
                    "370212": "崂山区",
                    "370213": "李沧区",
                    "370214": "城阳区",
                    "370281": "胶州市",
                    "370282": "即墨市",
                    "370283": "平度市",
                    "370285": "莱西市"
                },
                "370300": {
                    "370302": "淄川区",
                    "370303": "张店区",
                    "370304": "博山区",
                    "370305": "临淄区",
                    "370306": "周村区",
                    "370321": "桓台县",
                    "370322": "高青县",
                    "370323": "沂源县"
                },
                "370400": {
                    "370402": "市中区",
                    "370403": "薛城区",
                    "370404": "峄城区",
                    "370405": "台儿庄区",
                    "370406": "山亭区",
                    "370481": "滕州市"
                },
                "370500": {
                    "370502": "东营区",
                    "370503": "河口区",
                    "370505": "垦利区",
                    "370522": "利津县",
                    "370523": "广饶县"
                },
                "370600": {
                    "370602": "芝罘区",
                    "370611": "福山区",
                    "370612": "牟平区",
                    "370613": "莱山区",
                    "370634": "长岛县",
                    "370681": "龙口市",
                    "370682": "莱阳市",
                    "370683": "莱州市",
                    "370684": "蓬莱市",
                    "370685": "招远市",
                    "370686": "栖霞市",
                    "370687": "海阳市"
                },
                "370700": {
                    "370702": "潍城区",
                    "370703": "寒亭区",
                    "370704": "坊子区",
                    "370705": "奎文区",
                    "370724": "临朐县",
                    "370725": "昌乐县",
                    "370781": "青州市",
                    "370782": "诸城市",
                    "370783": "寿光市",
                    "370784": "安丘市",
                    "370785": "高密市",
                    "370786": "昌邑市"
                },
                "370800": {
                    "370811": "任城区",
                    "370812": "兖州区",
                    "370826": "微山县",
                    "370827": "鱼台县",
                    "370828": "金乡县",
                    "370829": "嘉祥县",
                    "370830": "汶上县",
                    "370831": "泗水县",
                    "370832": "梁山县",
                    "370881": "曲阜市",
                    "370883": "邹城市"
                },
                "370900": {
                    "370902": "泰山区",
                    "370911": "岱岳区",
                    "370921": "宁阳县",
                    "370923": "东平县",
                    "370982": "新泰市",
                    "370983": "肥城市"
                },
                "371000": {
                    "371002": "环翠区",
                    "371003": "文登区",
                    "371082": "荣成市",
                    "371083": "乳山市"
                },
                "371100": {
                    "371102": "东港区",
                    "371103": "岚山区",
                    "371121": "五莲县",
                    "371122": "莒县"
                },
                "371200": {
                    "371202": "莱城区",
                    "371203": "钢城区"
                },
                "371300": {
                    "371302": "兰山区",
                    "371311": "罗庄区",
                    "371312": "河东区",
                    "371321": "沂南县",
                    "371322": "郯城县",
                    "371323": "沂水县",
                    "371324": "兰陵县",
                    "371325": "费县",
                    "371326": "平邑县",
                    "371327": "莒南县",
                    "371328": "蒙阴县",
                    "371329": "临沭县"
                },
                "371400": {
                    "371402": "德城区",
                    "371403": "陵城区",
                    "371422": "宁津县",
                    "371423": "庆云县",
                    "371424": "临邑县",
                    "371425": "齐河县",
                    "371426": "平原县",
                    "371427": "夏津县",
                    "371428": "武城县",
                    "371481": "乐陵市",
                    "371482": "禹城市"
                },
                "371500": {
                    "371502": "东昌府区",
                    "371521": "阳谷县",
                    "371522": "莘县",
                    "371523": "茌平县",
                    "371524": "东阿县",
                    "371525": "冠县",
                    "371526": "高唐县",
                    "371581": "临清市"
                },
                "371600": {
                    "371602": "滨城区",
                    "371603": "沾化区",
                    "371621": "惠民县",
                    "371622": "阳信县",
                    "371623": "无棣县",
                    "371625": "博兴县",
                    "371626": "邹平县"
                },
                "371700": {
                    "371702": "牡丹区",
                    "371703": "定陶区",
                    "371721": "曹县",
                    "371722": "单县",
                    "371723": "成武县",
                    "371724": "巨野县",
                    "371725": "郓城县",
                    "371726": "鄄城县",
                    "371728": "东明县"
                },
                "410000": {
                    "410100": "郑州市",
                    "410200": "开封市",
                    "410300": "洛阳市",
                    "410400": "平顶山市",
                    "410500": "安阳市",
                    "410600": "鹤壁市",
                    "410700": "新乡市",
                    "410800": "焦作市",
                    "410900": "濮阳市",
                    "411000": "许昌市",
                    "411100": "漯河市",
                    "411200": "三门峡市",
                    "411300": "南阳市",
                    "411400": "商丘市",
                    "411500": "信阳市",
                    "411600": "周口市",
                    "411700": "驻马店市",
                    "419001": "济源市"
                },
                "410100": {
                    "410102": "中原区",
                    "410103": "二七区",
                    "410104": "管城回族区",
                    "410105": "金水区",
                    "410106": "上街区",
                    "410108": "惠济区",
                    "410122": "中牟县",
                    "410181": "巩义市",
                    "410182": "荥阳市",
                    "410183": "新密市",
                    "410184": "新郑市",
                    "410185": "登封市"
                },
                "410200": {
                    "410202": "龙亭区",
                    "410203": "顺河回族区",
                    "410204": "鼓楼区",
                    "410205": "禹王台区",
                    "410212": "祥符区",
                    "410221": "杞县",
                    "410222": "通许县",
                    "410223": "尉氏县",
                    "410225": "兰考县"
                },
                "410300": {
                    "410302": "老城区",
                    "410303": "西工区",
                    "410304": "瀍河回族区",
                    "410305": "涧西区",
                    "410306": "吉利区",
                    "410311": "洛龙区",
                    "410322": "孟津县",
                    "410323": "新安县",
                    "410324": "栾川县",
                    "410325": "嵩县",
                    "410326": "汝阳县",
                    "410327": "宜阳县",
                    "410328": "洛宁县",
                    "410329": "伊川县",
                    "410381": "偃师市"
                },
                "410400": {
                    "410402": "新华区",
                    "410403": "卫东区",
                    "410404": "石龙区",
                    "410411": "湛河区",
                    "410421": "宝丰县",
                    "410422": "叶县",
                    "410423": "鲁山县",
                    "410425": "郏县",
                    "410481": "舞钢市",
                    "410482": "汝州市"
                },
                "410500": {
                    "410502": "文峰区",
                    "410503": "北关区",
                    "410505": "殷都区",
                    "410506": "龙安区",
                    "410522": "安阳县",
                    "410523": "汤阴县",
                    "410526": "滑县",
                    "410527": "内黄县",
                    "410581": "林州市"
                },
                "410600": {
                    "410602": "鹤山区",
                    "410603": "山城区",
                    "410611": "淇滨区",
                    "410621": "浚县",
                    "410622": "淇县"
                },
                "410700": {
                    "410702": "红旗区",
                    "410703": "卫滨区",
                    "410704": "凤泉区",
                    "410711": "牧野区",
                    "410721": "新乡县",
                    "410724": "获嘉县",
                    "410725": "原阳县",
                    "410726": "延津县",
                    "410727": "封丘县",
                    "410728": "长垣县",
                    "410781": "卫辉市",
                    "410782": "辉县市"
                },
                "410800": {
                    "410802": "解放区",
                    "410803": "中站区",
                    "410804": "马村区",
                    "410811": "山阳区",
                    "410821": "修武县",
                    "410822": "博爱县",
                    "410823": "武陟县",
                    "410825": "温县",
                    "410882": "沁阳市",
                    "410883": "孟州市"
                },
                "410900": {
                    "410902": "华龙区",
                    "410922": "清丰县",
                    "410923": "南乐县",
                    "410926": "范县",
                    "410927": "台前县",
                    "410928": "濮阳县"
                },
                "411000": {
                    "411002": "魏都区",
                    "411023": "建安区",
                    "411024": "鄢陵县",
                    "411025": "襄城县",
                    "411081": "禹州市",
                    "411082": "长葛市"
                },
                "411100": {
                    "411102": "源汇区",
                    "411103": "郾城区",
                    "411104": "召陵区",
                    "411121": "舞阳县",
                    "411122": "临颍县"
                },
                "411200": {
                    "411202": "湖滨区",
                    "411203": "陕州区",
                    "411221": "渑池县",
                    "411224": "卢氏县",
                    "411281": "义马市",
                    "411282": "灵宝市"
                },
                "411300": {
                    "411302": "宛城区",
                    "411303": "卧龙区",
                    "411321": "南召县",
                    "411322": "方城县",
                    "411323": "西峡县",
                    "411324": "镇平县",
                    "411325": "内乡县",
                    "411326": "淅川县",
                    "411327": "社旗县",
                    "411328": "唐河县",
                    "411329": "新野县",
                    "411330": "桐柏县",
                    "411381": "邓州市"
                },
                "411400": {
                    "411402": "梁园区",
                    "411403": "睢阳区",
                    "411421": "民权县",
                    "411422": "睢县",
                    "411423": "宁陵县",
                    "411424": "柘城县",
                    "411425": "虞城县",
                    "411426": "夏邑县",
                    "411481": "永城市"
                },
                "411500": {
                    "411502": "浉河区",
                    "411503": "平桥区",
                    "411521": "罗山县",
                    "411522": "光山县",
                    "411523": "新县",
                    "411524": "商城县",
                    "411525": "固始县",
                    "411526": "潢川县",
                    "411527": "淮滨县",
                    "411528": "息县"
                },
                "411600": {
                    "411602": "川汇区",
                    "411621": "扶沟县",
                    "411622": "西华县",
                    "411623": "商水县",
                    "411624": "沈丘县",
                    "411625": "郸城县",
                    "411626": "淮阳县",
                    "411627": "太康县",
                    "411628": "鹿邑县",
                    "411681": "项城市"
                },
                "411700": {
                    "411702": "驿城区",
                    "411721": "西平县",
                    "411722": "上蔡县",
                    "411723": "平舆县",
                    "411724": "正阳县",
                    "411725": "确山县",
                    "411726": "泌阳县",
                    "411727": "汝南县",
                    "411728": "遂平县",
                    "411729": "新蔡县"
                },
                "420000": {
                    "420100": "武汉市",
                    "420200": "黄石市",
                    "420300": "十堰市",
                    "420500": "宜昌市",
                    "420600": "襄阳市",
                    "420700": "鄂州市",
                    "420800": "荆门市",
                    "420900": "孝感市",
                    "421000": "荆州市",
                    "421100": "黄冈市",
                    "421200": "咸宁市",
                    "421300": "随州市",
                    "422800": "恩施土家族苗族自治州",
                    "429004": "仙桃市",
                    "429005": "潜江市",
                    "429006": "天门市",
                    "429021": "神农架林区"
                },
                "420100": {
                    "420102": "江岸区",
                    "420103": "江汉区",
                    "420104": "硚口区",
                    "420105": "汉阳区",
                    "420106": "武昌区",
                    "420107": "青山区",
                    "420111": "洪山区",
                    "420112": "东西湖区",
                    "420113": "汉南区",
                    "420114": "蔡甸区",
                    "420115": "江夏区",
                    "420116": "黄陂区",
                    "420117": "新洲区"
                },
                "420200": {
                    "420202": "黄石港区",
                    "420203": "西塞山区",
                    "420204": "下陆区",
                    "420205": "铁山区",
                    "420222": "阳新县",
                    "420281": "大冶市"
                },
                "420300": {
                    "420302": "茅箭区",
                    "420303": "张湾区",
                    "420304": "郧阳区",
                    "420322": "郧西县",
                    "420323": "竹山县",
                    "420324": "竹溪县",
                    "420325": "房县",
                    "420381": "丹江口市"
                },
                "420500": {
                    "420502": "西陵区",
                    "420503": "伍家岗区",
                    "420504": "点军区",
                    "420505": "猇亭区",
                    "420506": "夷陵区",
                    "420525": "远安县",
                    "420526": "兴山县",
                    "420527": "秭归县",
                    "420528": "长阳土家族自治县",
                    "420529": "五峰土家族自治县",
                    "420581": "宜都市",
                    "420582": "当阳市",
                    "420583": "枝江市"
                },
                "420600": {
                    "420602": "襄城区",
                    "420606": "樊城区",
                    "420607": "襄州区",
                    "420624": "南漳县",
                    "420625": "谷城县",
                    "420626": "保康县",
                    "420682": "老河口市",
                    "420683": "枣阳市",
                    "420684": "宜城市"
                },
                "420700": {
                    "420702": "梁子湖区",
                    "420703": "华容区",
                    "420704": "鄂城区"
                },
                "420800": {
                    "420802": "东宝区",
                    "420804": "掇刀区",
                    "420821": "京山县",
                    "420822": "沙洋县",
                    "420881": "钟祥市"
                },
                "420900": {
                    "420902": "孝南区",
                    "420921": "孝昌县",
                    "420922": "大悟县",
                    "420923": "云梦县",
                    "420981": "应城市",
                    "420982": "安陆市",
                    "420984": "汉川市"
                },
                "421000": {
                    "421002": "沙市区",
                    "421003": "荆州区",
                    "421022": "公安县",
                    "421023": "监利县",
                    "421024": "江陵县",
                    "421081": "石首市",
                    "421083": "洪湖市",
                    "421087": "松滋市"
                },
                "421100": {
                    "421102": "黄州区",
                    "421121": "团风县",
                    "421122": "红安县",
                    "421123": "罗田县",
                    "421124": "英山县",
                    "421125": "浠水县",
                    "421126": "蕲春县",
                    "421127": "黄梅县",
                    "421181": "麻城市",
                    "421182": "武穴市"
                },
                "421200": {
                    "421202": "咸安区",
                    "421221": "嘉鱼县",
                    "421222": "通城县",
                    "421223": "崇阳县",
                    "421224": "通山县",
                    "421281": "赤壁市"
                },
                "421300": {
                    "421303": "曾都区",
                    "421321": "随县",
                    "421381": "广水市"
                },
                "422800": {
                    "422801": "恩施市",
                    "422802": "利川市",
                    "422822": "建始县",
                    "422823": "巴东县",
                    "422825": "宣恩县",
                    "422826": "咸丰县",
                    "422827": "来凤县",
                    "422828": "鹤峰县"
                },
                "430000": {
                    "430100": "长沙市",
                    "430200": "株洲市",
                    "430300": "湘潭市",
                    "430400": "衡阳市",
                    "430500": "邵阳市",
                    "430600": "岳阳市",
                    "430700": "常德市",
                    "430800": "张家界市",
                    "430900": "益阳市",
                    "431000": "郴州市",
                    "431100": "永州市",
                    "431200": "怀化市",
                    "431300": "娄底市",
                    "433100": "湘西土家族苗族自治州"
                },
                "430100": {
                    "430102": "芙蓉区",
                    "430103": "天心区",
                    "430104": "岳麓区",
                    "430105": "开福区",
                    "430111": "雨花区",
                    "430112": "望城区",
                    "430121": "长沙县",
                    "430124": "宁乡县",
                    "430181": "浏阳市"
                },
                "430200": {
                    "430202": "荷塘区",
                    "430203": "芦淞区",
                    "430204": "石峰区",
                    "430211": "天元区",
                    "430221": "株洲县",
                    "430223": "攸县",
                    "430224": "茶陵县",
                    "430225": "炎陵县",
                    "430281": "醴陵市"
                },
                "430300": {
                    "430302": "雨湖区",
                    "430304": "岳塘区",
                    "430321": "湘潭县",
                    "430381": "湘乡市",
                    "430382": "韶山市"
                },
                "430400": {
                    "430405": "珠晖区",
                    "430406": "雁峰区",
                    "430407": "石鼓区",
                    "430408": "蒸湘区",
                    "430412": "南岳区",
                    "430421": "衡阳县",
                    "430422": "衡南县",
                    "430423": "衡山县",
                    "430424": "衡东县",
                    "430426": "祁东县",
                    "430481": "耒阳市",
                    "430482": "常宁市"
                },
                "430500": {
                    "430502": "双清区",
                    "430503": "大祥区",
                    "430511": "北塔区",
                    "430521": "邵东县",
                    "430522": "新邵县",
                    "430523": "邵阳县",
                    "430524": "隆回县",
                    "430525": "洞口县",
                    "430527": "绥宁县",
                    "430528": "新宁县",
                    "430529": "城步苗族自治县",
                    "430581": "武冈市"
                },
                "430600": {
                    "430602": "岳阳楼区",
                    "430603": "云溪区",
                    "430611": "君山区",
                    "430621": "岳阳县",
                    "430623": "华容县",
                    "430624": "湘阴县",
                    "430626": "平江县",
                    "430681": "汨罗市",
                    "430682": "临湘市"
                },
                "430700": {
                    "430702": "武陵区",
                    "430703": "鼎城区",
                    "430721": "安乡县",
                    "430722": "汉寿县",
                    "430723": "澧县",
                    "430724": "临澧县",
                    "430725": "桃源县",
                    "430726": "石门县",
                    "430781": "津市市"
                },
                "430800": {
                    "430802": "永定区",
                    "430811": "武陵源区",
                    "430821": "慈利县",
                    "430822": "桑植县"
                },
                "430900": {
                    "430902": "资阳区",
                    "430903": "赫山区",
                    "430921": "南县",
                    "430922": "桃江县",
                    "430923": "安化县",
                    "430981": "沅江市"
                },
                "431000": {
                    "431002": "北湖区",
                    "431003": "苏仙区",
                    "431021": "桂阳县",
                    "431022": "宜章县",
                    "431023": "永兴县",
                    "431024": "嘉禾县",
                    "431025": "临武县",
                    "431026": "汝城县",
                    "431027": "桂东县",
                    "431028": "安仁县",
                    "431081": "资兴市"
                },
                "431100": {
                    "431102": "零陵区",
                    "431103": "冷水滩区",
                    "431121": "祁阳县",
                    "431122": "东安县",
                    "431123": "双牌县",
                    "431124": "道县",
                    "431125": "江永县",
                    "431126": "宁远县",
                    "431127": "蓝山县",
                    "431128": "新田县",
                    "431129": "江华瑶族自治县"
                },
                "431200": {
                    "431202": "鹤城区",
                    "431221": "中方县",
                    "431222": "沅陵县",
                    "431223": "辰溪县",
                    "431224": "溆浦县",
                    "431225": "会同县",
                    "431226": "麻阳苗族自治县",
                    "431227": "新晃侗族自治县",
                    "431228": "芷江侗族自治县",
                    "431229": "靖州苗族侗族自治县",
                    "431230": "通道侗族自治县",
                    "431281": "洪江市"
                },
                "431300": {
                    "431302": "娄星区",
                    "431321": "双峰县",
                    "431322": "新化县",
                    "431381": "冷水江市",
                    "431382": "涟源市"
                },
                "433100": {
                    "433101": "吉首市",
                    "433122": "泸溪县",
                    "433123": "凤凰县",
                    "433124": "花垣县",
                    "433125": "保靖县",
                    "433126": "古丈县",
                    "433127": "永顺县",
                    "433130": "龙山县"
                },
                "440000": {
                    "440100": "广州市",
                    "440200": "韶关市",
                    "440300": "深圳市",
                    "440400": "珠海市",
                    "440500": "汕头市",
                    "440600": "佛山市",
                    "440700": "江门市",
                    "440800": "湛江市",
                    "440900": "茂名市",
                    "441200": "肇庆市",
                    "441300": "惠州市",
                    "441400": "梅州市",
                    "441500": "汕尾市",
                    "441600": "河源市",
                    "441700": "阳江市",
                    "441800": "清远市",
                    "441900": "东莞市",
                    "442000": "中山市",
                    "445100": "潮州市",
                    "445200": "揭阳市",
                    "445300": "云浮市"
                },
                "440100": {
                    "440103": "荔湾区",
                    "440104": "越秀区",
                    "440105": "海珠区",
                    "440106": "天河区",
                    "440111": "白云区",
                    "440112": "黄埔区",
                    "440113": "番禺区",
                    "440114": "花都区",
                    "440115": "南沙区",
                    "440117": "从化区",
                    "440118": "增城区"
                },
                "440200": {
                    "440203": "武江区",
                    "440204": "浈江区",
                    "440205": "曲江区",
                    "440222": "始兴县",
                    "440224": "仁化县",
                    "440229": "翁源县",
                    "440232": "乳源瑶族自治县",
                    "440233": "新丰县",
                    "440281": "乐昌市",
                    "440282": "南雄市"
                },
                "440300": {
                    "440303": "罗湖区",
                    "440304": "福田区",
                    "440305": "南山区",
                    "440306": "宝安区",
                    "440307": "龙岗区",
                    "440308": "盐田区",
                    "440309": "龙华区",
                    "440310": "坪山区"
                },
                "440400": {
                    "440402": "香洲区",
                    "440403": "斗门区",
                    "440404": "金湾区"
                },
                "440500": {
                    "440507": "龙湖区",
                    "440511": "金平区",
                    "440512": "濠江区",
                    "440513": "潮阳区",
                    "440514": "潮南区",
                    "440515": "澄海区",
                    "440523": "南澳县"
                },
                "440600": {
                    "440604": "禅城区",
                    "440605": "南海区",
                    "440606": "顺德区",
                    "440607": "三水区",
                    "440608": "高明区"
                },
                "440700": {
                    "440703": "蓬江区",
                    "440704": "江海区",
                    "440705": "新会区",
                    "440781": "台山市",
                    "440783": "开平市",
                    "440784": "鹤山市",
                    "440785": "恩平市"
                },
                "440800": {
                    "440802": "赤坎区",
                    "440803": "霞山区",
                    "440804": "坡头区",
                    "440811": "麻章区",
                    "440823": "遂溪县",
                    "440825": "徐闻县",
                    "440881": "廉江市",
                    "440882": "雷州市",
                    "440883": "吴川市"
                },
                "440900": {
                    "440902": "茂南区",
                    "440904": "电白区",
                    "440981": "高州市",
                    "440982": "化州市",
                    "440983": "信宜市"
                },
                "441200": {
                    "441202": "端州区",
                    "441203": "鼎湖区",
                    "441204": "高要区",
                    "441223": "广宁县",
                    "441224": "怀集县",
                    "441225": "封开县",
                    "441226": "德庆县",
                    "441284": "四会市"
                },
                "441300": {
                    "441302": "惠城区",
                    "441303": "惠阳区",
                    "441322": "博罗县",
                    "441323": "惠东县",
                    "441324": "龙门县"
                },
                "441400": {
                    "441402": "梅江区",
                    "441403": "梅县区",
                    "441422": "大埔县",
                    "441423": "丰顺县",
                    "441424": "五华县",
                    "441426": "平远县",
                    "441427": "蕉岭县",
                    "441481": "兴宁市"
                },
                "441500": {
                    "441502": "城区",
                    "441521": "海丰县",
                    "441523": "陆河县",
                    "441581": "陆丰市"
                },
                "441600": {
                    "441602": "源城区",
                    "441621": "紫金县",
                    "441622": "龙川县",
                    "441623": "连平县",
                    "441624": "和平县",
                    "441625": "东源县"
                },
                "441700": {
                    "441702": "江城区",
                    "441704": "阳东区",
                    "441721": "阳西县",
                    "441781": "阳春市"
                },
                "441800": {
                    "441802": "清城区",
                    "441803": "清新区",
                    "441821": "佛冈县",
                    "441823": "阳山县",
                    "441825": "连山壮族瑶族自治县",
                    "441826": "连南瑶族自治县",
                    "441881": "英德市",
                    "441882": "连州市"
                },
                "445100": {
                    "445102": "湘桥区",
                    "445103": "潮安区",
                    "445122": "饶平县"
                },
                "445200": {
                    "445202": "榕城区",
                    "445203": "揭东区",
                    "445222": "揭西县",
                    "445224": "惠来县",
                    "445281": "普宁市"
                },
                "445300": {
                    "445302": "云城区",
                    "445303": "云安区",
                    "445321": "新兴县",
                    "445322": "郁南县",
                    "445381": "罗定市"
                },
                "450000": {
                    "450100": "南宁市",
                    "450200": "柳州市",
                    "450300": "桂林市",
                    "450400": "梧州市",
                    "450500": "北海市",
                    "450600": "防城港市",
                    "450700": "钦州市",
                    "450800": "贵港市",
                    "450900": "玉林市",
                    "451000": "百色市",
                    "451100": "贺州市",
                    "451200": "河池市",
                    "451300": "来宾市",
                    "451400": "崇左市"
                },
                "450100": {
                    "450102": "兴宁区",
                    "450103": "青秀区",
                    "450105": "江南区",
                    "450107": "西乡塘区",
                    "450108": "良庆区",
                    "450109": "邕宁区",
                    "450110": "武鸣区",
                    "450123": "隆安县",
                    "450124": "马山县",
                    "450125": "上林县",
                    "450126": "宾阳县",
                    "450127": "横县"
                },
                "450200": {
                    "450202": "城中区",
                    "450203": "鱼峰区",
                    "450204": "柳南区",
                    "450205": "柳北区",
                    "450221": "柳江区",
                    "450222": "柳城县",
                    "450223": "鹿寨县",
                    "450224": "融安县",
                    "450225": "融水苗族自治县",
                    "450226": "三江侗族自治县"
                },
                "450300": {
                    "450302": "秀峰区",
                    "450303": "叠彩区",
                    "450304": "象山区",
                    "450305": "七星区",
                    "450311": "雁山区",
                    "450312": "临桂区",
                    "450321": "阳朔县",
                    "450323": "灵川县",
                    "450324": "全州县",
                    "450325": "兴安县",
                    "450326": "永福县",
                    "450327": "灌阳县",
                    "450328": "龙胜各族自治县",
                    "450329": "资源县",
                    "450330": "平乐县",
                    "450331": "荔浦县",
                    "450332": "恭城瑶族自治县"
                },
                "450400": {
                    "450403": "万秀区",
                    "450405": "长洲区",
                    "450406": "龙圩区",
                    "450421": "苍梧县",
                    "450422": "藤县",
                    "450423": "蒙山县",
                    "450481": "岑溪市"
                },
                "450500": {
                    "450502": "海城区",
                    "450503": "银海区",
                    "450512": "铁山港区",
                    "450521": "合浦县"
                },
                "450600": {
                    "450602": "港口区",
                    "450603": "防城区",
                    "450621": "上思县",
                    "450681": "东兴市"
                },
                "450700": {
                    "450702": "钦南区",
                    "450703": "钦北区",
                    "450721": "灵山县",
                    "450722": "浦北县"
                },
                "450800": {
                    "450802": "港北区",
                    "450803": "港南区",
                    "450804": "覃塘区",
                    "450821": "平南县",
                    "450881": "桂平市"
                },
                "450900": {
                    "450902": "玉州区",
                    "450903": "福绵区",
                    "450921": "容县",
                    "450922": "陆川县",
                    "450923": "博白县",
                    "450924": "兴业县",
                    "450981": "北流市"
                },
                "451000": {
                    "451002": "右江区",
                    "451021": "田阳县",
                    "451022": "田东县",
                    "451023": "平果县",
                    "451024": "德保县",
                    "451026": "那坡县",
                    "451027": "凌云县",
                    "451028": "乐业县",
                    "451029": "田林县",
                    "451030": "西林县",
                    "451031": "隆林各族自治县",
                    "451081": "靖西市"
                },
                "451100": {
                    "451102": "八步区",
                    "451103": "平桂区",
                    "451121": "昭平县",
                    "451122": "钟山县",
                    "451123": "富川瑶族自治县"
                },
                "451200": {
                    "451202": "金城江区",
                    "451221": "南丹县",
                    "451222": "天峨县",
                    "451223": "凤山县",
                    "451224": "东兰县",
                    "451225": "罗城仫佬族自治县",
                    "451226": "环江毛南族自治县",
                    "451227": "巴马瑶族自治县",
                    "451228": "都安瑶族自治县",
                    "451229": "大化瑶族自治县",
                    "451281": "宜州市"
                },
                "451300": {
                    "451302": "兴宾区",
                    "451321": "忻城县",
                    "451322": "象州县",
                    "451323": "武宣县",
                    "451324": "金秀瑶族自治县",
                    "451381": "合山市"
                },
                "451400": {
                    "451402": "江州区",
                    "451421": "扶绥县",
                    "451422": "宁明县",
                    "451423": "龙州县",
                    "451424": "大新县",
                    "451425": "天等县",
                    "451481": "凭祥市"
                },
                "460000": {
                    "460100": "海口市",
                    "460200": "三亚市",
                    "460300": "三沙市",
                    "460400": "儋州市",
                    "469001": "五指山市",
                    "469002": "琼海市",
                    "469005": "文昌市",
                    "469006": "万宁市",
                    "469007": "东方市",
                    "469021": "定安县",
                    "469022": "屯昌县",
                    "469023": "澄迈县",
                    "469024": "临高县",
                    "469025": "白沙黎族自治县",
                    "469026": "昌江黎族自治县",
                    "469027": "乐东黎族自治县",
                    "469028": "陵水黎族自治县",
                    "469029": "保亭黎族苗族自治县",
                    "469030": "琼中黎族苗族自治县"
                },
                "460100": {
                    "460105": "秀英区",
                    "460106": "龙华区",
                    "460107": "琼山区",
                    "460108": "美兰区"
                },
                "460200": {
                    "460202": "海棠区",
                    "460203": "吉阳区",
                    "460204": "天涯区",
                    "460205": "崖州区"
                },
                "460300": {
                    "460321": "西沙群岛",
                    "460322": "南沙群岛",
                    "460323": "中沙群岛的岛礁及其海域"
                },
                "500000": {
                    "500100": "重庆市市辖区",
                    "500200": "重庆市郊县"
                },
                "500100": {
                    "500101": "万州区",
                    "500102": "涪陵区",
                    "500103": "渝中区",
                    "500104": "大渡口区",
                    "500105": "江北区",
                    "500106": "沙坪坝区",
                    "500107": "九龙坡区",
                    "500108": "南岸区",
                    "500109": "北碚区",
                    "500110": "綦江区",
                    "500111": "大足区",
                    "500112": "渝北区",
                    "500113": "巴南区",
                    "500114": "黔江区",
                    "500115": "长寿区",
                    "500116": "江津区",
                    "500117": "合川区",
                    "500118": "永川区",
                    "500119": "南川区",
                    "500120": "璧山区",
                    "500151": "铜梁区",
                    "500152": "潼南区",
                    "500153": "荣昌区",
                    "500154": "开州区",
                    "500228": "梁平区",
                    "500229": "城口县",
                    "500230": "丰都县",
                    "500231": "垫江县",
                    "500232": "武隆区",
                    "500233": "忠县",
                    "500235": "云阳县",
                    "500236": "奉节县",
                    "500237": "巫山县",
                    "500238": "巫溪县",
                    "500240": "石柱土家族自治县",
                    "500241": "秀山土家族苗族自治县",
                    "500242": "酉阳土家族苗族自治县",
                    "500243": "彭水苗族土家族自治县"
                },
                "510000": {
                    "510100": "成都市",
                    "510300": "自贡市",
                    "510400": "攀枝花市",
                    "510500": "泸州市",
                    "510600": "德阳市",
                    "510700": "绵阳市",
                    "510800": "广元市",
                    "510900": "遂宁市",
                    "511000": "内江市",
                    "511100": "乐山市",
                    "511300": "南充市",
                    "511400": "眉山市",
                    "511500": "宜宾市",
                    "511600": "广安市",
                    "511700": "达州市",
                    "511800": "雅安市",
                    "511900": "巴中市",
                    "512000": "资阳市",
                    "513200": "阿坝藏族羌族自治州",
                    "513300": "甘孜藏族自治州",
                    "513400": "凉山彝族自治州"
                },
                "510100": {
                    "510104": "锦江区",
                    "510105": "青羊区",
                    "510106": "金牛区",
                    "510107": "武侯区",
                    "510108": "成华区",
                    "510112": "龙泉驿区",
                    "510113": "青白江区",
                    "510114": "新都区",
                    "510115": "温江区",
                    "510116": "双流区",
                    "510121": "金堂县",
                    "510124": "郫都区",
                    "510129": "大邑县",
                    "510131": "蒲江县",
                    "510132": "新津县",
                    "510180": "简阳市",
                    "510181": "都江堰市",
                    "510182": "彭州市",
                    "510183": "邛崃市",
                    "510184": "崇州市"
                },
                "510300": {
                    "510302": "自流井区",
                    "510303": "贡井区",
                    "510304": "大安区",
                    "510311": "沿滩区",
                    "510321": "荣县",
                    "510322": "富顺县"
                },
                "510400": {
                    "510402": "东区",
                    "510403": "西区",
                    "510411": "仁和区",
                    "510421": "米易县",
                    "510422": "盐边县"
                },
                "510500": {
                    "510502": "江阳区",
                    "510503": "纳溪区",
                    "510504": "龙马潭区",
                    "510521": "泸县",
                    "510522": "合江县",
                    "510524": "叙永县",
                    "510525": "古蔺县"
                },
                "510600": {
                    "510603": "旌阳区",
                    "510623": "中江县",
                    "510626": "罗江县",
                    "510681": "广汉市",
                    "510682": "什邡市",
                    "510683": "绵竹市"
                },
                "510700": {
                    "510703": "涪城区",
                    "510704": "游仙区",
                    "510705": "安州区",
                    "510722": "三台县",
                    "510723": "盐亭县",
                    "510725": "梓潼县",
                    "510726": "北川羌族自治县",
                    "510727": "平武县",
                    "510781": "江油市"
                },
                "510800": {
                    "510802": "利州区",
                    "510811": "昭化区",
                    "510812": "朝天区",
                    "510821": "旺苍县",
                    "510822": "青川县",
                    "510823": "剑阁县",
                    "510824": "苍溪县"
                },
                "510900": {
                    "510903": "船山区",
                    "510904": "安居区",
                    "510921": "蓬溪县",
                    "510922": "射洪县",
                    "510923": "大英县"
                },
                "511000": {
                    "511002": "市中区",
                    "511011": "东兴区",
                    "511024": "威远县",
                    "511025": "资中县",
                    "511028": "隆昌县"
                },
                "511100": {
                    "511102": "市中区",
                    "511111": "沙湾区",
                    "511112": "五通桥区",
                    "511113": "金口河区",
                    "511123": "犍为县",
                    "511124": "井研县",
                    "511126": "夹江县",
                    "511129": "沐川县",
                    "511132": "峨边彝族自治县",
                    "511133": "马边彝族自治县",
                    "511181": "峨眉山市"
                },
                "511300": {
                    "511302": "顺庆区",
                    "511303": "高坪区",
                    "511304": "嘉陵区",
                    "511321": "南部县",
                    "511322": "营山县",
                    "511323": "蓬安县",
                    "511324": "仪陇县",
                    "511325": "西充县",
                    "511381": "阆中市"
                },
                "511400": {
                    "511402": "东坡区",
                    "511403": "彭山区",
                    "511421": "仁寿县",
                    "511423": "洪雅县",
                    "511424": "丹棱县",
                    "511425": "青神县"
                },
                "511500": {
                    "511502": "翠屏区",
                    "511503": "南溪区",
                    "511521": "宜宾县",
                    "511523": "江安县",
                    "511524": "长宁县",
                    "511525": "高县",
                    "511526": "珙县",
                    "511527": "筠连县",
                    "511528": "兴文县",
                    "511529": "屏山县"
                },
                "511600": {
                    "511602": "广安区",
                    "511603": "前锋区",
                    "511621": "岳池县",
                    "511622": "武胜县",
                    "511623": "邻水县",
                    "511681": "华蓥市"
                },
                "511700": {
                    "511702": "通川区",
                    "511703": "达川区",
                    "511722": "宣汉县",
                    "511723": "开江县",
                    "511724": "大竹县",
                    "511725": "渠县",
                    "511781": "万源市"
                },
                "511800": {
                    "511802": "雨城区",
                    "511803": "名山区",
                    "511822": "荥经县",
                    "511823": "汉源县",
                    "511824": "石棉县",
                    "511825": "天全县",
                    "511826": "芦山县",
                    "511827": "宝兴县"
                },
                "511900": {
                    "511902": "巴州区",
                    "511903": "恩阳区",
                    "511921": "通江县",
                    "511922": "南江县",
                    "511923": "平昌县"
                },
                "512000": {
                    "512002": "雁江区",
                    "512021": "安岳县",
                    "512022": "乐至县"
                },
                "513200": {
                    "513201": "马尔康市",
                    "513221": "汶川县",
                    "513222": "理县",
                    "513223": "茂县",
                    "513224": "松潘县",
                    "513225": "九寨沟县",
                    "513226": "金川县",
                    "513227": "小金县",
                    "513228": "黑水县",
                    "513230": "壤塘县",
                    "513231": "阿坝县",
                    "513232": "若尔盖县",
                    "513233": "红原县"
                },
                "513300": {
                    "513301": "康定市",
                    "513322": "泸定县",
                    "513323": "丹巴县",
                    "513324": "九龙县",
                    "513325": "雅江县",
                    "513326": "道孚县",
                    "513327": "炉霍县",
                    "513328": "甘孜县",
                    "513329": "新龙县",
                    "513330": "德格县",
                    "513331": "白玉县",
                    "513332": "石渠县",
                    "513333": "色达县",
                    "513334": "理塘县",
                    "513335": "巴塘县",
                    "513336": "乡城县",
                    "513337": "稻城县",
                    "513338": "得荣县"
                },
                "513400": {
                    "513401": "西昌市",
                    "513422": "木里藏族自治县",
                    "513423": "盐源县",
                    "513424": "德昌县",
                    "513425": "会理县",
                    "513426": "会东县",
                    "513427": "宁南县",
                    "513428": "普格县",
                    "513429": "布拖县",
                    "513430": "金阳县",
                    "513431": "昭觉县",
                    "513432": "喜德县",
                    "513433": "冕宁县",
                    "513434": "越西县",
                    "513435": "甘洛县",
                    "513436": "美姑县",
                    "513437": "雷波县"
                },
                "520000": {
                    "520100": "贵阳市",
                    "520200": "六盘水市",
                    "520300": "遵义市",
                    "520400": "安顺市",
                    "520500": "毕节市",
                    "520600": "铜仁市",
                    "522300": "黔西南布依族苗族自治州",
                    "522600": "黔东南苗族侗族自治州",
                    "522700": "黔南布依族苗族自治州"
                },
                "520100": {
                    "520102": "南明区",
                    "520103": "云岩区",
                    "520111": "花溪区",
                    "520112": "乌当区",
                    "520113": "白云区",
                    "520115": "观山湖区",
                    "520121": "开阳县",
                    "520122": "息烽县",
                    "520123": "修文县",
                    "520181": "清镇市"
                },
                "520200": {
                    "520201": "钟山区",
                    "520203": "六枝特区",
                    "520221": "水城县",
                    "520222": "盘县"
                },
                "520300": {
                    "520302": "红花岗区",
                    "520303": "汇川区",
                    "520304": "播州区",
                    "520322": "桐梓县",
                    "520323": "绥阳县",
                    "520324": "正安县",
                    "520325": "道真仡佬族苗族自治县",
                    "520326": "务川仡佬族苗族自治县",
                    "520327": "凤冈县",
                    "520328": "湄潭县",
                    "520329": "余庆县",
                    "520330": "习水县",
                    "520381": "赤水市",
                    "520382": "仁怀市"
                },
                "520400": {
                    "520402": "西秀区",
                    "520403": "平坝区",
                    "520422": "普定县",
                    "520423": "镇宁布依族苗族自治县",
                    "520424": "关岭布依族苗族自治县",
                    "520425": "紫云苗族布依族自治县"
                },
                "520500": {
                    "520502": "七星关区",
                    "520521": "大方县",
                    "520522": "黔西县",
                    "520523": "金沙县",
                    "520524": "织金县",
                    "520525": "纳雍县",
                    "520526": "威宁彝族回族苗族自治县",
                    "520527": "赫章县"
                },
                "520600": {
                    "520602": "碧江区",
                    "520603": "万山区",
                    "520621": "江口县",
                    "520622": "玉屏侗族自治县",
                    "520623": "石阡县",
                    "520624": "思南县",
                    "520625": "印江土家族苗族自治县",
                    "520626": "德江县",
                    "520627": "沿河土家族自治县",
                    "520628": "松桃苗族自治县"
                },
                "522300": {
                    "522301": "兴义市",
                    "522322": "兴仁县",
                    "522323": "普安县",
                    "522324": "晴隆县",
                    "522325": "贞丰县",
                    "522326": "望谟县",
                    "522327": "册亨县",
                    "522328": "安龙县"
                },
                "522600": {
                    "522601": "凯里市",
                    "522622": "黄平县",
                    "522623": "施秉县",
                    "522624": "三穗县",
                    "522625": "镇远县",
                    "522626": "岑巩县",
                    "522627": "天柱县",
                    "522628": "锦屏县",
                    "522629": "剑河县",
                    "522630": "台江县",
                    "522631": "黎平县",
                    "522632": "榕江县",
                    "522633": "从江县",
                    "522634": "雷山县",
                    "522635": "麻江县",
                    "522636": "丹寨县"
                },
                "522700": {
                    "522701": "都匀市",
                    "522702": "福泉市",
                    "522722": "荔波县",
                    "522723": "贵定县",
                    "522725": "瓮安县",
                    "522726": "独山县",
                    "522727": "平塘县",
                    "522728": "罗甸县",
                    "522729": "长顺县",
                    "522730": "龙里县",
                    "522731": "惠水县",
                    "522732": "三都水族自治县"
                },
                "530000": {
                    "530100": "昆明市",
                    "530300": "曲靖市",
                    "530400": "玉溪市",
                    "530500": "保山市",
                    "530600": "昭通市",
                    "530700": "丽江市",
                    "530800": "普洱市",
                    "530900": "临沧市",
                    "532300": "楚雄彝族自治州",
                    "532500": "红河哈尼族彝族自治州",
                    "532600": "文山壮族苗族自治州",
                    "532800": "西双版纳傣族自治州",
                    "532900": "大理白族自治州",
                    "533100": "德宏傣族景颇族自治州",
                    "533300": "怒江傈僳族自治州",
                    "533400": "迪庆藏族自治州"
                },
                "530100": {
                    "530102": "五华区",
                    "530103": "盘龙区",
                    "530111": "官渡区",
                    "530112": "西山区",
                    "530113": "东川区",
                    "530114": "呈贡区",
                    "530122": "晋宁区",
                    "530124": "富民县",
                    "530125": "宜良县",
                    "530126": "石林彝族自治县",
                    "530127": "嵩明县",
                    "530128": "禄劝彝族苗族自治县",
                    "530129": "寻甸回族彝族自治县",
                    "530181": "安宁市"
                },
                "530300": {
                    "530302": "麒麟区",
                    "530303": "沾益区",
                    "530321": "马龙县",
                    "530322": "陆良县",
                    "530323": "师宗县",
                    "530324": "罗平县",
                    "530325": "富源县",
                    "530326": "会泽县",
                    "530381": "宣威市"
                },
                "530400": {
                    "530402": "红塔区",
                    "530403": "江川区",
                    "530422": "澄江县",
                    "530423": "通海县",
                    "530424": "华宁县",
                    "530425": "易门县",
                    "530426": "峨山彝族自治县",
                    "530427": "新平彝族傣族自治县",
                    "530428": "元江哈尼族彝族傣族自治县"
                },
                "530500": {
                    "530502": "隆阳区",
                    "530521": "施甸县",
                    "530523": "龙陵县",
                    "530524": "昌宁县",
                    "530581": "腾冲市"
                },
                "530600": {
                    "530602": "昭阳区",
                    "530621": "鲁甸县",
                    "530622": "巧家县",
                    "530623": "盐津县",
                    "530624": "大关县",
                    "530625": "永善县",
                    "530626": "绥江县",
                    "530627": "镇雄县",
                    "530628": "彝良县",
                    "530629": "威信县",
                    "530630": "水富县"
                },
                "530700": {
                    "530702": "古城区",
                    "530721": "玉龙纳西族自治县",
                    "530722": "永胜县",
                    "530723": "华坪县",
                    "530724": "宁蒗彝族自治县"
                },
                "530800": {
                    "530802": "思茅区",
                    "530821": "宁洱哈尼族彝族自治县",
                    "530822": "墨江哈尼族自治县",
                    "530823": "景东彝族自治县",
                    "530824": "景谷傣族彝族自治县",
                    "530825": "镇沅彝族哈尼族拉祜族自治县",
                    "530826": "江城哈尼族彝族自治县",
                    "530827": "孟连傣族拉祜族佤族自治县",
                    "530828": "澜沧拉祜族自治县",
                    "530829": "西盟佤族自治县"
                },
                "530900": {
                    "530902": "临翔区",
                    "530921": "凤庆县",
                    "530922": "云县",
                    "530923": "永德县",
                    "530924": "镇康县",
                    "530925": "双江拉祜族佤族布朗族傣族自治县",
                    "530926": "耿马傣族佤族自治县",
                    "530927": "沧源佤族自治县"
                },
                "532300": {
                    "532301": "楚雄市",
                    "532322": "双柏县",
                    "532323": "牟定县",
                    "532324": "南华县",
                    "532325": "姚安县",
                    "532326": "大姚县",
                    "532327": "永仁县",
                    "532328": "元谋县",
                    "532329": "武定县",
                    "532331": "禄丰县"
                },
                "532500": {
                    "532501": "个旧市",
                    "532502": "开远市",
                    "532503": "蒙自市",
                    "532504": "弥勒市",
                    "532523": "屏边苗族自治县",
                    "532524": "建水县",
                    "532525": "石屏县",
                    "532527": "泸西县",
                    "532528": "元阳县",
                    "532529": "红河县",
                    "532530": "金平苗族瑶族傣族自治县",
                    "532531": "绿春县",
                    "532532": "河口瑶族自治县"
                },
                "532600": {
                    "532601": "文山市",
                    "532622": "砚山县",
                    "532623": "西畴县",
                    "532624": "麻栗坡县",
                    "532625": "马关县",
                    "532626": "丘北县",
                    "532627": "广南县",
                    "532628": "富宁县"
                },
                "532800": {
                    "532801": "景洪市",
                    "532822": "勐海县",
                    "532823": "勐腊县"
                },
                "532900": {
                    "532901": "大理市",
                    "532922": "漾濞彝族自治县",
                    "532923": "祥云县",
                    "532924": "宾川县",
                    "532925": "弥渡县",
                    "532926": "南涧彝族自治县",
                    "532927": "巍山彝族回族自治县",
                    "532928": "永平县",
                    "532929": "云龙县",
                    "532930": "洱源县",
                    "532931": "剑川县",
                    "532932": "鹤庆县"
                },
                "533100": {
                    "533102": "瑞丽市",
                    "533103": "芒市",
                    "533122": "梁河县",
                    "533123": "盈江县",
                    "533124": "陇川县"
                },
                "533300": {
                    "533301": "泸水市",
                    "533323": "福贡县",
                    "533324": "贡山独龙族怒族自治县",
                    "533325": "兰坪白族普米族自治县"
                },
                "533400": {
                    "533401": "香格里拉市",
                    "533422": "德钦县",
                    "533423": "维西傈僳族自治县"
                },
                "540000": {
                    "540100": "拉萨市",
                    "540200": "日喀则市",
                    "540300": "昌都市",
                    "540400": "林芝市",
                    "540500": "山南市",
                    "542400": "那曲地区",
                    "542500": "阿里地区"
                },
                "540100": {
                    "540102": "城关区",
                    "540103": "堆龙德庆区",
                    "540121": "林周县",
                    "540122": "当雄县",
                    "540123": "尼木县",
                    "540124": "曲水县",
                    "540126": "达孜县",
                    "540127": "墨竹工卡县"
                },
                "540200": {
                    "540202": "桑珠孜区",
                    "540221": "南木林县",
                    "540222": "江孜县",
                    "540223": "定日县",
                    "540224": "萨迦县",
                    "540225": "拉孜县",
                    "540226": "昂仁县",
                    "540227": "谢通门县",
                    "540228": "白朗县",
                    "540229": "仁布县",
                    "540230": "康马县",
                    "540231": "定结县",
                    "540232": "仲巴县",
                    "540233": "亚东县",
                    "540234": "吉隆县",
                    "540235": "聂拉木县",
                    "540236": "萨嘎县",
                    "540237": "岗巴县"
                },
                "540300": {
                    "540302": "卡若区",
                    "540321": "江达县",
                    "540322": "贡觉县",
                    "540323": "类乌齐县",
                    "540324": "丁青县",
                    "540325": "察雅县",
                    "540326": "八宿县",
                    "540327": "左贡县",
                    "540328": "芒康县",
                    "540329": "洛隆县",
                    "540330": "边坝县"
                },
                "540400": {
                    "540402": "巴宜区",
                    "540421": "工布江达县",
                    "540422": "米林县",
                    "540423": "墨脱县",
                    "540424": "波密县",
                    "540425": "察隅县",
                    "540426": "朗县"
                },
                "540500": {
                    "540502": "乃东区",
                    "540521": "扎囊县",
                    "540522": "贡嘎县",
                    "540523": "桑日县",
                    "540524": "琼结县",
                    "540525": "曲松县",
                    "540526": "措美县",
                    "540527": "洛扎县",
                    "540528": "加查县",
                    "540529": "隆子县",
                    "540530": "错那县",
                    "540531": "浪卡子县"
                },
                "542400": {
                    "542421": "那曲县",
                    "542422": "嘉黎县",
                    "542423": "比如县",
                    "542424": "聂荣县",
                    "542425": "安多县",
                    "542426": "申扎县",
                    "542427": "索县",
                    "542428": "班戈县",
                    "542429": "巴青县",
                    "542430": "尼玛县",
                    "542431": "双湖县"
                },
                "542500": {
                    "542521": "普兰县",
                    "542522": "札达县",
                    "542523": "噶尔县",
                    "542524": "日土县",
                    "542525": "革吉县",
                    "542526": "改则县",
                    "542527": "措勤县"
                },
                "610000": {
                    "610100": "西安市",
                    "610200": "铜川市",
                    "610300": "宝鸡市",
                    "610400": "咸阳市",
                    "610500": "渭南市",
                    "610600": "延安市",
                    "610700": "汉中市",
                    "610800": "榆林市",
                    "610900": "安康市",
                    "611000": "商洛市"
                },
                "610100": {
                    "610102": "新城区",
                    "610103": "碑林区",
                    "610104": "莲湖区",
                    "610111": "灞桥区",
                    "610112": "未央区",
                    "610113": "雁塔区",
                    "610114": "阎良区",
                    "610115": "临潼区",
                    "610116": "长安区",
                    "610117": "高陵区",
                    "610122": "蓝田县",
                    "610124": "周至县",
                    "610125": "鄠邑区"
                },
                "610200": {
                    "610202": "王益区",
                    "610203": "印台区",
                    "610204": "耀州区",
                    "610222": "宜君县"
                },
                "610300": {
                    "610302": "渭滨区",
                    "610303": "金台区",
                    "610304": "陈仓区",
                    "610322": "凤翔县",
                    "610323": "岐山县",
                    "610324": "扶风县",
                    "610326": "眉县",
                    "610327": "陇县",
                    "610328": "千阳县",
                    "610329": "麟游县",
                    "610330": "凤县",
                    "610331": "太白县"
                },
                "610400": {
                    "610402": "秦都区",
                    "610403": "杨陵区",
                    "610404": "渭城区",
                    "610422": "三原县",
                    "610423": "泾阳县",
                    "610424": "乾县",
                    "610425": "礼泉县",
                    "610426": "永寿县",
                    "610427": "彬县",
                    "610428": "长武县",
                    "610429": "旬邑县",
                    "610430": "淳化县",
                    "610431": "武功县",
                    "610481": "兴平市"
                },
                "610500": {
                    "610502": "临渭区",
                    "610503": "华州区",
                    "610522": "潼关县",
                    "610523": "大荔县",
                    "610524": "合阳县",
                    "610525": "澄城县",
                    "610526": "蒲城县",
                    "610527": "白水县",
                    "610528": "富平县",
                    "610581": "韩城市",
                    "610582": "华阴市"
                },
                "610600": {
                    "610602": "宝塔区",
                    "610621": "延长县",
                    "610622": "延川县",
                    "610623": "子长县",
                    "610624": "安塞区",
                    "610625": "志丹县",
                    "610626": "吴起县",
                    "610627": "甘泉县",
                    "610628": "富县",
                    "610629": "洛川县",
                    "610630": "宜川县",
                    "610631": "黄龙县",
                    "610632": "黄陵县"
                },
                "610700": {
                    "610702": "汉台区",
                    "610721": "南郑县",
                    "610722": "城固县",
                    "610723": "洋县",
                    "610724": "西乡县",
                    "610725": "勉县",
                    "610726": "宁强县",
                    "610727": "略阳县",
                    "610728": "镇巴县",
                    "610729": "留坝县",
                    "610730": "佛坪县"
                },
                "610800": {
                    "610802": "榆阳区",
                    "610803": "横山区",
                    "610821": "神木县",
                    "610822": "府谷县",
                    "610824": "靖边县",
                    "610825": "定边县",
                    "610826": "绥德县",
                    "610827": "米脂县",
                    "610828": "佳县",
                    "610829": "吴堡县",
                    "610830": "清涧县",
                    "610831": "子洲县"
                },
                "610900": {
                    "610902": "汉滨区",
                    "610921": "汉阴县",
                    "610922": "石泉县",
                    "610923": "宁陕县",
                    "610924": "紫阳县",
                    "610925": "岚皋县",
                    "610926": "平利县",
                    "610927": "镇坪县",
                    "610928": "旬阳县",
                    "610929": "白河县"
                },
                "611000": {
                    "611002": "商州区",
                    "611021": "洛南县",
                    "611022": "丹凤县",
                    "611023": "商南县",
                    "611024": "山阳县",
                    "611025": "镇安县",
                    "611026": "柞水县"
                },
                "620000": {
                    "620100": "兰州市",
                    "620200": "嘉峪关市",
                    "620300": "金昌市",
                    "620400": "白银市",
                    "620500": "天水市",
                    "620600": "武威市",
                    "620700": "张掖市",
                    "620800": "平凉市",
                    "620900": "酒泉市",
                    "621000": "庆阳市",
                    "621100": "定西市",
                    "621200": "陇南市",
                    "622900": "临夏回族自治州",
                    "623000": "甘南藏族自治州"
                },
                "620100": {
                    "620102": "城关区",
                    "620103": "七里河区",
                    "620104": "西固区",
                    "620105": "安宁区",
                    "620111": "红古区",
                    "620121": "永登县",
                    "620122": "皋兰县",
                    "620123": "榆中县"
                },
                "620300": {
                    "620302": "金川区",
                    "620321": "永昌县"
                },
                "620400": {
                    "620402": "白银区",
                    "620403": "平川区",
                    "620421": "靖远县",
                    "620422": "会宁县",
                    "620423": "景泰县"
                },
                "620500": {
                    "620502": "秦州区",
                    "620503": "麦积区",
                    "620521": "清水县",
                    "620522": "秦安县",
                    "620523": "甘谷县",
                    "620524": "武山县",
                    "620525": "张家川回族自治县"
                },
                "620600": {
                    "620602": "凉州区",
                    "620621": "民勤县",
                    "620622": "古浪县",
                    "620623": "天祝藏族自治县"
                },
                "620700": {
                    "620702": "甘州区",
                    "620721": "肃南裕固族自治县",
                    "620722": "民乐县",
                    "620723": "临泽县",
                    "620724": "高台县",
                    "620725": "山丹县"
                },
                "620800": {
                    "620802": "崆峒区",
                    "620821": "泾川县",
                    "620822": "灵台县",
                    "620823": "崇信县",
                    "620824": "华亭县",
                    "620825": "庄浪县",
                    "620826": "静宁县"
                },
                "620900": {
                    "620902": "肃州区",
                    "620921": "金塔县",
                    "620922": "瓜州县",
                    "620923": "肃北蒙古族自治县",
                    "620924": "阿克塞哈萨克族自治县",
                    "620981": "玉门市",
                    "620982": "敦煌市"
                },
                "621000": {
                    "621002": "西峰区",
                    "621021": "庆城县",
                    "621022": "环县",
                    "621023": "华池县",
                    "621024": "合水县",
                    "621025": "正宁县",
                    "621026": "宁县",
                    "621027": "镇原县"
                },
                "621100": {
                    "621102": "安定区",
                    "621121": "通渭县",
                    "621122": "陇西县",
                    "621123": "渭源县",
                    "621124": "临洮县",
                    "621125": "漳县",
                    "621126": "岷县"
                },
                "621200": {
                    "621202": "武都区",
                    "621221": "成县",
                    "621222": "文县",
                    "621223": "宕昌县",
                    "621224": "康县",
                    "621225": "西和县",
                    "621226": "礼县",
                    "621227": "徽县",
                    "621228": "两当县"
                },
                "622900": {
                    "622901": "临夏市",
                    "622921": "临夏县",
                    "622922": "康乐县",
                    "622923": "永靖县",
                    "622924": "广河县",
                    "622925": "和政县",
                    "622926": "东乡族自治县",
                    "622927": "积石山保安族东乡族撒拉族自治县"
                },
                "623000": {
                    "623001": "合作市",
                    "623021": "临潭县",
                    "623022": "卓尼县",
                    "623023": "舟曲县",
                    "623024": "迭部县",
                    "623025": "玛曲县",
                    "623026": "碌曲县",
                    "623027": "夏河县"
                },
                "630000": {
                    "630100": "西宁市",
                    "630200": "海东市",
                    "632200": "海北藏族自治州",
                    "632300": "黄南藏族自治州",
                    "632500": "海南藏族自治州",
                    "632600": "果洛藏族自治州",
                    "632700": "玉树藏族自治州",
                    "632800": "海西蒙古族藏族自治州"
                },
                "630100": {
                    "630102": "城东区",
                    "630103": "城中区",
                    "630104": "城西区",
                    "630105": "城北区",
                    "630121": "大通回族土族自治县",
                    "630122": "湟中县",
                    "630123": "湟源县"
                },
                "630200": {
                    "630202": "乐都区",
                    "630203": "平安区",
                    "630222": "民和回族土族自治县",
                    "630223": "互助土族自治县",
                    "630224": "化隆回族自治县",
                    "630225": "循化撒拉族自治县"
                },
                "632200": {
                    "632221": "门源回族自治县",
                    "632222": "祁连县",
                    "632223": "海晏县",
                    "632224": "刚察县"
                },
                "632300": {
                    "632321": "同仁县",
                    "632322": "尖扎县",
                    "632323": "泽库县",
                    "632324": "河南蒙古族自治县"
                },
                "632500": {
                    "632521": "共和县",
                    "632522": "同德县",
                    "632523": "贵德县",
                    "632524": "兴海县",
                    "632525": "贵南县"
                },
                "632600": {
                    "632621": "玛沁县",
                    "632622": "班玛县",
                    "632623": "甘德县",
                    "632624": "达日县",
                    "632625": "久治县",
                    "632626": "玛多县"
                },
                "632700": {
                    "632701": "玉树市",
                    "632722": "杂多县",
                    "632723": "称多县",
                    "632724": "治多县",
                    "632725": "囊谦县",
                    "632726": "曲麻莱县"
                },
                "632800": {
                    "632801": "格尔木市",
                    "632802": "德令哈市",
                    "632821": "乌兰县",
                    "632822": "都兰县",
                    "632823": "天峻县",
                    "632825": "海西蒙古族藏族自治州直辖"
                },
                "640000": {
                    "640100": "银川市",
                    "640200": "石嘴山市",
                    "640300": "吴忠市",
                    "640400": "固原市",
                    "640500": "中卫市"
                },
                "640100": {
                    "640104": "兴庆区",
                    "640105": "西夏区",
                    "640106": "金凤区",
                    "640121": "永宁县",
                    "640122": "贺兰县",
                    "640181": "灵武市"
                },
                "640200": {
                    "640202": "大武口区",
                    "640205": "惠农区",
                    "640221": "平罗县"
                },
                "640300": {
                    "640302": "利通区",
                    "640303": "红寺堡区",
                    "640323": "盐池县",
                    "640324": "同心县",
                    "640381": "青铜峡市"
                },
                "640400": {
                    "640402": "原州区",
                    "640422": "西吉县",
                    "640423": "隆德县",
                    "640424": "泾源县",
                    "640425": "彭阳县"
                },
                "640500": {
                    "640502": "沙坡头区",
                    "640521": "中宁县",
                    "640522": "海原县"
                },
                "650000": {
                    "650100": "乌鲁木齐市",
                    "650200": "克拉玛依市",
                    "650400": "吐鲁番市",
                    "650500": "哈密市",
                    "652300": "昌吉回族自治州",
                    "652700": "博尔塔拉蒙古自治州",
                    "652800": "巴音郭楞蒙古自治州",
                    "652900": "阿克苏地区",
                    "653000": "克孜勒苏柯尔克孜自治州",
                    "653100": "喀什地区",
                    "653200": "和田地区",
                    "654000": "伊犁哈萨克自治州",
                    "654200": "塔城地区",
                    "654300": "阿勒泰地区",
                    "659001": "石河子市",
                    "659002": "阿拉尔市",
                    "659003": "图木舒克市",
                    "659004": "五家渠市",
                    "659005": "北屯市",
                    "659006": "铁门关市",
                    "659007": "双河市",
                    "659008": "可克达拉市",
                    "659009": "昆玉市"
                },
                "650100": {
                    "650102": "天山区",
                    "650103": "沙依巴克区",
                    "650104": "新市区",
                    "650105": "水磨沟区",
                    "650106": "头屯河区",
                    "650107": "达坂城区",
                    "650109": "米东区",
                    "650121": "乌鲁木齐县"
                },
                "650200": {
                    "650202": "独山子区",
                    "650203": "克拉玛依区",
                    "650204": "白碱滩区",
                    "650205": "乌尔禾区"
                },
                "650400": {
                    "650402": "高昌区",
                    "650421": "鄯善县",
                    "650422": "托克逊县"
                },
                "650500": {
                    "650502": "伊州区",
                    "650521": "巴里坤哈萨克自治县",
                    "650522": "伊吾县"
                },
                "652300": {
                    "652301": "昌吉市",
                    "652302": "阜康市",
                    "652323": "呼图壁县",
                    "652324": "玛纳斯县",
                    "652325": "奇台县",
                    "652327": "吉木萨尔县",
                    "652328": "木垒哈萨克自治县"
                },
                "652700": {
                    "652701": "博乐市",
                    "652702": "阿拉山口市",
                    "652722": "精河县",
                    "652723": "温泉县"
                },
                "652800": {
                    "652801": "库尔勒市",
                    "652822": "轮台县",
                    "652823": "尉犁县",
                    "652824": "若羌县",
                    "652825": "且末县",
                    "652826": "焉耆回族自治县",
                    "652827": "和静县",
                    "652828": "和硕县",
                    "652829": "博湖县"
                },
                "652900": {
                    "652901": "阿克苏市",
                    "652922": "温宿县",
                    "652923": "库车县",
                    "652924": "沙雅县",
                    "652925": "新和县",
                    "652926": "拜城县",
                    "652927": "乌什县",
                    "652928": "阿瓦提县",
                    "652929": "柯坪县"
                },
                "653000": {
                    "653001": "阿图什市",
                    "653022": "阿克陶县",
                    "653023": "阿合奇县",
                    "653024": "乌恰县"
                },
                "653100": {
                    "653101": "喀什市",
                    "653121": "疏附县",
                    "653122": "疏勒县",
                    "653123": "英吉沙县",
                    "653124": "泽普县",
                    "653125": "莎车县",
                    "653126": "叶城县",
                    "653127": "麦盖提县",
                    "653128": "岳普湖县",
                    "653129": "伽师县",
                    "653130": "巴楚县",
                    "653131": "塔什库尔干塔吉克自治县"
                },
                "653200": {
                    "653201": "和田市",
                    "653221": "和田县",
                    "653222": "墨玉县",
                    "653223": "皮山县",
                    "653224": "洛浦县",
                    "653225": "策勒县",
                    "653226": "于田县",
                    "653227": "民丰县"
                },
                "654000": {
                    "654002": "伊宁市",
                    "654003": "奎屯市",
                    "654004": "霍尔果斯市",
                    "654021": "伊宁县",
                    "654022": "察布查尔锡伯自治县",
                    "654023": "霍城县",
                    "654024": "巩留县",
                    "654025": "新源县",
                    "654026": "昭苏县",
                    "654027": "特克斯县",
                    "654028": "尼勒克县"
                },
                "654200": {
                    "654201": "塔城市",
                    "654202": "乌苏市",
                    "654221": "额敏县",
                    "654223": "沙湾县",
                    "654224": "托里县",
                    "654225": "裕民县",
                    "654226": "和布克赛尔蒙古自治县"
                },
                "654300": {
                    "654301": "阿勒泰市",
                    "654321": "布尔津县",
                    "654322": "富蕴县",
                    "654323": "福海县",
                    "654324": "哈巴河县",
                    "654325": "青河县",
                    "654326": "吉木乃县"
                },
                "810000": {
                    "810001": "中西区",
                    "810002": "湾仔区",
                    "810003": "东区",
                    "810004": "南区",
                    "810005": "油尖旺区",
                    "810006": "深水埗区",
                    "810007": "九龙城区",
                    "810008": "黄大仙区",
                    "810009": "观塘区",
                    "810010": "荃湾区",
                    "810011": "屯门区",
                    "810012": "元朗区",
                    "810013": "北区",
                    "810014": "大埔区",
                    "810015": "西贡区",
                    "810016": "沙田区",
                    "810017": "葵青区",
                    "810018": "离岛区"
                },
                "820000": {
                    "820001": "花地玛堂区",
                    "820002": "花王堂区",
                    "820003": "望德堂区",
                    "820004": "大堂区",
                    "820005": "风顺堂区",
                    "820006": "嘉模堂区",
                    "820007": "路凼填海区",
                    "820008": "圣方济各堂区"
                }
            },
            n = function(t, e) {
                if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
            },
            o = function() {
                function t(t, e) {
                    for (var i = 0; i < e.length; i++) {
                        var n = e[i];
                        n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), Object.defineProperty(t, n.key, n)
                    }
                }
                return function(e, i, n) {
                    return i && t(e.prototype, i), n && t(e, n), e
                }
            }(),
            a = "change.distpicker",
            s = function() {
                function s(i, o) {
                    n(this, s);
                    var a = this;
                    a.$element = t(i), a.options = t.extend({}, e, t.isPlainObject(o) && o), a.placeholders = t.extend({}, e), a.ready = !1, a.init()
                }
                return o(s, [{
                    "key": "init",
                    "value": function() {
                        var e = this,
                            i = e.options,
                            n = e.$element.find("select"),
                            o = n.length,
                            a = {};
                        n.each(function(e, i) {
                            return t.extend(a, t(i).data())
                        }), t.each(["province", "city", "district"], function(t, s) {
                            a[s] ? (i[s] = a[s], e["$" + s] = n.filter("[data-" + s + "]")) : e["$" + s] = o > t ? n.eq(t) : null
                        }), e.bind(), e.reset(), e.ready = !0
                    }
                }, {
                    "key": "bind",
                    "value": function() {
                        var e = this;
                        e.$province && e.$province.on(a, e.onChangeProvince = t.proxy(function() {
                            e.output("city"), e.output("district")
                        }, e)), e.$city && e.$city.on(a, e.onChangeCity = t.proxy(function() {
                            return e.output("district")
                        }, e))
                    }
                }, {
                    "key": "unbind",
                    "value": function() {
                        var t = this;
                        t.$province && t.$province.off(a, t.onChangeProvince), t.$city && t.$city.off(a, t.onChangeCity)
                    }
                }, {
                    "key": "output",
                    "value": function(e) {
                        var i = this,
                            n = i.options,
                            o = i.placeholders,
                            a = i["$" + e];
                        if (a && a.length) {
                            var s = void 0;
                            switch (e) {
                                case "province":
                                    s = 1e5;
                                    break;
                                case "city":
                                    s = i.$province && (i.$province.find(":selected").data("code") || "");
                                    break;
                                case "district":
                                    s = i.$city && (i.$city.find(":selected").data("code") || "")
                            }
                            var r = i.getDistricts(s),
                                l = n[e],
                                c = [],
                                d = !1;
                            if (t.isPlainObject(r) && t.each(r, function(t, e) {
                                    var i = e === l;
                                    "code" === n.valueType && (i = t === String(l)), i && (d = !0), c.push({
                                        "code": t,
                                        "name": e,
                                        "value": "name" === n.valueType ? e : t,
                                        "selected": i
                                    })
                                }), !d) {
                                var u = n.autoselect || n.autoSelect;
                                c.length && ("province" === e && u > 0 || "city" === e && u > 1 || "district" === e && u > 2) && (c[0].selected = !0), !i.ready && l && (o[e] = l)
                            }
                            n.placeholder && c.unshift({
                                "code": "",
                                "name": o[e],
                                "value": "",
                                "selected": !1
                            }), c.length ? a.html(i.getList(c)) : a.empty()
                        }
                    }
                }, {
                    "key": "getList",
                    "value": function(e) {
                        var i = [];
                        return t.each(e, function(t, e) {
                            var n = ['data-code="' + e.code + '"', 'data-text="' + e.name + '"', 'value="' + e.value + '"'];
                            e.selected && n.push("selected"), i.push("<option " + n.join(" ") + ">" + e.name + "</option>")
                        }), i.join("")
                    }
                }, {
                    "key": "getDistricts",
                    "value": function() {
                        return i[arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 1e5] || null
                    }
                }, {
                    "key": "reset",
                    "value": function(t) {
                        var e = this;
                        t ? e.$province && e.$province.find(":first").prop("selected", !0).trigger(a) : (e.output("province"), e.output("city"), e.output("district"))
                    }
                }, {
                    "key": "destroy",
                    "value": function() {
                        var t = this;
                        t.unbind(), t.$element.removeData("distpicker")
                    }
                }], [{
                    "key": "setDefaults",
                    "value": function(i) {
                        t.extend(e, t.isPlainObject(i) && i)
                    }
                }]), s
            }(),
            r = t.fn.distpicker;
        t.fn.distpicker = function(e) {
            for (var i = arguments.length, n = Array(i > 1 ? i - 1 : 0), o = 1; o < i; o++) n[o - 1] = arguments[o];
            var a = void 0;
            return this.each(function() {
                var i = t(this),
                    o = i.data("distpicker");
                if (!o) {
                    if (/destroy/.test(e)) return;
                    var r = t.extend({}, i.data(), t.isPlainObject(e) && e);
                    i.data("distpicker", o = new s(this, r))
                }
                if ("string" == typeof e) {
                    var l = o[e];
                    t.isFunction(l) && (a = l.apply(o, n))
                }
            }), void 0 !== a ? a : this
        }, t.fn.distpicker.Constructor = s, t.fn.distpicker.setDefaults = s.setDefaults, t.fn.distpicker.noConflict = function() {
            return t.fn.distpicker = r, this
        }, t(function() {
            t('[data-toggle="distpicker"]').distpicker()
        })
    })
}, function(t, e, i) {
    "use strict";
    ! function(t) {
        t.fn.addBack = t.fn.addBack || t.fn.andSelf, t.fn.extend({
            "actual": function(e, i) {
                if (!this[e]) throw '$.actual => The jQuery method "' + e + '" you called does not exist';
                var n, o, a = {
                        "absolute": !1,
                        "clone": !1,
                        "includeMargin": !1
                    },
                    s = t.extend(a, i),
                    r = this.eq(0);
                if (!0 === s.clone) n = function() {
                    r = r.clone().attr("style", "position: absolute !important; top: -1000 !important; ").appendTo("body")
                }, o = function() {
                    r.remove()
                };
                else {
                    var l, c = [],
                        d = "";
                    n = function() {
                        l = r.parents().addBack().filter(":hidden"), d += "visibility: hidden !important; display: block !important; ", !0 === s.absolute && (d += "position: absolute !important; "), l.each(function() {
                            var e = t(this),
                                i = e.attr("style");
                            c.push(i), e.attr("style", i ? i + ";" + d : d)
                        })
                    }, o = function() {
                        l.each(function(e) {
                            var i = t(this),
                                n = c[e];
                            n === undefined ? i.removeAttr("style") : i.attr("style", n)
                        })
                    }
                }
                n();
                var u = /(outer)/.test(e) ? r[e](s.includeMargin) : r[e]();
                return o(), u
            }
        })
    }(jQuery)
}], [18]);