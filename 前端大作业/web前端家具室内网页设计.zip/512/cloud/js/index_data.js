var portal_url = '/sites/v2qsap/';
var c_data = c_data || {};
c_data.animations = [];
c_data.timelines = [{
    "data": {
        "type": 0,
        "t": {
            "rv": 0,
            "rp": 0,
            "wa": 0,
            "de": 0,
            "st": 1,
            "du": 1,
            "es": 0
        },
        "d": {}
    },
    "element_id": "section40c9c426",
    "iType": 0,
    "id": "tl_a31d502a",
    "animations": ["ani_810a0671"]
}, {
    "data": {
        "type": 0,
        "t": {
            "rv": 0,
            "rp": 0,
            "wa": 0,
            "de": 0,
            "st": 1,
            "du": 1,
            "es": 0
        },
        "d": {}
    },
    "element_id": "slider64b09eae",
    "iType": 0,
    "id": "tl_6cbffc05",
    "animations": ["ani_34b7cce3"]
}, {
    "data": {
        "type": 0,
        "t": {
            "rv": 0,
            "rp": 0,
            "wa": 0,
            "de": 0,
            "st": 1,
            "du": 1,
            "es": 0
        },
        "d": {}
    },
    "element_id": "slidea847f6c0",
    "iType": 0,
    "id": "tl_a6277508",
    "animations": ["ani_24913d36288dd66e", "ani_69c32dcc", "ani_6bfde56332a8b14d"]
}, {
    "data": {
        "type": 0,
        "t": {
            "rv": 0,
            "rp": 0,
            "wa": 0,
            "de": 0,
            "st": 1,
            "du": 1,
            "es": 0
        },
        "d": {}
    },
    "element_id": "sectionfcee37b3",
    "iType": 0,
    "id": "tl_86b5022c",
    "animations": []
}, {
    "data": {
        "type": 0,
        "t": {
            "rv": 0,
            "rp": 0,
            "wa": 0,
            "de": 0,
            "st": 1,
            "du": 1,
            "es": 0
        },
        "d": {}
    },
    "element_id": "slidee5148336",
    "iType": 0,
    "id": "tl_304a9df1",
    "animations": ["ani_24913d36288dd66e", "ani_69c32dcc", "ani_6bfde56332a8b14d"]
}, {
    "data": {
        "type": 0,
        "t": {
            "rv": 0,
            "rp": 0,
            "wa": 0,
            "de": 0,
            "st": 1,
            "du": 1,
            "es": 0
        },
        "d": {}
    },
    "element_id": "slidee932fa94",
    "iType": 0,
    "id": "tl_1c345627",
    "animations": ["ani_24913d36288dd66e", "ani_69c32dcc", "ani_6bfde56332a8b14d"]
}, {
    "data": {
        "type": 0,
        "t": {
            "rv": 0,
            "rp": 0,
            "wa": 0,
            "de": 0,
            "st": 1,
            "du": 1,
            "es": 0
        },
        "d": {}
    },
    "element_id": "slide23bad099",
    "iType": 0,
    "id": "tl_790cbb2b",
    "animations": ["ani_24913d36288dd66e", "ani_69c32dcc", "ani_6bfde56332a8b14d"]
}, {
    "data": {
        "type": 0,
        "t": {
            "rv": 0,
            "rp": 0,
            "wa": 0,
            "de": 0,
            "st": 1,
            "du": 1,
            "es": 0
        },
        "d": {}
    },
    "element_id": "slidee4f1c904",
    "iType": 0,
    "id": "tl_c182165c",
    "animations": ["ani_24913d36288dd66e", "ani_69c32dcc", "ani_6bfde56332a8b14d"]
}, {
    "iType": 0,
    "isNew": true,
    "animations": [],
    "element_id": "slider_35f7c312",
    "data": {
        "type": 0,
        "t": {
            "rv": 0,
            "rp": 0,
            "wa": 0,
            "de": 0,
            "st": 1,
            "du": 1,
            "es": 0
        },
        "d": {}
    },
    "id": "M_2e12d9aa1713faca"
}, {
    "iType": 0,
    "isNew": true,
    "animations": [],
    "element_id": "slidea9d97684",
    "data": {
        "type": 0,
        "t": {
            "rv": 0,
            "rp": 0,
            "wa": 0,
            "de": 0,
            "st": 1,
            "du": 1,
            "es": 0
        },
        "d": {}
    },
    "id": "M_01e61fae226cb684"
}, {
    "iType": 0,
    "isNew": true,
    "animations": [],
    "element_id": "slide0e9f0618",
    "data": {
        "type": 0,
        "t": {
            "rv": 0,
            "rp": 0,
            "wa": 0,
            "de": 0,
            "st": 1,
            "du": 1,
            "es": 0
        },
        "d": {}
    },
    "id": "M_11f71a8ab0b54ad4"
}, {
    "iType": 0,
    "isNew": true,
    "animations": [],
    "element_id": "slide5f46cad0",
    "data": {
        "type": 0,
        "t": {
            "rv": 0,
            "rp": 0,
            "wa": 0,
            "de": 0,
            "st": 1,
            "du": 1,
            "es": 0
        },
        "d": {}
    },
    "id": "M_81631b7b73b55a3c"
}, {
    "data": {
        "type": 0,
        "t": {
            "rv": 0,
            "rp": 0,
            "wa": 0,
            "de": 0,
            "st": 1,
            "du": 1,
            "es": 0
        },
        "d": {}
    },
    "element_id": "sectiondb4951b6",
    "iType": 0,
    "id": "tl_e390310d",
    "animations": []
}, {
    "data": {
        "type": 0,
        "t": {
            "rv": 0,
            "rp": 0,
            "wa": 0,
            "de": 0,
            "st": 1,
            "du": 1,
            "es": 0
        },
        "d": {}
    },
    "element_id": "section0153e977",
    "iType": 0,
    "id": "tl_59767781",
    "animations": []
}, {
    "data": {
        "type": 0,
        "t": {
            "rv": 0,
            "rp": 0,
            "wa": 0,
            "de": 0,
            "st": 1,
            "du": 1,
            "es": 0
        },
        "d": {}
    },
    "element_id": "section78533062",
    "iType": 0,
    "id": "tl_e86e7b5b",
    "animations": []
}, {
    "data": {
        "type": 0,
        "t": {
            "rv": 0,
            "rp": 0,
            "wa": 0,
            "de": 0,
            "st": 1,
            "du": 1,
            "es": 0
        },
        "d": {}
    },
    "element_id": "section76147ea6",
    "iType": 0,
    "id": "tl_dd3cfc1d",
    "animations": []
}, {
    "iType": 0,
    "element_id": "section73ef9f42",
    "data": {
        "type": 0,
        "t": {
            "rv": 0,
            "rp": 0,
            "wa": 0,
            "de": 0,
            "st": 1,
            "du": 1,
            "es": 0
        },
        "d": {}
    },
    "id": "tl_f83f28f0",
    "animations": []
}, {
    "iType": 0,
    "element_id": "sectionab099e47",
    "data": {
        "type": 0,
        "t": {
            "rv": 0,
            "rp": 0,
            "wa": 0,
            "de": 0,
            "st": 1,
            "du": 1,
            "es": 0
        },
        "d": {}
    },
    "id": "tl_389d6d77",
    "animations": []
}];
c_data.actions = [{
    "element_id": "linkblock1e40a0f4",
    "data": {
        "args": {
            "e_ids": ["icon1fac4612", "iconaf5904a3", "navcollapseb9aaba37"],
            "cla": "c-state1",
            "st": 1,
            "a_ids": []
        },
        "type": 0,
        "exec": 23
    },
    "id": "act_eb360d5c"
}]